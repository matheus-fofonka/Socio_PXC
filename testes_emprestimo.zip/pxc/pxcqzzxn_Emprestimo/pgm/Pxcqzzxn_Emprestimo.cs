﻿using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.BD;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Text;

namespace Bergs.Pxc.Pxcqzzxn
{
    /// <summary>Classe que possui os métodos de manipulação de dados da tabela EMPRESTIMO da base de dados PXC.</summary>
    public class Emprestimo : AplicacaoDados
    {
        /// <summary>Nome da tabela da correção.</summary>
        const String NOME_TABELA = "EMPRESTIMO33";

        #region Métodos Público - Cliente
        #region IncluirCliente
        /// <summary>Método incluir referente à tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> IncluirCliente(TOClientePxc toClientePxc)
        {
            try
            {
                Int32 registrosAfetados;

                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Sql.Temporario.Length = 0;
                this.Parametros.Clear();
                toClientePxc.CodOperador = Infra.Usuario.Matricula;
                //Inicia montagem do comando
                this.Sql.Comando.Append("INSERT INTO PXC.CLIENTE_PXC (");
                //Monta campos que serão inseridos
                this.MontarInsertCliente(toClientePxc);

                //Une os buffers de montagem do comando
                this.Sql.Comando.Append(") VALUES (");
                this.Sql.Comando.Append(this.Sql.Temporario.ToString());

                this.Sql.Comando.Append(")");

                //Executa o comando
                registrosAfetados = this.IncluirDados();

                return this.Infra.RetornarSucesso(registrosAfetados);
            }
            // Utilizar catches correspondentes de exceções de banco de dados
            catch (Bergs.Pwx.Pwxodaxn.Excecoes.RegistroDuplicadoException ex)
            {
                return this.Infra.RetornarFalha<Int32>(new Pwx.Pwxoiexn.Mensagens.RegistroDuplicadoMensagem(ex));
            }
            catch (Bergs.Pwx.Pwxodaxn.Excecoes.ChaveEstrangeiraInexistenteException ex)
            {
                return this.Infra.RetornarFalha<Int32>(new Pwx.Pwxoiexn.Mensagens.ChaveEstrangeiraInexistenteMensagem(ex));
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
        #endregion
        #region ExcluirCliente
        /// <summary>Método excluir referente à tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> ExcluirCliente(TOClientePxc toClientePxc)
        {
            try
            {
                Int32 registrosAfetados;

                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear();

                //Inicia montagem do comando
                this.Sql.Comando.Append("DELETE FROM PXC.CLIENTE_PXC");
                //Filtra a exclusão pelas chaves da tabela
                this.MontarWhereChavesCliente(toClientePxc);
                //Filtra a exclusão pelo campo de controle de acessos concorrentes
                //this.Sql.MontarCampoWhere("ULT_ATUALIZACAO", toClientePxc.UltAtualizacao);

                //Executa o comando
                registrosAfetados = this.ExcluirDados();
                if (registrosAfetados == 0)
                {
                    return this.Infra.RetornarFalha<Int32>(new ConcorrenciaMensagem());
                }

                return this.Infra.RetornarSucesso(registrosAfetados);
            }
            // Utilizar catches correspondentes de exceções de banco de dados
            catch (Bergs.Pwx.Pwxodaxn.Excecoes.ChaveEstrangeiraReferenciadaException ex)
            {
                return this.Infra.RetornarFalha<Int32>(new Pwx.Pwxoiexn.Mensagens.ChaveEstrangeiraReferenciadaMensagem(ex));
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
        #endregion
        #region ObterCliente
        /// <summary>Método obter referente à tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOClientePxc> ObterCliente(TOClientePxc toClientePxc)
        {
            try
            {
                Linha linha;
                TOClientePxc dados;

                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear();

                //Inicia montagem do comando
                this.Sql.Comando.Append("SELECT ");
                this.Sql.Comando.Append("AGENCIA, ");
                this.Sql.Comando.Append("COD_CLIENTE, ");
                this.Sql.Comando.Append("COD_OPERADOR, ");
                this.Sql.Comando.Append("DT_ABE_CAD, ");
                this.Sql.Comando.Append("DT_CONSTITUICAO, ");
                this.Sql.Comando.Append("IND_FUNC_BANRISUL, ");
                this.Sql.Comando.Append("NOME_CLIENTE, ");
                this.Sql.Comando.Append("NOME_FANTASIA, ");
                this.Sql.Comando.Append("NOME_MAE, ");
                this.Sql.Comando.Append("TIPO_PESSOA, ");
                this.Sql.Comando.Append("ULT_ATUALIZACAO, ");
                this.Sql.Comando.Append("ULT_NOSSO_NRO, ");
                this.Sql.Comando.Append("VLR_CAPITAL_SOCIAL ");
                this.Sql.Comando.Append("FROM PXC.CLIENTE_PXC");
                //Filtra consulta pelos dados informados no TO
                this.MontarWhereChavesCliente(toClientePxc);

                //Executa o comando
                linha = this.ObterDados();
                if (linha == null)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(new RegistroInexistenteMensagem());
                }

                //Cria TO para a tupla retornada
                dados = new TOClientePxc();
                dados.PopularRetorno(linha);

                return this.Infra.RetornarSucesso(dados);
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOClientePxc>(ex);
            }
        }
        #endregion
        #endregion
        #region Métodos Privados - Cliente
        /// <summary>Monta campos para cláusula INSERT.</summary>
        /// <param name="toClientePxc">TO contendo os campos.</param>
        private void MontarInsertCliente(TOClientePxc toClientePxc)
        {
            //Monta no INSERT todos os campos da tabela que foram informados

            this.MontarCamposChaveCliente(this.Sql.MontarCampoInsert, toClientePxc);
            this.MontarCamposCliente(this.Sql.MontarCampoInsert, toClientePxc);
            this.Sql.MontarCampoInsert("ULT_ATUALIZACAO");
            this.Sql.Temporario.Append("CURRENT_TIMESTAMP");
        }

        /// <summary>Monta campos para cláusula WHERE.</summary>
        /// <param name="toClientePxc">TO contendo os campos.</param>
        private void MontarWhereCliente(TOClientePxc toClientePxc)
        {
            //Monta no WHERE todos os campos da tabela que foram informados

            this.MontarWhereChavesCliente(toClientePxc);
            this.MontarCamposCliente(this.Sql.MontarCampoWhere, toClientePxc);
            this.Sql.MontarCampoWhere("ULT_ATUALIZACAO", toClientePxc.UltAtualizacao);
        }

        /// <summary>Monta campos chave para cláusula WHERE.</summary>
        /// <param name="toClientePxc">TO contendo os campos.</param>
        private void MontarWhereChavesCliente(TOClientePxc toClientePxc)
        {
            //Monta no WHERE todos os campos chave da tabela

            this.MontarCamposChaveCliente(this.Sql.MontarCampoWhere, toClientePxc);
        }

        /// <summary>Executa uma ação nos campos chave de um TO.</summary>
        /// <param name="montagem">Ação a ser executada.</param>
        /// <param name="toClientePxc">TO alvo das ações.</param>
        private void MontarCamposChaveCliente(ConstrutorSql.MontarCampo montagem, TOClientePxc toClientePxc)
        {
            //Invoca qualquer comando simples de montagem nos campos chave da tabela

            // COD_CLIENTE deve ser SEMPRE trabalhado com 14 dígitos 
            if (toClientePxc.CodCliente.FoiSetado)
            {
                montagem.Invoke("COD_CLIENTE", new CampoObrigatorio<String>(toClientePxc.CodCliente.ToString().PadLeft(14, '0')));
            }
            montagem.Invoke("TIPO_PESSOA", toClientePxc.TipoPessoa);
        }

        /// <summary>Executa uma ação nos campos não chave de um TO.</summary>
        /// <param name="montagem">Ação a ser executada.</param>
        /// <param name="toClientePxc">TO alvo das ações.</param>
        private void MontarCamposCliente(ConstrutorSql.MontarCampo montagem, TOClientePxc toClientePxc)
        {
            //Invoca qualquer comando simples de montagem nos campos não chave da tabela, exceto no que faz controle de acessos concorrentes

            montagem.Invoke("AGENCIA", toClientePxc.Agencia);
            montagem.Invoke("COD_OPERADOR", toClientePxc.CodOperador);
            montagem.Invoke("DT_ABE_CAD", toClientePxc.DtAbeCad);
            montagem.Invoke("DT_CONSTITUICAO", toClientePxc.DtConstituicao);
            montagem.Invoke("IND_FUNC_BANRISUL", toClientePxc.IndFuncBanrisul);
            montagem.Invoke("NOME_FANTASIA", toClientePxc.NomeFantasia);
            montagem.Invoke("NOME_MAE", toClientePxc.NomeMae);
            montagem.Invoke("ULT_NOSSO_NRO", toClientePxc.UltNossoNro);
            montagem.Invoke("VLR_CAPITAL_SOCIAL", toClientePxc.VlrCapitalSocial);

            // Fazer %LIKE% no campo NOME_CLIENTE
            if (montagem == this.Sql.MontarCampoWhere)
            {
                if (toClientePxc.NomeCliente.FoiSetado)
                {
                    this.Sql.MontarCampoWhere("NOME_CLIENTE", new CampoObrigatorio<String>("%" + toClientePxc.NomeCliente.ToString() + "%"));
                }
            }
            else
            {
                montagem.Invoke("NOME_CLIENTE", toClientePxc.NomeCliente);
            }
        }
        #endregion
        #region Métodos
        /// <summary>Método alterar referente à tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Alterar(TOClientePxc toClientePxc)
        {
            try
            {
                Int32 registrosAfetados;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear();
                if (this.TemEmprestimo(toClientePxc))
                {
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodOperador = Infra.Usuario.Matricula;
                }
                    
                //Inicia montagem do comando
                this.Sql.Comando.Append("UPDATE PXC."+NOME_TABELA);
                //Monta campos que serão modificados
                this.MontarSet(toClientePxc);
                //Filtra a alteração pelas chaves da tabela
                this.MontarWhereChaves(toClientePxc);
                //Filtra a alteração pelo campo de controle de acessos concorrentes
                if (this.TemEmprestimo(toClientePxc))
                {
                    this.Sql.MontarCampoWhere("ULT_ATUALIZACAO", toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao);    
                }

                //Executa o comando
                registrosAfetados = this.AlterarDados();
                if (registrosAfetados == 0)
                {
                    return this.Infra.RetornarFalha<Int32>(new ConcorrenciaMensagem());
                }

                return this.Infra.RetornarSucesso(registrosAfetados);
            }    
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
     
        /// <summary>Método contar referente à tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int64> Contar(TOClientePxc toClientePxc)
        {
            try
            {
                Int64 quantidadeRegistros;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear();

                //Inicia montagem do comando
                this.Sql.Comando.Append("SELECT COUNT(*) FROM PXC."+NOME_TABELA);
                //Filtra consulta pelos dados informados no TO
                this.MontarWhere(toClientePxc);

                //Executa o comando
                quantidadeRegistros = this.ContarDados();

                return this.Infra.RetornarSucesso(quantidadeRegistros);
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int64>(ex);
            }
        }
      
        /// <summary>Método excluir referente à tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Excluir(TOClientePxc toClientePxc)
        {
            try
            {
                Int32 registrosAfetados;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear();
                TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
                    
                //Inicia montagem do comando
                this.Sql.Comando.Append("DELETE FROM PXC."+NOME_TABELA);
                //Filtra a exclusão pelas chaves da tabela
                this.MontarWhereChaves(toClientePxc);
                //Filtra a exclusão pelo campo de controle de acessos concorrentes
                this.Sql.MontarCampoWhere("ULT_ATUALIZACAO", toEmprestimo.UltAtualizacao);
          
                //Executa o comando
                registrosAfetados = this.ExcluirDados();
                if (registrosAfetados == 0)
                {
                    return this.Infra.RetornarFalha<Int32>(new ConcorrenciaMensagem());
                }
                
                return this.Infra.RetornarSucesso(registrosAfetados);
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }

        /// <summary>Método excluir referente à tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> ExcluirMultiplosEmprestimos(TOClientePxc toClientePxc)
        {
            try
            {
                Int32 registrosAfetados;

                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear();

                //Inicia montagem do comando
                this.Sql.Comando.Append("DELETE FROM PXC."+NOME_TABELA);
                //Filtra a exclusão pelas chaves da tabela
                this.Sql.MontarCampoWhere("COD_CLIENTE", new CampoObrigatorio<String>(toClientePxc.CodCliente.ToString().PadLeft(14, '0')));
                this.Sql.MontarCampoWhere("TIPO_PESSOA", toClientePxc.TipoPessoa);

                //Executa o comando
                registrosAfetados = this.ExcluirMultiplosDados();

                return this.Infra.RetornarSucesso(registrosAfetados);
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
     
        /// <summary>Método incluir referente à tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Incluir(TOClientePxc toClientePxc)
        {
            try
            { 
                Int32 registrosAfetados;                
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Sql.Temporario.Length = 0;
                this.Parametros.Clear();
                TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
                toEmprestimo.CodOperador = Infra.Usuario.Matricula; 
                //Inicia montagem do comando
                this.Sql.Comando.Append("INSERT INTO PXC." + NOME_TABELA + " (");
                //Monta campos que serão inseridos
                this.MontarInsert(toClientePxc);
                 
                //Une os buffers de montagem do comando
                this.Sql.Comando.Append(") VALUES (");                
                this.Sql.Comando.Append(this.Sql.Temporario.ToString());
                
                this.Sql.Comando.Append(")");

                //Executa o comando
                registrosAfetados = this.IncluirDados();

                return this.Infra.RetornarSucesso(registrosAfetados);
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
    
        /// <summary>Método listar referente à tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <param name="toPaginacao">Classe da infra-estrutura contendo as informações de paginação.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<List<TOEmprestimo>> Listar(TOClientePxc toClientePxc, TOPaginacao toPaginacao)
        {
            try
            {
                List<TOEmprestimo> dados;
                TOEmprestimo toRetorno;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear(); 

                //Inicia montagem do comando
                this.Sql.Comando.Append("SELECT ");
                this.Sql.Comando.Append("COD_EMPRESTIMO, ");
                this.Sql.Comando.Append("COD_CLIENTE, ");
                this.Sql.Comando.Append("TIPO_PESSOA, ");
                this.Sql.Comando.Append("VALOR_EMP, ");
                this.Sql.Comando.Append("DT_INCLUSAO, ");
                this.Sql.Comando.Append("UF, ");
                this.Sql.Comando.Append("COD_MUNICIPIO, ");
                this.Sql.Comando.Append("AGENCIA, ");
                this.Sql.Comando.Append("TAXA, ");
                this.Sql.Comando.Append("DT_PAGTO, ");
                this.Sql.Comando.Append("DT_CANCELAMENTO, ");
                this.Sql.Comando.Append("COD_OPERADOR, ");
                this.Sql.Comando.Append("ULT_ATUALIZACAO ");
                this.Sql.Comando.Append("FROM PXC."+NOME_TABELA);
                //Filtra consulta pelos dados informados no TO
                this.MontarWhere(toClientePxc);

                dados = new List<TOEmprestimo>();

                if (toPaginacao == null)
                {
                    //Executa o comando sem utilizar paginação
                    using (ListaConectada listaConectada = this.ListarDados())
                    {
                        //Cria TO para cada tupla retornada
                        while (listaConectada.Ler())
                        {
                            toRetorno = new TOEmprestimo();
                            toRetorno.PopularRetorno(listaConectada.LinhaAtual);
                            dados.Add(toRetorno);
                        }
                    }
                }
                else
                {
                    //Executa o comando utilizando paginação
                    ListaDesconectada listaDesconectada = this.ListarDados(toPaginacao);

                    //Cria TO para cada tupla retornada
                    foreach (Linha linha in listaDesconectada.Linhas)
                    {
                        toRetorno = new TOEmprestimo();
                        toRetorno.PopularRetorno(linha);
                        dados.Add(toRetorno);
                    }
                }

                return this.Infra.RetornarSucesso(dados);
            }    
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<List<TOEmprestimo>>(ex);
            }
        }
    
        /// <summary>Método obter referente à tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOEmprestimo> Obter(TOClientePxc toClientePxc)
        {
            try
            {
                Linha linha;
                TOEmprestimo dados;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear(); 

                //Inicia montagem do comando
                this.Sql.Comando.Append("SELECT ");
                this.Sql.Comando.Append("COD_EMPRESTIMO, ");
                this.Sql.Comando.Append("COD_CLIENTE, ");
                this.Sql.Comando.Append("TIPO_PESSOA, ");
                this.Sql.Comando.Append("VALOR_EMP, ");
                this.Sql.Comando.Append("DT_INCLUSAO, ");
                this.Sql.Comando.Append("UF, ");
                this.Sql.Comando.Append("COD_MUNICIPIO, ");
                this.Sql.Comando.Append("AGENCIA, ");
                this.Sql.Comando.Append("TAXA, ");
                this.Sql.Comando.Append("DT_PAGTO, ");
                this.Sql.Comando.Append("DT_CANCELAMENTO, ");
                this.Sql.Comando.Append("COD_OPERADOR, ");
                this.Sql.Comando.Append("ULT_ATUALIZACAO ");
                this.Sql.Comando.Append("FROM PXC."+NOME_TABELA);
                //Filtra consulta pelos dados informados no TO
                this.MontarWhereChaves(toClientePxc);

                //Executa o comando
                linha = this.ObterDados();
                if (linha == null)
                {
                    return this.Infra.RetornarFalha<TOEmprestimo>(new RegistroInexistenteMensagem());
                }
                
                //Cria TO para a tupla retornada
                dados = new TOEmprestimo();
                dados.PopularRetorno(linha);

                return this.Infra.RetornarSucesso(dados);
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOEmprestimo>(ex);
            }
        }
    
        /// <summary>Monta campos para cláusula WHERE.</summary>
        /// <param name="toClientePxc">TO contendo os campos.</param>
        private void MontarWhere(TOClientePxc toClientePxc)
        {
            //Monta no WHERE todos os campos da tabela que foram informados

            this.MontarWhereChaves(toClientePxc);
            this.MontarCampos(this.Sql.MontarCampoWhere, toClientePxc);
            TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
            this.Sql.MontarCampoWhere("ULT_ATUALIZACAO", toEmprestimo.UltAtualizacao);
        }
        
        /// <summary>Monta campos chave para cláusula WHERE.</summary>
        /// <param name="toClientePxc">TO contendo os campos.</param>
        private void MontarWhereChaves(TOClientePxc toClientePxc)
        {
            //Monta no WHERE todos os campos chave da tabela

            this.MontarCamposChave(this.Sql.MontarCampoWhere, toClientePxc);
        }
        
        /// <summary>Monta campos para cláusula SET.</summary>
        /// <param name="toClientePxc">TO contendo os campos.</param>
        private void MontarSet(TOClientePxc toClientePxc)
        {
            //Monta no SET todos os campos não chave da tabela que foram informados

            this.MontarCampos(this.Sql.MontarCampoSet, toClientePxc);
            this.Sql.MontarCampoSet("ULT_ATUALIZACAO");
            this.Sql.Comando.Append("CURRENT_TIMESTAMP");
        }
        
        /// <summary>Monta campos para cláusula INSERT.</summary>
        /// <param name="toClientePxc">TO contendo os campos.</param>
        private void MontarInsert(TOClientePxc toClientePxc)
        {
            //Monta no INSERT todos os campos da tabela que foram informados

            this.MontarCamposChave(this.Sql.MontarCampoInsert, toClientePxc);
            this.MontarCampos(this.Sql.MontarCampoInsert, toClientePxc);
            this.Sql.MontarCampoInsert("ULT_ATUALIZACAO");
            this.Sql.Temporario.Append("CURRENT_TIMESTAMP");
        }
        
        /// <summary>Executa uma ação nos campos chave de um TO.</summary>
        /// <param name="montagem">Ação a ser executada.</param>
        /// <param name="toClientePxc">TO alvo das ações.</param>
        private void MontarCamposChave(ConstrutorSql.MontarCampo montagem, TOClientePxc toClientePxc)
        {   
            //Invoca qualquer comando simples de montagem nos campos chave da tabela
            TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
            montagem.Invoke("COD_EMPRESTIMO", toEmprestimo.CodEmprestimo);
        }
        
        /// <summary>Executa uma ação nos campos não chave de um TO.</summary>
        /// <param name="montagem">Ação a ser executada.</param>
        /// <param name="toClientePxc">TO alvo das ações.</param>
        private void MontarCampos(ConstrutorSql.MontarCampo montagem, TOClientePxc toClientePxc)
        {   
            //Invoca qualquer comando simples de montagem nos campos não chave da tabela, exceto no que faz controle de acessos concorrentes
            if (toClientePxc.CodCliente.FoiSetado)
            {
                montagem.Invoke("COD_CLIENTE", new CampoObrigatorio<String>(toClientePxc.CodCliente.ToString().PadLeft(14, '0')));
            }
            montagem.Invoke("TIPO_PESSOA", toClientePxc.TipoPessoa);

            TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
            montagem.Invoke("VALOR_EMP", toEmprestimo.ValorEmp);
            montagem.Invoke("DT_INCLUSAO", toEmprestimo.DtInclusao);
            montagem.Invoke("UF", toEmprestimo.Uf);
            montagem.Invoke("COD_MUNICIPIO", toEmprestimo.CodMunicipio);
            montagem.Invoke("AGENCIA", toEmprestimo.Agencia);
            montagem.Invoke("TAXA", toEmprestimo.Taxa);
            montagem.Invoke("DT_PAGTO", toEmprestimo.DtPagto);
            montagem.Invoke("DT_CANCELAMENTO", toEmprestimo.DtCancelamento);
            montagem.Invoke("COD_OPERADOR", toEmprestimo.CodOperador);
        }

        #region Métodos auxiliares
        #region ObterEmprestimo
        /// <summary>Método que obtém o primeiro empréstimo da lista de empréstimos do TOClientePxc.</summary>
        /// <param name="toClientePxc">TO de entrada.</param>
        /// <returns>TOEmprestimo populado.</returns>
        private TOEmprestimo ObterEmprestimo(TOClientePxc toClientePxc)
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();

            if (this.TemEmprestimo(toClientePxc))
            {
                toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];
            }

            return toEmprestimo;
        }
        #endregion
        #region TemEmprestimo
        /// <summary>Método que verifica se há pelo menos um empréstimo na lista de empréstimos do TOClientePxc.</summary>
        /// <param name="toClientePxc">TO de entrada.</param>
        /// <returns>True, se existe empréstimo. False se não existe.</returns>
        private Boolean TemEmprestimo(TOClientePxc toClientePxc)
        {
            return ((toClientePxc.Emprestimos.TemConteudo) && (toClientePxc.Emprestimos.LerConteudoOuPadrao().Count > 0));
        }
        #endregion
        #endregion

        /// <summary>Cria um parâmetro para a instrução SQL.</summary>
        /// <param name="nomeCampo">Nome do campo da tabela.</param>
        /// <param name="conteudo">Valor para o parâmetro.</param>
        /// <returns>Parâmetro recém-criado.</returns>
        protected override Parametro CriarParametro(String nomeCampo, Object conteudo)
        {
            Parametro parametro = new Parametro();
            switch (nomeCampo)
            {   
                #region Chaves Primárias
                case "COD_EMPRESTIMO":
                    parametro.Precision = 7;
                    parametro.Size = 7;
                    parametro.DbType = DbType.Decimal;
                    break;                        
                #endregion

                #region Campos Obrigatórios
                case "COD_CLIENTE":
                    parametro.Precision = 14;
                    parametro.Size = 14;
                    parametro.DbType = DbType.String;
                    break;
                case "TIPO_PESSOA":
                    parametro.Precision = 1;
                    parametro.Size = 1;
                    parametro.DbType = DbType.String;
                    break;
                case "VALOR_EMP":
                    parametro.Precision = 15;
                    parametro.Scale = 2;
                    parametro.Size = 15;
                    parametro.DbType = DbType.Decimal;
                    break;
                case "DT_INCLUSAO":
                    parametro.Precision = 4;
                    parametro.Size = 4;
                    parametro.DbType = DbType.Date;
                    break;
                case "UF":
                    parametro.Precision = 2;
                    parametro.Size = 2;
                    parametro.DbType = DbType.String;
                    break;
                case "COD_MUNICIPIO":
                    parametro.Precision = 7;
                    parametro.Size = 7;
                    parametro.DbType = DbType.String;
                    break;
                case "AGENCIA":
                    parametro.Precision = 2;
                    parametro.Size = 2;
                    parametro.DbType = DbType.Int16;
                    break;
                case "COD_OPERADOR":
                    parametro.Precision = 6;
                    parametro.Size = 6;
                    parametro.DbType = DbType.String;
                    break;
                case "ULT_ATUALIZACAO":
                    parametro.Precision = 10;
                    parametro.Scale = 6;
                    parametro.Size = 10;
                    parametro.DbType = DbType.DateTime;
                    break;
                #endregion

                #region Campos Cliente
                case "DT_ABE_CAD":
                    parametro.Precision = 4;
                    parametro.Size = 4;
                    parametro.DbType = DbType.Date;
                    break;
                case "NOME_CLIENTE":
                    parametro.Precision = 50;
                    parametro.Size = 50;
                    parametro.DbType = DbType.String;
                    break;
                #endregion

                #region Campos Opcionais
                case "TAXA":
                    parametro.Precision = 3;
                    parametro.Scale = 2;
                    parametro.Size = 3;
                    parametro.DbType = DbType.Decimal;
                    break;
                case "DT_PAGTO":
                    parametro.Precision = 4;
                    parametro.Size = 4;
                    parametro.DbType = DbType.Date;
                    break;
                case "DT_CANCELAMENTO":
                    parametro.Precision = 4;
                    parametro.Size = 4;
                    parametro.DbType = DbType.Date;
                    break;

#if DEBUG
                default:
                    //Força um erro em modo debug para alertar o programador caso tenha caido no default
                    //Todo parâmetro deve cair em um case neste switch
                    parametro = null;
                    break;
#endif
                #endregion                

                
            }
            parametro.Direction = ParameterDirection.Input;
            parametro.SourceColumn = nomeCampo;
            
            if (parametro.Scale > 0 && conteudo != null &&  parametro.DbType != DbType.DateTime)
            {
                parametro.Value = String.Format(CultureInfo.InvariantCulture, "{0:F" + parametro.Scale + "}", conteudo);
            }
            else
            {
                parametro.Value = conteudo;
            }
            
            return parametro;
        }
        #endregion
    }
}