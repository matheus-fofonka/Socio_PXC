﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcsclxn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.Tests
{
    ///  <summary>
    /// Contém os métodos de teste da classe Emprestimo.
    /// </summary>
    [TestFixture(Description="Classe de testes para a classe RN Emprestimo.", Author="E30252")]
	public class EmprestimoTests : AbstractTesteRegraNegocio<Emprestimo>
	{

        #region PopularTOEmprestimo
        /// <summary>Retorna o primeiro TOSocio da lista de Sócios do TOCliente ou um TO vazio.</summary>
        /// <param name="toCliente"></param>
        /// <returns>TOSocio populado.</returns>
        private TOEmprestimo PopularTOEmprestimo(TOClientePxc toCliente)
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();

            if ((toCliente.Emprestimos.TemConteudo) && (toCliente.Emprestimos.LerConteudoOuPadrao().Count > 0))
            {
                toEmprestimo = toCliente.Emprestimos.LerConteudoOuPadrao()[0];
            }

            return toEmprestimo;
        }
        #endregion
        #region Métodos de preparação dos testes
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
		{
		}
		///  <summary>
		/// Executa uma ação ANTES de cada método de teste da classe.
		/// </summary>
		protected override void BeforeEach()
		{
		}
		///  <summary>
		/// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
		/// </summary>
		protected override void AfterAll()
		{
		}
		///  <summary>
		/// Executa uma ação DEPOIS de cada método de teste da classe.
		/// </summary>
		protected override void AfterEach()
		{
		}
		///  <summary>
		/// Método para setar os dados necessários para conexão com o PHA no servidor de build.
		/// </summary>
		/// <returns>TO com dados necessários para conexão no servidor de build.</returns>
		protected override TOPhaServidorBuild SetarDadosServidorBuild()
		{
			return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
		}
		#endregion

		#region Métodos de teste de sucesso.
		///  <summary>
		/// Realiza o teste padrão para o método Alterar(TOClientePxc).
		/// Validações realizadas: 
		/// - Altera o registro na base, conforme os dados informados.
		/// - Verifica se o retorno do método Alterar foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// - Obtém o TO novamente da base, utilizando o método Obter.
		/// - Compara o retorno do Obter com os dados do TO preenchido.
		/// </summary>
		[Test(Description="Testa o método Alterar(TOClientePxc).", Author="E30252")]
		public void AlterarComSucessoTest()
		{
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "Erro: {0}", retIncluir.Mensagem.ParaOperador);

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "Não obteve");

            TOEmprestimo toFiltro = new TOEmprestimo();
            toFiltro.CodEmprestimo = retObter.Dados.CodEmprestimo;
            toFiltro.UltAtualizacao = retObter.Dados.UltAtualizacao;
            toCliente.Emprestimos.LerConteudoOuPadrao()[0] = toFiltro;

            Retorno<Int32> retAlterar = this.RN.Alterar(toCliente);
            MMAssert.IsTrue(retAlterar.OK, "Erro: {0}", retAlterar.Mensagem.ParaOperador);
        }
		///  <summary>
		/// Realiza o teste padrão para o método Contar(TOClientePxc).
		/// Validações realizadas: 
		/// - Chama o Contar usando os filtros informados.
		/// - Verifica se o retorno do método Contar foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// 4 - Retorno.Dados não é zero.
		/// 
		/// </summary>
		[Test(Description="Testa o método Contar(TOClientePxc).", Author="E30252")]
		public void ContarComSucessoTest()
		{
			TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "10073";
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            
            TOEmprestimo toEmprestimo = this.PopularTOEmprestimo(toCliente);
            toEmprestimo.ValorEmp = Convert.ToDecimal(14520);

            Retorno<Int64> retContar = this.RN.Contar(toCliente);
            MMAssert.IsTrue(retContar.OK);
        }
        ///  <summary>
        /// Realiza o teste padrão para o método Excluir(TOClientePxc).
        /// Validações realizadas: 
        /// - Exclui o registro na base, conforme a chave informada.
        /// - Verifica se o retorno do método Excluir foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Tenta obter o registro novamente da base, através do método Obter.
        /// - Verifica se o registro não existe mais.
        /// </summary>
        [Test(Description="Testa o método Excluir(TOClientePxc).", Author="E30252")]
		public void ExcluirComSucessoTest()
		{
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 00001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;
            toEmprestimo.UltAtualizacao = new System.DateTime();

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "não incluiu");

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "Não obteve");            

            Retorno<Int32> retExcluir = this.RN.Excluir(toCliente);
            MMAssert.IsTrue(retExcluir.OK, "Erro: {0}", retExcluir.Mensagem.ParaOperador);
        }
        ///  <summary>
        /// Realiza o teste padrão para o método Incluir(TOClientePxc).
        /// Validações realizadas: 
        /// - Chama o método Incluir usando os filtros informados.
        /// - Verifica se o retorno do método Incluir foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Obtém o TO novamente da base, utilizando o método Obter.
        /// - Compara o retorno do Obter com os dados do TO preenchido.
        /// </summary>
        [Test(Description="Testa o método Incluir(TOClientePxc).", Author="E30252")]
		public void IncluirComSucessoTest()
		{
            //Instânciar RN de outro projeto (Preciso adicionar referência antes)
            Pxcsclxn.ClientePxc rnCliente = this.Infra.InstanciarRN<Pxcsclxn.ClientePxc>();

            TOClientePxc toCliente = new TOClientePxc();
            // TODO: Setar os valores necessários para o toCliente
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;
            toCliente.DtAbeCad = new System.DateTime();
            toCliente.NomeCliente = "Banrisul SA";
            toCliente.UltAtualizacao = new System.DateTime();
            toCliente.NomeFantasia = "Banco Regional";
            toCliente.DtConstituicao = new System.DateTime();
            toCliente.VlrCapitalSocial = 1500;
            toCliente.CodOperador = "30252";

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 00001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
            
            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "não incluiu");

        }
		///  <summary>
		/// Realiza o teste padrão para o método Listar(TOClientePxc, TOPaginacao).
		/// Validações realizadas: 
		/// - Chama o Listar usando os filtros informados.
		/// - Verifica se o retorno do método Listar foi de sucesso
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// 4 - Retorno.Dados possui elementos.
		/// - Compara o retorno com os dados da lista de TO preenchida antes do teste.
		/// </summary>
		[Test(Description="Testa o método Listar(TOClientePxc, TOPaginacao).", Author="E30252")]
		public void ListarComSucessoTest()
		{
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 00001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            base.TestarIncluir<TOClientePxc, TOEmprestimo>(toCliente);

            Retorno<List<TOEmprestimo>> retObter = this.RN.Listar(toCliente, null);
            MMAssert.IsTrue(retObter.OK, "não obteve");
        }
		///  <summary>
		/// Realiza o teste padrão para o método Obter(TOClientePxc).
		/// Validações realizadas: 
		/// - Chama o método Obter usando os filtros de chave informados.
		/// - Verifica se o retorno do método Obter foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
		/// </summary>
		[Test(Description="Testa o método Obter(TOClientePxc).", Author="E30252")]
		public void ObterComSucessoTest()
		{
            //Instânciar RN de outro projeto (Preciso adicionar referência antes)
            Pxcsclxn.ClientePxc rnCliente = this.Infra.InstanciarRN<Pxcsclxn.ClientePxc>();

            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 00001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            base.TestarIncluir<TOClientePxc, TOEmprestimo>(toCliente);

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "não obteve");
        }
		///  <summary>
		/// Realiza um teste para o método ListarCidades.
		/// </summary>
		[Test(Description="Testa o método ListarCidades(TOBnjtmul).", Author="E30252")]
		public void ListarCidadesComSucessoTest()
		{
			TOBnjtmul toBnjtmul = new TOBnjtmul();
            toBnjtmul.CodMunici = "4312458";
            toBnjtmul.Uf = "RS";
            toBnjtmul.Municipio = "Porto Alegre";
            Retorno<List<TOBnjtmul>> retorno = this.RN.ListarCidades(toBnjtmul);
			MMAssert.Sucesso(retorno);
			// TODO: Incluir as Assertivas necessárias para o ListarCidades
		}
		///  <summary>
		/// Realiza um teste para o método Cancelar.
		/// </summary>
		[Test(Description="Testa o método Cancelar(TOClientePxc).", Author="E30252")]
		public void CancelarComSucessoTest()
		{
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "Erro: {0}", retIncluir.Mensagem.ParaOperador);

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "Não obteve");

            TOEmprestimo toFiltro = new TOEmprestimo();
            toFiltro.CodEmprestimo = retObter.Dados.CodEmprestimo;
            toFiltro.UltAtualizacao = retObter.Dados.UltAtualizacao;
            toCliente.Emprestimos.LerConteudoOuPadrao()[0] = toFiltro;

            Retorno<Int32> retCancelar = this.RN.Cancelar(toCliente);
            MMAssert.IsTrue(retCancelar.OK, "Erro: {0}", retCancelar.Mensagem.ParaOperador);
        }
		///  <summary>
		/// Realiza um teste para o método Pagar.
		/// </summary>
		[Test(Description="Testa o método Pagar(TOClientePxc).", Author="E30252")]
		public void PagarComSucessoTest()
		{
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "Erro: {0}", retIncluir.Mensagem.ParaOperador);

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "Não obteve");

            TOEmprestimo toFiltro = new TOEmprestimo();
            toFiltro.CodEmprestimo = retObter.Dados.CodEmprestimo;
            toFiltro.UltAtualizacao = retObter.Dados.UltAtualizacao;
            toCliente.Emprestimos.LerConteudoOuPadrao()[0] = toFiltro;

            Retorno<Int32> retPagar = this.RN.Pagar(toCliente);
            MMAssert.IsTrue(retPagar.OK, "Erro: {0}", retPagar.Mensagem.ParaOperador);
        }
		#endregion

		#region Testes Regras de Negócio
        ///  <summary>
		/// Realiza um teste para o método Obter com teste de falha.
		/// </summary>
		[Test(Description = "Testa o método Obter(TOClientePxc).", Author = "E30252")]
        public void TesteRN01()
        {
            TOClientePxc toCliente = new TOClientePxc();
            // TODO: Setar os valores necessários para o toCliente
            toCliente.CodCliente = "10073";
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            

            TOEmprestimo toEmprestimo = new TOEmprestimo();

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsFalse(retIncluir.OK);
            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo); 
                       
            // TODO: Incluir as Assertivas necessárias para o Obter
        }
        /// <summary>
        /// 
        /// </summary>
        [Test(Description = "teste das rn")]
        public void TesteRN02()
        {
            //Instânciar RN de outro projeto (Preciso adicionar referência antes)
            Pxcsclxn.ClientePxc rnCliente = this.Infra.InstanciarRN<Pxcsclxn.ClientePxc>();

            TOClientePxc toCliente = new TOClientePxc();
            // TODO: Setar os valores necessários para o toCliente
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 0100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = DateTime.Parse("21/01/2222");
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsFalse(retIncluir.OK, "incluiu");
        }
        /// <summary>
        /// 
        /// </summary>
        [Test(Description = "teste das rn")]
        public void TesteRN03()
        {
            //Instânciar RN de outro projeto (Preciso adicionar referência antes)
            Pxcsclxn.ClientePxc rnCliente = this.Infra.InstanciarRN<Pxcsclxn.ClientePxc>();

            TOClientePxc toCliente = new TOClientePxc();
            // TODO: Setar os valores necessários para o toCliente
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 0100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 152;
            toEmprestimo.ValorEmp = Convert.ToDecimal(1000000000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.Agencia = toCliente.Agencia;
            toEmprestimo.CodMunicipio = "4325460";

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsFalse(retIncluir.OK, "incluiu");
            MMAssert.AreEqual("O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.", retIncluir.Mensagem.ParaOperador);
        }
        /// <summary>
        /// 
        /// </summary>
        [Test(Description = "teste das rn")]
        public void TesteRN03_1([Values(-1, 0, 0.5, 0.99, 11.0, 10.01)] decimal taxa)
        {
            //Instânciar RN de outro projeto (Preciso adicionar referência antes)
            Pxcsclxn.ClientePxc rnCliente = this.Infra.InstanciarRN<Pxcsclxn.ClientePxc>();

            TOClientePxc toCliente = new TOClientePxc();
            // TODO: Setar os valores necessários para o toCliente
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 0100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Taxa = taxa;
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsFalse(retIncluir.OK, "incluiu");
        }
        /// <summary>
        /// 
        /// </summary>
        [Test(Description = "teste das rn")]
        public void TesteRN04()
        {
            //Instânciar RN de outro projeto (Preciso adicionar referência antes)
            Pxcsclxn.ClientePxc rnCliente = this.Infra.InstanciarRN<Pxcsclxn.ClientePxc>();

            TOClientePxc toCliente = new TOClientePxc();
            // TODO: Setar os valores necessários para o toCliente
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 0100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 0122;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "sp";
            toEmprestimo.Agencia = toCliente.Agencia;
            toEmprestimo.CodMunicipio = "4325460";

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsFalse(retIncluir.OK, "incluiu");
            MMAssert.AreEqual("São aceitas somente as UFs da região Sul do país.", retIncluir.Mensagem.ParaOperador);
        }
        /// <summary>
        /// 
        /// </summary>
        [Test(Description = "teste das rn")]
        public void TesteRN07()
        {
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;
            toEmprestimo.UltAtualizacao = new System.DateTime();
            toEmprestimo.DtCancelamento = DateTime.Parse("21/08/2025");

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "Erro: {0}", retIncluir.Mensagem.ParaOperador);

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "Não obteve");

            TOEmprestimo toFiltro = new TOEmprestimo();
            toFiltro.CodEmprestimo = retObter.Dados.CodEmprestimo;
            toFiltro.UltAtualizacao = retObter.Dados.UltAtualizacao;
            toFiltro.DtInclusao = retObter.Dados.DtInclusao;
            toFiltro.DtCancelamento = retObter.Dados.DtCancelamento;
            toCliente.Emprestimos.LerConteudoOuPadrao()[0] = toFiltro;

            Retorno<Int32> retCancelar = this.RN.Cancelar(toCliente);
            MMAssert.IsFalse(retCancelar.OK, "Erro: {0}", retCancelar.Mensagem.ParaOperador);
            MMAssert.AreEqual("Só é possível cancelar empréstimo ativo.", retCancelar.Mensagem.ParaOperador);
        }
        /// <summary>
        /// 
        /// </summary>
        [Test(Description = "teste das rn")]
        public void TesteRN07_1()
        {
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;
            toEmprestimo.UltAtualizacao = new System.DateTime();
            toEmprestimo.DtCancelamento = DateTime.Parse("21/08/2025");

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "Erro: {0}", retIncluir.Mensagem.ParaOperador);

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "Não obteve");

            TOEmprestimo toFiltro = new TOEmprestimo();
            toFiltro.CodEmprestimo = retObter.Dados.CodEmprestimo;
            toFiltro.UltAtualizacao = retObter.Dados.UltAtualizacao;
            toFiltro.DtInclusao = retObter.Dados.DtInclusao;
            toFiltro.DtCancelamento = retObter.Dados.DtCancelamento;
            toCliente.Emprestimos.LerConteudoOuPadrao()[0] = toFiltro;

            Retorno<Int32> retPagar = this.RN.Pagar(toCliente);
            MMAssert.IsFalse(retPagar.OK, "Erro: {0}", retPagar.Mensagem.ParaOperador);
            MMAssert.AreEqual("Só é possível pagar empréstimo ativo.", retPagar.Mensagem.ParaOperador);
        }
        ///  <summary>
        /// Realiza o teste padrão para o método Excluir(TOClientePxc).
        /// </summary>
        [Test(Description = "Testa o método Excluir(TOClientePxc).", Author = "E30252")]
        public void TesteRN07_3()
        {
            TOClientePxc toCliente = new TOClientePxc();
            toCliente.CodCliente = "191".PadLeft(14, '0');
            toCliente.TipoPessoa = TipoPessoa.Juridica;
            toCliente.Agencia = 100;

            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodEmprestimo = 00001;
            toEmprestimo.ValorEmp = Convert.ToDecimal(10000);
            toEmprestimo.DtInclusao = new System.DateTime();
            toEmprestimo.Uf = "rs";
            toEmprestimo.CodMunicipio = "4325460";
            toEmprestimo.Agencia = toCliente.Agencia;

            toCliente.Emprestimos = new List<TOEmprestimo>();
            toCliente.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<Int32> retIncluir = this.RN.Incluir(toCliente);
            MMAssert.IsTrue(retIncluir.OK, "não incluiu");

            Retorno<TOEmprestimo> retObter = this.RN.Obter(toCliente);
            MMAssert.IsTrue(retObter.OK, "Não obteve");

            TOEmprestimo toFiltro = new TOEmprestimo();
            toFiltro.CodEmprestimo = retObter.Dados.CodEmprestimo;
            toFiltro.UltAtualizacao = retObter.Dados.UltAtualizacao;
            toFiltro.DtInclusao = retObter.Dados.DtInclusao;
            toCliente.Emprestimos.LerConteudoOuPadrao()[0] = toFiltro;

            Retorno<Int32> retExcluir = this.RN.Excluir(toCliente);
            MMAssert.IsFalse(retExcluir.OK, "Erro: {0}", retExcluir.Mensagem.ParaOperador);
            MMAssert.AreEqual("Só é possível excluir empréstimo pago ou cancelado.", retExcluir.Mensagem.ParaOperador);
        }
        #endregion
    }
}

