﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using Bergs.Pxc.Pxcszzxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{

    ///  <summary>
    /// Contém os métodos de teste da classe Emprestimo.
    /// </summary>
    [TestFixture(Description = "Classe de testes para a classe RN Emprestimo.", Author = "B36649")]
    public class G_07_Alterar : AbstractTesteRegraNegocio<Emprestimo>
    {
        #region Métodos de preparação dos testes
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Senão existe, inclui o cliente
            Retorno<TOClientePxc> obtencaoCliente;
            Retorno<Int32> inclusaoCliente;

            #region Fisica_ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCpfZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCpfZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Fisica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcFisica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcFisica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCnpjZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCnpjZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcJuridica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcJuridica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Inclui empréstimos (se der registro duplicado, mude o número do seu empréstimo (pode ser coincidência))
            Retorno<Int32> inclusaoEmprestimo;

            #region Popula empréstimos para os clientes e inclui o empréstimo
            String MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO = "Erro no BEFORE ALL!\nIncluir Empréstimo {0} para Cliente {1}.\nMensagem: {2}";
            #region Cliente Fisica_ZEROS
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO01) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO01.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO02) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO02.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Fisica
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO03) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO03.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO04) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO04.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO05) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO05.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica ZEROS
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO06) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO06.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO07) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO07.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO08) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO08.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO09) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO09.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO10) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO10.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO11) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO11.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO12) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO12.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO13) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO13.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO14) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO14.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO15) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO15.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #endregion
            #endregion
        }
        ///  <summary>
        /// Executa uma ação ANTES de cada método de teste da classe.
        /// </summary>
        protected override void BeforeEach()
        {
        }
        ///  <summary>
        /// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
        /// </summary>
        protected override void AfterAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Exclui os clientes
            Retorno<Int32> exclusaoClientes;

            #region Fisica_ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Fisica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #endregion

        }
        ///  <summary>
        /// Executa uma ação DEPOIS de cada método de teste da classe.
        /// </summary>
        protected override void AfterEach()
        {
        }
        ///  <summary>
        /// Método para setar os dados necessários para conexão com o PHA no servidor de build.
        /// </summary>
        /// <returns>TO com dados necessários para conexão no servidor de build.</returns>
        protected override TOPhaServidorBuild SetarDadosServidorBuild()
        {
            return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
        }
        #endregion
        #region Métodos Popular
        #region PopularTOClientePxc
        private TOClientePxc PopularTOClientePxc(String sCodCliente, TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = sCodCliente;
            toClientePxc.TipoPessoa = tipoPessoa;

            toClientePxc.Agencia = 100;
            toClientePxc.NomeCliente = "TESTES TESTADOR";

            return toClientePxc;
        }
        #endregion
        #region PopularTOEmprestimo
        /// <summary>Popula TOEmprestimo com alguns valores defaults.</summary>
        /// <param name="codEmprestimo">PK.</param>
        /// <param name="iAgencia">Agencia (default 0100)</param>
        /// <param name="sUF">UF (default RS)</param>
        /// <param name="sCodMunicipio">Cidade (default 4312345)</param>
        /// <param name="dValorEmp">Valor do Empréstimo (default 6.666,99)</param>
        /// <returns>TOEmprestimo populado.</returns>
        private TOEmprestimo PopularTOEmprestimo(Int32 codEmprestimo, Int16 iAgencia = 100, String sUF = "RS", String sCodMunicipio = "4312345", Decimal dValorEmp = 6666.99M)
        {
            return new TOEmprestimo()
            {
                CodEmprestimo = codEmprestimo,
                Agencia = iAgencia,
                Uf = sUF,
                CodMunicipio = sCodMunicipio,
                ValorEmp = dValorEmp
            };
        }
        #endregion
        #region PopularTOClientePxcCompleto
        private TOClientePxc PopularTOClientePxcCompleto()
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = VariaveisGlobais.CPF_CLI_ZEROS;
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            List<TOEmprestimo> emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo()
            {
                CodEmprestimo = VariaveisGlobais.EMPRESTIMO01,
                UltAtualizacao = DateTime.Now,
            };
            emprestimos.Add(toEmprestimo);
            toClientePxc.Emprestimos = emprestimos;

            return toClientePxc;
        }
        #endregion
        #endregion
        #region Métodos de teste de sucesso.
        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g01_Alterar_SemNada()
        {
            Retorno<Int32> alteracao = this.RN.Alterar(new TOClientePxc());
            MMAssert.IsFalse(alteracao.OK, "Deveria morrer em regra de campo obrigatório.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g02_Alterar_SemCodCliente()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.CodCliente = new CampoObrigatorio<String>();

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.FalhaCampoObrigatorio(alteracao, "COD_CLIENTE");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g03_Alterar_SemTipoPessoa()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.TipoPessoa = new CampoObrigatorio<TipoPessoa>();

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.FalhaCampoObrigatorio(alteracao, "TIPO_PESSOA");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g04_Alterar_SemEmprestimo()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos = new CampoOpcional<List<TOEmprestimo>>();

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.FalhaCampoObrigatorio(alteracao, "EMPRÉSTIMO");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g05_Alterar_Emprestimo_NULL()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos = new CampoOpcional<List<TOEmprestimo>>(null);

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.FalhaCampoObrigatorio(alteracao, "EMPRÉSTIMO");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g06_Alterar_SemCodEmprestimo()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = new CampoObrigatorio<Decimal>();

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.FalhaCampoObrigatorio(alteracao, "COD_EMPRESTIMO");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g07_Alterar_SemUltAtualizacao()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = new CampoObrigatorio<DateTime>();

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.FalhaCampoObrigatorio(alteracao, "ULT_ATUALIZACAO");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g08_Alterar_SAC()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.IsFalse(alteracao.OK);
            MMAssert.FalhaComMensagem<Mensagem>(alteracao, (new ConcorrenciaMensagem()).Identificador, (new ConcorrenciaMensagem()).ParaOperador);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g09_Alterar_Sucesso_F()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();

            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = 1;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].ValorEmp = 5000;

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.IsTrue(alteracao.OK);

            // obtém de novo o registro
            obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK);

            // compara dados alterados
            MMAssert.AreEqual(1, obtencao.Dados.Taxa.LerConteudoOuPadrao());
            MMAssert.AreEqual(5000, obtencao.Dados.ValorEmp.LerConteudoOuPadrao());
            MMAssert.AreNotEqual(toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao.LerConteudoOuPadrao(), obtencao.Dados.UltAtualizacao.LerConteudoOuPadrao());
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Alterar.", Author = "B36649")]
        public void g10_Alterar_Sucesso_J()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF;
            toClientePxc.TipoPessoa = TipoPessoa.Juridica;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO07;

            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = 2;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].ValorEmp = 7070;

            Retorno<Int32> alteracao = this.RN.Alterar(toClientePxc);
            MMAssert.IsTrue(alteracao.OK);

            // obtém de novo o registro
            obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK);

            // compara dados alterados
            MMAssert.AreEqual(2, obtencao.Dados.Taxa.LerConteudoOuPadrao());
            MMAssert.AreEqual(7070, obtencao.Dados.ValorEmp.LerConteudoOuPadrao());
            MMAssert.AreNotEqual(toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao.LerConteudoOuPadrao(), obtencao.Dados.UltAtualizacao.LerConteudoOuPadrao());
        }
        #endregion
    }
}

