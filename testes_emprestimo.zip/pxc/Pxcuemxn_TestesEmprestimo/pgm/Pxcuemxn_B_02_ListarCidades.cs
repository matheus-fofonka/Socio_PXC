﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{
	
	///  <summary>
	/// Contém os métodos de teste da classe Emprestimo.
	/// </summary>
	[TestFixture(Description="Classe de testes para a classe RN Emprestimo.", Author="B36649")]
	public class B_02_ListarCidades : AbstractTesteRegraNegocio<Emprestimo>
	{
		#region Métodos de preparação dos testes
		///  <summary>
		/// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
		/// </summary>
		protected override void BeforeAll()
		{
		}
		///  <summary>
		/// Executa uma ação ANTES de cada método de teste da classe.
		/// </summary>
		protected override void BeforeEach()
		{
		}
		///  <summary>
		/// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
		/// </summary>
		protected override void AfterAll()
		{
		}
		///  <summary>
		/// Executa uma ação DEPOIS de cada método de teste da classe.
		/// </summary>
		protected override void AfterEach()
		{
		}
		///  <summary>
		/// Método para setar os dados necessários para conexão com o PHA no servidor de build.
		/// </summary>
		/// <returns>TO com dados necessários para conexão no servidor de build.</returns>
		protected override TOPhaServidorBuild SetarDadosServidorBuild()
		{
			return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
		}
		#endregion
		#region Métodos de teste de sucesso.
        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método ListarCidades.", Author = "B36649")]
        public void b01_ListarCidades_SemNada()
        {
            Retorno<List<TOBnjtmul>> listagemCidades = this.RN.ListarCidades(new TOBnjtmul());
            MMAssert.IsFalse(listagemCidades.OK, "Deveria morrer em regra de negócio de UF não informado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método ListarCidades.", Author = "B36649")]
        public void b02_ListarCidades_UF_TamanhoDiferente2([Values("A", "BCC", "DEFG", "ERRADO", "MUITO ERRADO")] String sUf)
        {
            TOBnjtmul toBnjtmul = new TOBnjtmul();
            toBnjtmul.Uf = sUf;
            Retorno<List<TOBnjtmul>> listagemCidades = this.RN.ListarCidades(toBnjtmul);
            MMAssert.IsFalse(listagemCidades.OK, "Deveria morrer em regra de negócio de UF não informado (qualquer UF com tamanho diferente de 2 cai nesse erro).");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método ListarCidades.", Author = "B36649")]
        public void b03_ListarCidades_UF_Inexistentes([Values("AJ", "11", "BB", "ZZ", "G1")] String sUf)
        {
            TOBnjtmul toBnjtmul = new TOBnjtmul();
            toBnjtmul.Uf = sUf;
            Retorno<List<TOBnjtmul>> listagemCidades = this.RN.ListarCidades(toBnjtmul);
            MMAssert.IsFalse(listagemCidades.OK, "Deveria morrer em registro não encontrado (UFs inexistentes).");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método ListarCidades.", Author = "B36649")]
        public void b04_ListarCidades_UF_Existentes([Values("RS", "SC")] String sUf)
        {
            TOBnjtmul toBnjtmul = new TOBnjtmul();
            toBnjtmul.Uf = sUf;
            Retorno<List<TOBnjtmul>> listagemCidades = this.RN.ListarCidades(toBnjtmul);
            MMAssert.IsTrue(listagemCidades.OK, "Deveria dar sucesso.");
            MMAssert.Greater(listagemCidades.Dados.Count, 0, "Como são UFs válidas, deveria vir PELO MENOS um município.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método ListarCidades.", Author = "B36649")]
        public void b05_ListarCidades_UF_Existentes_Minúsculo([Values("pr", "am")] String sUf)
        {
            TOBnjtmul toBnjtmul = new TOBnjtmul();
            toBnjtmul.Uf = sUf;
            Retorno<List<TOBnjtmul>> listagemCidades = this.RN.ListarCidades(toBnjtmul);
            MMAssert.IsTrue(listagemCidades.OK, "Deveria dar sucesso.");
            MMAssert.Greater(listagemCidades.Dados.Count, 0, "Como são UFs válidas, deveria vir PELO MENOS um município.");
        }
		#endregion
	}
}

