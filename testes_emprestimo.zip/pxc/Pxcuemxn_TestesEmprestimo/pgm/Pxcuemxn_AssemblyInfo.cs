﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(false)]
[assembly: AssemblyTitle("Pxcuemxn.Test")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcuemxn.Test")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2020")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("0bc6020e-b129-4273-a9b7-3de1833bf680")]