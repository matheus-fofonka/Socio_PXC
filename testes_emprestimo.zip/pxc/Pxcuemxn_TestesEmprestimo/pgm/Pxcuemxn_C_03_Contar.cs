﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using Bergs.Pxc.Pxcszzxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{

    ///  <summary>
    /// Contém os métodos de teste da classe Emprestimo.
    /// </summary>
    [TestFixture(Description = "Classe de testes para a classe RN Emprestimo.", Author = "B36649")]
    public class C_03_Contar : AbstractTesteRegraNegocio<Emprestimo>
    {
        #region Métodos de preparação dos testes
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Senão existe, inclui o cliente
            Retorno<TOClientePxc> obtencaoCliente;
            Retorno<Int32> inclusaoCliente;

            #region Fisica_ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCpfZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCpfZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Fisica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcFisica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcFisica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCnpjZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCnpjZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcJuridica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcJuridica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Inclui empréstimos (se der registro duplicado, mude o número do seu empréstimo (pode ser coincidência))
            Retorno<Int32> inclusaoEmprestimo;

            #region Popula empréstimos para os clientes e inclui o empréstimo
            String MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO = "Erro no BEFORE ALL!\nIncluir Empréstimo {0} para Cliente {1}.\nMensagem: {2}";
            #region Cliente Fisica_ZEROS
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO01) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO01.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO02) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO02.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Fisica
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO03) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO03.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO04) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO04.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO05) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO05.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica ZEROS
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO06) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO06.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO07) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO07.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO08) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO08.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO09) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO09.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO10) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO10.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO11) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO11.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO12) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO12.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO13) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO13.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO14) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO14.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO15) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO15.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #endregion
            #endregion
        }
        ///  <summary>
        /// Executa uma ação ANTES de cada método de teste da classe.
        /// </summary>
        protected override void BeforeEach()
        {
        }
        ///  <summary>
        /// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
        /// </summary>
        protected override void AfterAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Exclui os clientes
            Retorno<Int32> exclusaoClientes;

            #region Fisica_ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Fisica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #endregion

        }
        ///  <summary>
        /// Executa uma ação DEPOIS de cada método de teste da classe.
        /// </summary>
        protected override void AfterEach()
        {
        }
        ///  <summary>
        /// Método para setar os dados necessários para conexão com o PHA no servidor de build.
        /// </summary>
        /// <returns>TO com dados necessários para conexão no servidor de build.</returns>
        protected override TOPhaServidorBuild SetarDadosServidorBuild()
        {
            return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
        }
        #endregion
        #region Métodos Popular
        #region PopularTOClientePxc
        private TOClientePxc PopularTOClientePxc(String sCodCliente, TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = sCodCliente;
            toClientePxc.TipoPessoa = tipoPessoa;

            toClientePxc.Agencia = 100;
            toClientePxc.NomeCliente = "TESTES TESTADOR";

            return toClientePxc;
        }
        #endregion
        #region PopularTOEmprestimo
        /// <summary>Popula TOEmprestimo com alguns valores defaults.</summary>
        /// <param name="codEmprestimo">PK.</param>
        /// <param name="iAgencia">Agencia (default 0100)</param>
        /// <param name="sUF">UF (default RS)</param>
        /// <param name="sCodMunicipio">Cidade (default 4312345)</param>
        /// <param name="dValorEmp">Valor do Empréstimo (default 6.666,99)</param>
        /// <returns>TOEmprestimo populado.</returns>
        private TOEmprestimo PopularTOEmprestimo(Int32 codEmprestimo, Int16 iAgencia = 100, String sUF = "RS", String sCodMunicipio = "4312345", Decimal dValorEmp = 6666.99M)
        {
            return new TOEmprestimo()
            {
                CodEmprestimo = codEmprestimo,
                Agencia = iAgencia,
                Uf = sUF,
                CodMunicipio = sCodMunicipio,
                ValorEmp = dValorEmp
            };
        }
        #endregion
        #endregion
        #region Métodos de teste de sucesso.
        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c01_Contar_SemNada()
        {
            Retorno<Int64> contagem = this.RN.Contar(new TOClientePxc());
            MMAssert.IsFalse(contagem.OK, "Deveria morrer em regra de campo obrigatório.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c02_Contar_SemTipoPessoa()
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = "1"
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(contagem, "", "Campo TIPO_PESSOA não foi informado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c03_Contar_SemCodCliente([Values] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                TipoPessoa = tipoPessoa
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(contagem, "", "Campo COD_CLIENTE não foi informado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c04_Contar_ZERO_Registros([Values] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = "999666999",
                TipoPessoa = tipoPessoa
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            MMAssert.AreEqual(0, contagem.Dados, "Estou testando se veio zero registros.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c05_Contar_SemEnviarEmprestimos_F([Values(VariaveisGlobais.CPF_CLI_ZEROS, VariaveisGlobais.CPF_CLI_COMPLETO)] String sCodCliente)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Fisica,
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c06_Contar_SemEnviarEmprestimos_J([Values(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, VariaveisGlobais.CNPJ_CLI_COMPLETO)] String sCodCliente)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Juridica,
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c07_Contar_Emprestimos_NULL_F([Values(VariaveisGlobais.CPF_CLI_ZEROS, VariaveisGlobais.CPF_CLI_COMPLETO)] String sCodCliente)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Fisica,
                Emprestimos = new CampoOpcional<List<TOEmprestimo>>(null),
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c08_Contar_Emprestimos_NULL_J([Values(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, VariaveisGlobais.CNPJ_CLI_COMPLETO)] String sCodCliente)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Juridica,
                Emprestimos = new CampoOpcional<List<TOEmprestimo>>(null),
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c09_Contar_Quantidades_F([Values(VariaveisGlobais.CPF_CLI_ZEROS, VariaveisGlobais.CPF_CLI_COMPLETO)] String sCodCliente)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Fisica,
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            switch (sCodCliente)
            {
                case VariaveisGlobais.CPF_CLI_ZEROS:
                    MMAssert.AreEqual(2, contagem.Dados);
                    break;
                case VariaveisGlobais.CPF_CLI_COMPLETO:
                    MMAssert.AreEqual(3, contagem.Dados);
                    break;
                default:
                    break;
            }
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c10_Contar_Quantidades_J([Values(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, VariaveisGlobais.CNPJ_CLI_COMPLETO)] String sCodCliente)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Juridica,
            };
            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            switch (sCodCliente)
            {
                case VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF:
                    MMAssert.AreEqual(4, contagem.Dados);
                    break;
                case VariaveisGlobais.CNPJ_CLI_COMPLETO:
                    MMAssert.AreEqual(6, contagem.Dados);
                    break;
                default:
                    break;
            }
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c11_Contar_Filtro_CodEmprestimo_F([Values(VariaveisGlobais.CPF_CLI_ZEROS, VariaveisGlobais.CPF_CLI_COMPLETO)] String sCodCliente,
                                                      [Values(VariaveisGlobais.EMPRESTIMO01, VariaveisGlobais.EMPRESTIMO03, VariaveisGlobais.EMPRESTIMO15)] Int32 iCodEmprestimo)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Fisica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(iCodEmprestimo) };

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            switch (sCodCliente)
            {
                case VariaveisGlobais.CPF_CLI_ZEROS:
                    switch (iCodEmprestimo)
                    {
                        case VariaveisGlobais.EMPRESTIMO01:
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case VariaveisGlobais.EMPRESTIMO03:
                        case VariaveisGlobais.EMPRESTIMO15:
                            MMAssert.AreEqual(0, contagem.Dados);
                            break;
                        default:
                            break;
                    }
                    break;
                case VariaveisGlobais.CPF_CLI_COMPLETO:
                    switch (iCodEmprestimo)
                    {
                        case VariaveisGlobais.EMPRESTIMO03:
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case VariaveisGlobais.EMPRESTIMO01:
                        case VariaveisGlobais.EMPRESTIMO15:
                            MMAssert.AreEqual(0, contagem.Dados);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c12_Contar_Filtro_CodEmprestimo_J([Values(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, VariaveisGlobais.CNPJ_CLI_COMPLETO)] String sCodCliente,
                                                      [Values(VariaveisGlobais.EMPRESTIMO01, VariaveisGlobais.EMPRESTIMO06, VariaveisGlobais.EMPRESTIMO14)] Int32 iCodEmprestimo)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Juridica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(iCodEmprestimo) };

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            switch (sCodCliente)
            {
                case VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF:
                    switch (iCodEmprestimo)
                    {
                        case VariaveisGlobais.EMPRESTIMO06:
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case VariaveisGlobais.EMPRESTIMO01:
                        case VariaveisGlobais.EMPRESTIMO14:
                            MMAssert.AreEqual(0, contagem.Dados);
                            break;
                        default:
                            break;
                    }
                    break;
                case VariaveisGlobais.CNPJ_CLI_COMPLETO:
                    switch (iCodEmprestimo)
                    {
                        case VariaveisGlobais.EMPRESTIMO14:
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case VariaveisGlobais.EMPRESTIMO01:
                        case VariaveisGlobais.EMPRESTIMO06:
                            MMAssert.AreEqual(0, contagem.Dados);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c13_Contar_Filtro_UF_F([Values(VariaveisGlobais.CPF_CLI_ZEROS, VariaveisGlobais.CPF_CLI_COMPLETO)] String sCodCliente,
                                           [Values("RS", "SC", "PR", "ZZ")] String sUf)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Fisica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { new TOEmprestimo() { Uf = sUf } };

            Retorno<Int32> inclusaoAux;
            EmprestimoAux rnEmpAux = this.Infra.InstanciarRN<EmprestimoAux>();

            TOClientePxc toCliente1 = this.PopularTOClientePxc(sCodCliente, TipoPessoa.Fisica);
            toCliente1.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE1, 10, "SC") };
            inclusaoAux = rnEmpAux.Incluir(toCliente1);
            MMAssert.IsTrue(inclusaoAux.OK);

            TOClientePxc toCliente2 = this.PopularTOClientePxc(sCodCliente, TipoPessoa.Fisica);
            toCliente2.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE2, 10, "PR") };
            inclusaoAux = rnEmpAux.Incluir(toCliente2);
            MMAssert.IsTrue(inclusaoAux.OK);

            TOClientePxc toCliente3 = this.PopularTOClientePxc(sCodCliente, TipoPessoa.Fisica);
            toCliente3.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE3, 10, "PR") };
            inclusaoAux = rnEmpAux.Incluir(toCliente3);
            MMAssert.IsTrue(inclusaoAux.OK);

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            switch (sCodCliente)
            {
                case VariaveisGlobais.CPF_CLI_ZEROS:
                    switch (sUf)
                    {
                        case "RS":
                            MMAssert.AreEqual(2, contagem.Dados);
                            break;
                        case "SC":
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case "PR":
                            MMAssert.AreEqual(2, contagem.Dados);
                            break;
                        default:
                            MMAssert.Zero(contagem.Dados);
                            break;
                    }
                    break;
                case VariaveisGlobais.CPF_CLI_COMPLETO:
                    switch (sUf)
                    {
                        case "RS":
                            MMAssert.AreEqual(3, contagem.Dados);
                            break;
                        case "SC":
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case "PR":
                            MMAssert.AreEqual(2, contagem.Dados);
                            break;
                        default:
                            MMAssert.Zero(contagem.Dados);
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c14_Contar_Filtro_UF_J([Values(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, VariaveisGlobais.CNPJ_CLI_COMPLETO)] String sCodCliente,
                                           [Values("RS", "SC", "PR", "ZZ")] String sUf)
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = sCodCliente,
                TipoPessoa = TipoPessoa.Juridica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { new TOEmprestimo() { Uf = sUf } };

            Retorno<Int32> inclusaoAux;
            EmprestimoAux rnEmpAux = this.Infra.InstanciarRN<EmprestimoAux>();

            TOClientePxc toCliente1 = this.PopularTOClientePxc(sCodCliente, TipoPessoa.Juridica);
            toCliente1.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE1, 10, "SC") };
            inclusaoAux = rnEmpAux.Incluir(toCliente1);
            MMAssert.IsTrue(inclusaoAux.OK);

            TOClientePxc toCliente2 = this.PopularTOClientePxc(sCodCliente, TipoPessoa.Juridica);
            toCliente2.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE2, 10, "PR") };
            inclusaoAux = rnEmpAux.Incluir(toCliente2);
            MMAssert.IsTrue(inclusaoAux.OK);

            TOClientePxc toCliente3 = this.PopularTOClientePxc(sCodCliente, TipoPessoa.Juridica);
            toCliente3.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE3, 10, "PR") };
            inclusaoAux = rnEmpAux.Incluir(toCliente3);
            MMAssert.IsTrue(inclusaoAux.OK);

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            switch (sCodCliente)
            {
                case VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF:
                    switch (sUf)
                    {
                        case "RS":
                            MMAssert.AreEqual(4, contagem.Dados);
                            break;
                        case "SC":
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case "PR":
                            MMAssert.AreEqual(2, contagem.Dados);
                            break;
                        default:
                            MMAssert.Zero(contagem.Dados);
                            break;
                    }
                    break;
                case VariaveisGlobais.CNPJ_CLI_COMPLETO:
                    switch (sUf)
                    {
                        case "RS":
                            MMAssert.AreEqual(6, contagem.Dados);
                            break;
                        case "SC":
                            MMAssert.AreEqual(1, contagem.Dados);
                            break;
                        case "PR":
                            MMAssert.AreEqual(2, contagem.Dados);
                            break;
                        default:
                            MMAssert.Zero(contagem.Dados);
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c15_Contar_Filtro_Agencia_F()
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = VariaveisGlobais.CPF_CLI_COMPLETO,
                TipoPessoa = TipoPessoa.Fisica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { new TOEmprestimo() { Agencia = 100 } };

            Retorno<Int32> inclusaoAux;
            EmprestimoAux rnEmpAux = this.Infra.InstanciarRN<EmprestimoAux>();

            TOClientePxc toCliente1 = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            toCliente1.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE1, 10, "SC") };
            inclusaoAux = rnEmpAux.Incluir(toCliente1);
            MMAssert.IsTrue(inclusaoAux.OK);

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            MMAssert.AreEqual(3, contagem.Dados);

            toClientePxc.Emprestimos = new List<TOEmprestimo>() { new TOEmprestimo() { Agencia = 10 } };

            contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            MMAssert.AreEqual(1, contagem.Dados);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c16_Contar_Filtro_Agencia_J()
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO,
                TipoPessoa = TipoPessoa.Juridica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { new TOEmprestimo() { Agencia = 100 } };

            Retorno<Int32> inclusaoAux;
            EmprestimoAux rnEmpAux = this.Infra.InstanciarRN<EmprestimoAux>();

            TOClientePxc toCliente1 = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            toCliente1.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE1, 10, "SC") };
            inclusaoAux = rnEmpAux.Incluir(toCliente1);
            MMAssert.IsTrue(inclusaoAux.OK);

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            MMAssert.AreEqual(6, contagem.Dados);

            toClientePxc.Emprestimos = new List<TOEmprestimo>() { new TOEmprestimo() { Agencia = 10 } };

            contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            MMAssert.AreEqual(1, contagem.Dados);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c17_Contar_Filtro_Inteiro_F()
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = VariaveisGlobais.CPF_CLI_ZEROS,
                TipoPessoa = TipoPessoa.Fisica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO02) };

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            MMAssert.AreEqual(1, contagem.Dados);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa o método Contar.", Author = "B36649")]
        public void c18_Contar_Filtro_Inteiro_J()
        {
            TOClientePxc toClientePxc = new TOClientePxc()
            {
                CodCliente = VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF ,
                TipoPessoa = TipoPessoa.Juridica,
            };
            toClientePxc.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO07) };

            Retorno<Int64> contagem = this.RN.Contar(toClientePxc);
            MMAssert.IsTrue(contagem.OK, "O contar deveria vir OK.");
            MMAssert.AreEqual(1, contagem.Dados);
        }
        #endregion
    }
}

