﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{
	
	///  <summary>Contém as variáveis globais para todos os testes.</summary>
	[TestFixture(Description="Variáveis Globais para todas as outras classes de testes.", Author="B36649")]
	abstract class VariaveisGlobais : AbstractTesteRegraNegocio<Emprestimo>
	{
        /// <summary>["811500675"] Cliente CPF com zeros à esquerda.</summary>
        public const String CPF_CLI_ZEROS = "811500675";
        /// <summary>["811500675"] Cliente CNPJ com zeros à esquerda, e que também é um CPF.</summary>
        public const String CNPJ_CLI_ZEROS_IGUAL_CPF = "811500675";

        /// <summary>["12312312387"] Cliente CPF completo.</summary>
        public const String CPF_CLI_COMPLETO = "40567569888";
        /// <summary>["12341234123429"] Cliente CNPJ completo.</summary>
        public const String CNPJ_CLI_COMPLETO = "11155566645665";

        #region Empréstimos (não colocar em ordem crescente) (cada pessoa escolhe um número para começar, tamanho 5)
        public const Int32 EMPRESTIMO01 = 66666;
        public const Int32 EMPRESTIMO02 = 61234;
        public const Int32 EMPRESTIMO03 = 65555;
        public const Int32 EMPRESTIMO04 = 69881;
        public const Int32 EMPRESTIMO05 = 61313;
        public const Int32 EMPRESTIMO06 = 61717;
        public const Int32 EMPRESTIMO07 = 69999;
        public const Int32 EMPRESTIMO08 = 60000;
        public const Int32 EMPRESTIMO09 = 64321;
        public const Int32 EMPRESTIMO10 = 60101;
        public const Int32 EMPRESTIMO11 = 65656;
        public const Int32 EMPRESTIMO12 = 6666;     // 4 números
        public const Int32 EMPRESTIMO13 = 666;      // 3 números
        public const Int32 EMPRESTIMO14 = 66;       // 2 números
        public const Int32 EMPRESTIMO15 = 6;        // 1 números


        public const Int32 EMPRESTIMO_TESTE1 = 65011;
        public const Int32 EMPRESTIMO_TESTE2 = 66011;
        public const Int32 EMPRESTIMO_TESTE3 = 67011;
        public const Int32 EMPRESTIMO_TESTE4 = 68011;
        #endregion
    }
}

