﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using Bergs.Pxc.Pxcszzxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{

    ///  <summary>
    /// Contém os métodos de teste da classe Emprestimo.
    /// </summary>
    [TestFixture(Description = "Classe de testes para a classe RN Emprestimo.", Author = "B36649")]
    public class R_RNEMP04 : AbstractTesteRegraNegocio<Emprestimo>
    {
        #region Métodos de preparação dos testes
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Senão existe, inclui o cliente
            Retorno<TOClientePxc> obtencaoCliente;
            Retorno<Int32> inclusaoCliente;

            #region Fisica_ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCpfZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCpfZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Fisica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcFisica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcFisica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCnpjZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCnpjZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcJuridica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcJuridica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Inclui empréstimos (se der registro duplicado, mude o número do seu empréstimo (pode ser coincidência))
            Retorno<Int32> inclusaoEmprestimo;

            #region Popula empréstimos para os clientes e inclui o empréstimo
            String MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO = "Erro no BEFORE ALL!\nIncluir Empréstimo {0} para Cliente {1}.\nMensagem: {2}";
            #region Cliente Fisica_ZEROS
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO01) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO01.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO02) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO02.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Fisica
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO03) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO03.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO04) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO04.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO05) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO05.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica ZEROS
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO06) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO06.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO07) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO07.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO08) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO08.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO09) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO09.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO10) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO10.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO11) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO11.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO12) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO12.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO13) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO13.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO14) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO14.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO15) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO15.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #endregion
            #endregion
        }
        ///  <summary>
        /// Executa uma ação ANTES de cada método de teste da classe.
        /// </summary>
        protected override void BeforeEach()
        {
        }
        ///  <summary>
        /// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
        /// </summary>
        protected override void AfterAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Exclui os clientes
            Retorno<Int32> exclusaoClientes;

            #region Fisica_ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Fisica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #endregion

        }
        ///  <summary>
        /// Executa uma ação DEPOIS de cada método de teste da classe.
        /// </summary>
        protected override void AfterEach()
        {
        }
        ///  <summary>
        /// Método para setar os dados necessários para conexão com o PHA no servidor de build.
        /// </summary>
        /// <returns>TO com dados necessários para conexão no servidor de build.</returns>
        protected override TOPhaServidorBuild SetarDadosServidorBuild()
        {
            return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
        }
        #endregion
        #region Métodos Popular
        #region PopularTOClientePxc
        private TOClientePxc PopularTOClientePxc(String sCodCliente, TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = sCodCliente;
            toClientePxc.TipoPessoa = tipoPessoa;

            toClientePxc.Agencia = 100;
            toClientePxc.NomeCliente = "TESTES TESTADOR";

            return toClientePxc;
        }
        #endregion
        #region PopularTOEmprestimo
        /// <summary>Popula TOEmprestimo com alguns valores defaults.</summary>
        /// <param name="codEmprestimo">PK.</param>
        /// <param name="iAgencia">Agencia (default 0100)</param>
        /// <param name="sUF">UF (default RS)</param>
        /// <param name="sCodMunicipio">Cidade (default 4312345)</param>
        /// <param name="dValorEmp">Valor do Empréstimo (default 6.666,99)</param>
        /// <returns>TOEmprestimo populado.</returns>
        private TOEmprestimo PopularTOEmprestimo(Int32 codEmprestimo, Int16 iAgencia = 100, String sUF = "RS", String sCodMunicipio = "4312345", Decimal dValorEmp = 6666.99M)
        {
            return new TOEmprestimo()
            {
                CodEmprestimo = codEmprestimo,
                Agencia = iAgencia,
                Uf = sUF,
                CodMunicipio = sCodMunicipio,
                ValorEmp = dValorEmp
            };
        }
        #endregion
        #region PopularTOClientePxcCompleto
        private TOClientePxc PopularTOClientePxcCompleto()
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = VariaveisGlobais.CPF_CLI_ZEROS;
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            List<TOEmprestimo> emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE1) };
            toClientePxc.Emprestimos = emprestimos;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtInclusao = DateTime.Today;

            return toClientePxc;
        }
        #endregion
        #endregion
        #region Enum auxiliar
        /// <summary>Enum auxliar para testes.</summary>
        public enum MetodosEmprestimo
        {
            /// <summary>Incluir.</summary>
            Incluir,
            /// <summary>Alterar.</summary>
            Alterar,
            /// <summary>Excluir.</summary>
            Excluir,
            /// <summary>Pagar.</summary>
            Pagar,
            /// <summary>Cancelar.</summary>
            Cancelar,
        }
        #endregion
        #region Métodos de teste de sucesso.
        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r01_Sucesso_UF_Maiusculas_Incluir([Values(MetodosEmprestimo.Incluir)] MetodosEmprestimo metodo,
                                              [Values("rs", "Sc", "pR")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            String sCodMunicipio = "12345";
            switch (sUf)
            {
                case "rs":
                    sCodMunicipio = "43" + sCodMunicipio;
                    break;
                case "Sc":
                    sCodMunicipio = "42" + sCodMunicipio;
                    break;
                case "pR":
                    sCodMunicipio = "41" + sCodMunicipio;
                    break;
                default:
                    break;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // Incluir
            Retorno<Int32> inclusao = this.RN.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK);

            TOClientePxc toClientePxcGabaritoInclusao = new TOClientePxc();
            toClientePxcGabaritoInclusao.Emprestimos = new List<TOEmprestimo>();
            toClientePxcGabaritoInclusao.Emprestimos.LerConteudoOuPadrao().Add(new TOEmprestimo() { CodEmprestimo = inclusao.Dados });

            Retorno<TOEmprestimo> obtencaoEmprestimo = this.RN.Obter(toClientePxcGabaritoInclusao);
            MMAssert.IsTrue(obtencaoEmprestimo.OK);

            MMAssert.AreEqual(sUf.ToUpper(), obtencaoEmprestimo.Dados.Uf.LerConteudoOuPadrao());
            MMAssert.AreEqual(sCodMunicipio, obtencaoEmprestimo.Dados.CodMunicipio.LerConteudoOuPadrao());
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r02_Sucesso_UF_Maiusculas_Alterar([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                              [Values("rs", "Sc", "pR")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE4;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            String sCodMunicipio = "00666";
            switch (sUf)
            {
                case "rs":
                    sCodMunicipio = "43" + sCodMunicipio;
                    break;
                case "Sc":
                    sCodMunicipio = "42" + sCodMunicipio;
                    break;
                case "pR":
                    sCodMunicipio = "41" + sCodMunicipio;
                    break;
                default:
                    break;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // Incluir em minúsculo no banco via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK);

            // Obter ULT_ATUALIZACAO
            TOClientePxc toClienteAlteracao = new TOClientePxc();
            toClienteAlteracao.Emprestimos = new List<TOEmprestimo>();
            toClienteAlteracao.Emprestimos.LerConteudoOuPadrao().Add(new TOEmprestimo() { CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE4 });
            
            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClienteAlteracao);
            MMAssert.IsTrue(obtencao.OK);

            // popula UltAtualizacao e cliente e UF
            toClienteAlteracao.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;
            toClienteAlteracao.CodCliente = toClientePxc.CodCliente;
            toClienteAlteracao.TipoPessoa = toClientePxc.TipoPessoa;
            toClienteAlteracao.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;

            sCodMunicipio = "66600";
            switch (sUf)
            {
                case "rs":
                    sCodMunicipio = "43" + sCodMunicipio;
                    break;
                case "Sc":
                    sCodMunicipio = "42" + sCodMunicipio;
                    break;
                case "pR":
                    sCodMunicipio = "41" + sCodMunicipio;
                    break;
                default:
                    break;
            }
            toClienteAlteracao.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            Retorno<Int32> alteracao = this.RN.Alterar(toClienteAlteracao);
            MMAssert.IsTrue(alteracao.OK);

            Retorno<TOEmprestimo> obtencaoEmprestimo = this.RN.Obter(toClienteAlteracao);
            MMAssert.IsTrue(obtencaoEmprestimo.OK);

            MMAssert.AreEqual(sUf.ToUpper(), obtencaoEmprestimo.Dados.Uf.LerConteudoOuPadrao());
            MMAssert.AreEqual(sCodMunicipio, obtencaoEmprestimo.Dados.CodMunicipio.LerConteudoOuPadrao());
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r03_Falha_RegiaoNaoSul([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                           [Values("sp", "zZ", "Az", "11", "BB", "BBB", "A", " ", "G6", "ERRADO")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // Incluir
            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_1", "São aceitas somente as UFs da região Sul do país.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r04_Sucesso_RegiaoNaoSul([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                           [Values("rs", "sc", "pr", "rS", "Rs", "pR", "Pr", "sC", "Sc")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = "123";

            // Incluir
            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP04_1", retorno.Mensagem.Identificador, String.Format("Por todas as UFs informadas serem válidas, não deveria cair em regra de região SUL. Identificador devolvido: {0}.", retorno.Mensagem.Identificador));
            MMAssert.AreNotEqual("São aceitas somente as UFs da região Sul do país.", retorno.Mensagem.ParaOperador, String.Format("Por todas as UFs informadas serem válidas, não deveria cair em regra de região SUL. Mensagem devolvida: {0}.", retorno.Mensagem.ParaOperador));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r05_Falha_CodMunicipio_TamanhoNao7([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                           [Values("0", "a", "1", "22", "333", "4444", "55555", "666666", "88888888")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "RS";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // Incluir
            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_2", "O código do município deve ter tamanho 7.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r06_Sucesso_CodMunicipio_Tamanho7([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                                      [Values("7777777", "ABCDEFG", "a2b4c6Z")] String sCodMunicipio,
                                                      [Values("RS", "SC", "PR")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // Incluir
            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP04_2", retorno.Mensagem.Identificador, "Não deveria cair em erro de tamanho 7 pois o código tem tamanho 7.");
            MMAssert.AreNotEqual("O código do município deve ter tamanho 7.", retorno.Mensagem.ParaOperador, "Não deveria cair em erro de tamanho 7 pois o código tem tamanho 7.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r07_Falha_RS_NaoComeca_43([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                              [Values("4112345", "4266000", "4498765", "4012345", "1234567", "9876543", "0431234", "0000043")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "RS";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // Incluir
            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", "Para UF RS, o Código do Município deve ser iniciado por 43.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r08_Falha_SC_NaoComeca_42([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                              [Values("4112345", "4366000", "4498765", "4012345", "1234567", "9876543", "0421234", "0000042")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "SC";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // Incluir
            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", "Para UF SC, o Código do Município deve ser iniciado por 42.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r09_Falha_PR_NaoComeca_41([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                              [Values("4212345", "4366000", "4498765", "4012345", "1234567", "9876543", "0411234", "0000041")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "PR";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // Incluir
            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", "Para UF PR, o Código do Município deve ser iniciado por 41.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r10_Sucesso_RS_43([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                      [Values("4312345", "4300043", "4366666")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "RS";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP04_3", retorno.Mensagem.Identificador, "Não deveria cair em erro pois a UF e o cod_municipio estão corretos.");
            MMAssert.AreNotEqual("Para UF RS, o Código do Município deve ser iniciado por 43.", retorno.Mensagem.ParaOperador, "Não deveria cair em erro pois a UF e o cod_municipio estão corretos.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r11_Sucesso_SC_42([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                      [Values("4212345", "4200043", "4266666")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "SC";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP04_3", retorno.Mensagem.Identificador, "Não deveria cair em erro pois a UF e o cod_municipio estão corretos.");
            MMAssert.AreNotEqual("Para UF SC, o Código do Município deve ser iniciado por 42.", retorno.Mensagem.ParaOperador, "Não deveria cair em erro pois a UF e o cod_municipio estão corretos.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r12_Sucesso_PR_41([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                               [Values("4112345", "4100043", "4166666")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "PR";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO01;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP04_3", retorno.Mensagem.Identificador, "Não deveria cair em erro pois a UF e o cod_municipio estão corretos.");
            MMAssert.AreNotEqual("Para UF PR, o Código do Município deve ser iniciado por 41.", retorno.Mensagem.ParaOperador, "Não deveria cair em erro pois a UF e o cod_municipio estão corretos.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r13_Alterar_SomenteUF_RS([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                             [Values("SC", "sc", "sC", "Sc", "PR", "pr", "pR", "pR")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro para testes: RS/4312345
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Tentou incluir registro para teste mas retornou erro.\nMensagem: {0}.", inclusao.Mensagem.ParaOperador));

            // obtém para pegar ULT_ATUALIZACAO
            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK, String.Format("Tentou obter registro para teste mas retornou erro.\nMensagem: {0}.", obtencao.Mensagem.ParaOperador));
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;

            // muda a UF SEM ENVIAR COD_MUNICIPIO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = new CampoObrigatorio<String>();

            // tenta alterar
            Retorno<Int32> retorno =  this.RN.Alterar(toClientePxc);

            // auxiliar para testar mensagem de erro
            String sCodMunicipio = (sUf.ToUpper() == "SC") ? "42" : "41";

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", String.Format("Para UF {0}, o Código do Município deve ser iniciado por {1}.", sUf.ToUpper(), sCodMunicipio));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r14_Alterar_SomenteUF_SC([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                             [Values("RS", "rs", "rS", "Rs", "PR", "pr", "pR", "Pr")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "SC";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = "4212345";

            // inclui registro para testes: SC/4212345
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Tentou incluir registro para teste mas retornou erro.\nMensagem: {0}.", inclusao.Mensagem.ParaOperador));

            // obtém para pegar ULT_ATUALIZACAO
            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK, String.Format("Tentou obter registro para teste mas retornou erro.\nMensagem: {0}.", obtencao.Mensagem.ParaOperador));
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;

            // muda a UF SEM ENVIAR COD_MUNICIPIO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = new CampoObrigatorio<String>();

            // tenta alterar
            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            // auxiliar para testar mensagem de erro
            String sCodMunicipio = (sUf.ToUpper() == "RS") ? "43" : "41";

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", String.Format("Para UF {0}, o Código do Município deve ser iniciado por {1}.", sUf.ToUpper(), sCodMunicipio));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r15_Alterar_SomenteUF_PR([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                             [Values("RS", "rs", "rS", "Rs", "SC", "sc", "sC", "Sc")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "PR";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = "4112345";

            // inclui registro para testes: PR/4112345
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Tentou incluir registro para teste mas retornou erro.\nMensagem: {0}.", inclusao.Mensagem.ParaOperador));

            // obtém para pegar ULT_ATUALIZACAO
            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK, String.Format("Tentou obter registro para teste mas retornou erro.\nMensagem: {0}.", obtencao.Mensagem.ParaOperador));
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;

            // muda a UF SEM ENVIAR COD_MUNICIPIO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = new CampoObrigatorio<String>();

            // tenta alterar
            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            // auxiliar para testar mensagem de erro
            String sCodMunicipio = (sUf.ToUpper() == "RS") ? "43" : "42";

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", String.Format("Para UF {0}, o Código do Município deve ser iniciado por {1}.", sUf.ToUpper(), sCodMunicipio));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r16_Alterar_SomenteMunicipio_RS([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                                    [Values("4166666", "4299999", "0430012")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro para testes: RS/4312345
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Tentou incluir registro para teste mas retornou erro.\nMensagem: {0}.", inclusao.Mensagem.ParaOperador));

            // obtém para pegar ULT_ATUALIZACAO
            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK, String.Format("Tentou obter registro para teste mas retornou erro.\nMensagem: {0}.", obtencao.Mensagem.ParaOperador));
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;

            // muda o COD_MUNICIPIO SEM ENVIAR UF
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = new CampoObrigatorio<String>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // tenta alterar
            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", "Para UF RS, o Código do Município deve ser iniciado por 43.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r17_Alterar_SomenteMunicipio_SC([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                                    [Values("4166666", "4399999", "0420012")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf  = "SC";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = "4212345";

            // inclui registro para testes: SC/4212345
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Tentou incluir registro para teste mas retornou erro.\nMensagem: {0}.", inclusao.Mensagem.ParaOperador));

            // obtém para pegar ULT_ATUALIZACAO
            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK, String.Format("Tentou obter registro para teste mas retornou erro.\nMensagem: {0}.", obtencao.Mensagem.ParaOperador));
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;

            // muda o COD_MUNICIPIO SEM ENVIAR UF
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = new CampoObrigatorio<String>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // tenta alterar
            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", "Para UF SC, o Código do Município deve ser iniciado por 42.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r18_Alterar_SomenteMunicipio_PR([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                                    [Values("4266666", "4399999", "0410012")] String sCodMunicipio)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = "PR";
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = "4112345";

            // inclui registro para testes: PR/4112345
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Tentou incluir registro para teste mas retornou erro.\nMensagem: {0}.", inclusao.Mensagem.ParaOperador));

            // obtém para pegar ULT_ATUALIZACAO
            Retorno<TOEmprestimo> obtencao = this.RN.Obter(toClientePxc);
            MMAssert.IsTrue(obtencao.OK, String.Format("Tentou obter registro para teste mas retornou erro.\nMensagem: {0}.", obtencao.Mensagem.ParaOperador));
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = obtencao.Dados.UltAtualizacao;

            // muda o COD_MUNICIPIO SEM ENVIAR UF
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = new CampoObrigatorio<String>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // tenta alterar
            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP04_3", "Para UF PR, o Código do Município deve ser iniciado por 41.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP04.", Author = "B36649")]
        public void r19_Alterar_SemEnviar_UF_MUNICIPIO([Values(MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                                       [Values("RS", "SC", "PR")] String sUf)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // variáveis auxiliares
            String sCodMunicipio = String.Empty;
            switch (sUf)
            {
                case "RS":
                    sCodMunicipio = "43";
                    break;
                case "SC":
                    sCodMunicipio = "42";
                    break;
                case "PR":
                    sCodMunicipio = "41";
                    break;
                default:
                    break;
            }
            sCodMunicipio += "12345";

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = sUf;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = sCodMunicipio;

            // inclui registro para testes: PR/4112345
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Tentou incluir registro para teste mas retornou erro.\nMensagem: {0}.", inclusao.Mensagem.ParaOperador));

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // não muda nem UF e nem COD_MUNICIPIO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Uf = new CampoObrigatorio<String>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodMunicipio = new CampoObrigatorio<String>();

            // tenta alterar
            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);
            MMAssert.AreNotEqual("Falha_RNEMP04_3", retorno.Mensagem.Identificador, "Não deveria cair nesse erro pois a UF e o cod_municipio não foram informados e presume que estavam corretos na inclusão.");
        }
        #endregion
    }
}