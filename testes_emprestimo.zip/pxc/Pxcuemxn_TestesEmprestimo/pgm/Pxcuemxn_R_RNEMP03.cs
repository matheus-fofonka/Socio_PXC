﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using Bergs.Pxc.Pxcszzxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{

    ///  <summary>
    /// Contém os métodos de teste da classe Emprestimo.
    /// </summary>
    [TestFixture(Description = "Classe de testes para a classe RN Emprestimo.", Author = "B36649")]
    public class R_RNEMP03 : AbstractTesteRegraNegocio<Emprestimo>
    {
        #region Métodos de preparação dos testes
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Senão existe, inclui o cliente
            Retorno<TOClientePxc> obtencaoCliente;
            Retorno<Int32> inclusaoCliente;

            #region Fisica_ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCpfZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCpfZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Fisica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcFisica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcFisica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCnpjZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCnpjZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcJuridica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcJuridica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Inclui empréstimos (se der registro duplicado, mude o número do seu empréstimo (pode ser coincidência))
            Retorno<Int32> inclusaoEmprestimo;

            #region Popula empréstimos para os clientes e inclui o empréstimo
            String MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO = "Erro no BEFORE ALL!\nIncluir Empréstimo {0} para Cliente {1}.\nMensagem: {2}";
            #region Cliente Fisica_ZEROS
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO01) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO01.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO02) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO02.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Fisica
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO03) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO03.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO04) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO04.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO05) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO05.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica ZEROS
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO06) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO06.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO07) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO07.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO08) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO08.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO09) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO09.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO10) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO10.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO11) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO11.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO12) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO12.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO13) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO13.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO14) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO14.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO15) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO15.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #endregion
            #endregion
        }
        ///  <summary>
        /// Executa uma ação ANTES de cada método de teste da classe.
        /// </summary>
        protected override void BeforeEach()
        {
        }
        ///  <summary>
        /// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
        /// </summary>
        protected override void AfterAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Exclui os clientes
            Retorno<Int32> exclusaoClientes;

            #region Fisica_ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Fisica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #endregion

        }
        ///  <summary>
        /// Executa uma ação DEPOIS de cada método de teste da classe.
        /// </summary>
        protected override void AfterEach()
        {
        }
        ///  <summary>
        /// Método para setar os dados necessários para conexão com o PHA no servidor de build.
        /// </summary>
        /// <returns>TO com dados necessários para conexão no servidor de build.</returns>
        protected override TOPhaServidorBuild SetarDadosServidorBuild()
        {
            return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
        }
        #endregion
        #region Métodos Popular
        #region PopularTOClientePxc
        private TOClientePxc PopularTOClientePxc(String sCodCliente, TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = sCodCliente;
            toClientePxc.TipoPessoa = tipoPessoa;

            toClientePxc.Agencia = 100;
            toClientePxc.NomeCliente = "TESTES TESTADOR";

            return toClientePxc;
        }
        #endregion
        #region PopularTOEmprestimo
        /// <summary>Popula TOEmprestimo com alguns valores defaults.</summary>
        /// <param name="codEmprestimo">PK.</param>
        /// <param name="iAgencia">Agencia (default 0100)</param>
        /// <param name="sUF">UF (default RS)</param>
        /// <param name="sCodMunicipio">Cidade (default 4312345)</param>
        /// <param name="dValorEmp">Valor do Empréstimo (default 6.666,99)</param>
        /// <returns>TOEmprestimo populado.</returns>
        private TOEmprestimo PopularTOEmprestimo(Int32 codEmprestimo, Int16 iAgencia = 100, String sUF = "RS", String sCodMunicipio = "4312345", Decimal dValorEmp = 6666.99M)
        {
            return new TOEmprestimo()
            {
                CodEmprestimo = codEmprestimo,
                Agencia = iAgencia,
                Uf = sUF,
                CodMunicipio = sCodMunicipio,
                ValorEmp = dValorEmp
            };
        }
        #endregion
        #region PopularTOClientePxcCompleto
        private TOClientePxc PopularTOClientePxcCompleto()
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = VariaveisGlobais.CPF_CLI_ZEROS;
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            List<TOEmprestimo> emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE1) };
            toClientePxc.Emprestimos = emprestimos;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtInclusao = DateTime.Today;

            return toClientePxc;
        }
        #endregion
        #endregion
        #region Enum auxiliar
        /// <summary>Enum auxliar para testes.</summary>
        public enum MetodosEmprestimo
        {
            /// <summary>Incluir.</summary>
            Incluir,
            /// <summary>Alterar.</summary>
            Alterar,
            /// <summary>Excluir.</summary>
            Excluir,
            /// <summary>Pagar.</summary>
            Pagar,
            /// <summary>Cancelar.</summary>
            Cancelar,
        }
        #endregion
        #region Métodos de teste de sucesso.
        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r01_Falha_ValorEmp_MENOR([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(0, 0.01, 1, 500, 777, 999, 999.99)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].ValorEmp = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP03_1", "O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r02_Falha_ValorEmp_MAIOR([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(1000000.01, 2000000, 100000000, 1000000.99, 1000001)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].ValorEmp = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP03_1", "O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r03_Sucesso_ValorIgualLimite([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(1000, 1000000)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].ValorEmp = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP03_1", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual("O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.", retorno.Mensagem.ParaOperador);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r04_Sucesso_ValorAtendeRegra([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(1000.01, 999999.99, 6666, 888777.66)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].ValorEmp = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP03_1", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual("O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.", retorno.Mensagem.ParaOperador);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r05_Falha_TaxaMENOR([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(0, -0.01, -1, -500)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP03_2", "A Taxa do Empréstimo deve ser positiva e menor que 10%.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r06_Falha_TaxaMAIOR([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(10, 10.01, 66, 100, 1000)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP03_2", "A Taxa do Empréstimo deve ser positiva e menor que 10%.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r07_Sucesso_TaxaIgualLimite([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(0.01, 9.99)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP03_2", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual("A Taxa do Empréstimo deve ser positiva e menor que 10%.", retorno.Mensagem.ParaOperador);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r08_Sucesso_TaxaAtendeRegra([Values(MetodosEmprestimo.Incluir, MetodosEmprestimo.Alterar)] MetodosEmprestimo metodo,
                                            [Values(0.5, 1, 3, 6, 9, 9.5, 9.8)] Decimal dValor)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = dValor;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = null;

            switch (metodo)
            {
                case MetodosEmprestimo.Incluir:
                    retorno = this.RN.Incluir(toClientePxc);
                    break;
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RNEMP03_2", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual("A Taxa do Empréstimo deve ser positiva e menor que 10%.", retorno.Mensagem.ParaOperador);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r09_Sucesso_Alterar_Taxa_NULL()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = new CampoOpcional<Decimal>(null);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            MMAssert.AreNotEqual("Falha_RNEMP03_2", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual("A Taxa do Empréstimo deve ser positiva e menor que 10%.", retorno.Mensagem.ParaOperador);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r10_Sucesso_SemEnviarTaxa()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Taxa = new CampoOpcional<Decimal>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            MMAssert.AreNotEqual("Falha_RNEMP03_2", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual("A Taxa do Empréstimo deve ser positiva e menor que 10%.", retorno.Mensagem.ParaOperador);
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP03.", Author = "B36649")]
        public void r11_Sucesso_Alterar_SemEnviarValorEmp()
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].ValorEmp = new CampoObrigatorio<Decimal>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);

            MMAssert.AreNotEqual("Falha_RNEMP03_1", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual("O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.", retorno.Mensagem.ParaOperador);
        }
        #endregion
    }
}

