﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using Bergs.Pxc.Pxcszzxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{

    ///  <summary>
    /// Contém os métodos de teste da classe Emprestimo.
    /// </summary>
    [TestFixture(Description = "Classe de testes para a classe RN Emprestimo.", Author = "B36649")]
    public class R_RNEMP07 : AbstractTesteRegraNegocio<Emprestimo>
    {
        #region Métodos de preparação dos testes
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Senão existe, inclui o cliente
            Retorno<TOClientePxc> obtencaoCliente;
            Retorno<Int32> inclusaoCliente;

            #region Fisica_ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCpfZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCpfZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Fisica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcFisica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcFisica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE FÍSICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica ZEROS
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcCnpjZeros);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcCnpjZeros);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #region Jurídica
            obtencaoCliente = rnEmprestimoAux.ObterCliente(toClientePxcJuridica);
            if (!obtencaoCliente.OK)
            {
                inclusaoCliente = rnEmprestimoAux.IncluirCliente(toClientePxcJuridica);
                MMAssert.IsTrue(inclusaoCliente.OK, String.Format("[ERRO INCLUSÃO CLIENTE JURÍDICA] Deveria ter incluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), inclusaoCliente.Mensagem.ParaOperador, inclusaoCliente.Mensagem.ParaUsuario));
            }
            #endregion
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Inclui empréstimos (se der registro duplicado, mude o número do seu empréstimo (pode ser coincidência))
            Retorno<Int32> inclusaoEmprestimo;

            #region Popula empréstimos para os clientes e inclui o empréstimo
            String MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO = "Erro no BEFORE ALL!\nIncluir Empréstimo {0} para Cliente {1}.\nMensagem: {2}";
            #region Cliente Fisica_ZEROS
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO01) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO01.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCpfZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO02) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCpfZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO02.ToString(), "toClientePxcCpfZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Fisica
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO03) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO03.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO04) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO04.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcFisica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO05) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcFisica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO05.ToString(), "toClientePxcFisica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica ZEROS
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO06) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO06.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO07) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO07.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO08) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO08.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcCnpjZeros.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO09) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcCnpjZeros);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO09.ToString(), "toClientePxcCnpjZeros", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #region Cliente Juridica
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO10) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO10.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO11) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO11.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO12) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO12.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO13) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO13.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO14) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO14.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            toClientePxcJuridica.Emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO15) };
            inclusaoEmprestimo = rnEmprestimoAux.Incluir(toClientePxcJuridica);
            MMAssert.IsTrue(inclusaoEmprestimo.OK, String.Format(MENSAGEM_FALHA_INCLUSAO_EMPRESTIMO, VariaveisGlobais.EMPRESTIMO15.ToString(), "toClientePxcJuridica", inclusaoEmprestimo.Mensagem.ParaOperador));
            #endregion
            #endregion
            #endregion
        }
        ///  <summary>
        /// Executa uma ação ANTES de cada método de teste da classe.
        /// </summary>
        protected override void BeforeEach()
        {
        }
        ///  <summary>
        /// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
        /// </summary>
        protected override void AfterAll()
        {
            #region Instancia classe EmprestimoAux
            Pxcszzxn.EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<Pxcszzxn.EmprestimoAux>();
            #endregion

            #region Popula TOClientePxc's
            TOClientePxc toClientePxcCpfZeros = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_ZEROS, TipoPessoa.Fisica);
            TOClientePxc toClientePxcCnpjZeros = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_ZEROS_IGUAL_CPF, TipoPessoa.Juridica);
            TOClientePxc toClientePxcFisica = this.PopularTOClientePxc(VariaveisGlobais.CPF_CLI_COMPLETO, TipoPessoa.Fisica);
            TOClientePxc toClientePxcJuridica = this.PopularTOClientePxc(VariaveisGlobais.CNPJ_CLI_COMPLETO, TipoPessoa.Juridica);
            #endregion

            #region Exclui os empréstimos
            Retorno<Int32> exclusaoEmprestimos;

            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            exclusaoEmprestimos = rnEmprestimoAux.ExcluirMultiplosEmprestimos(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoEmprestimos.OK);
            #endregion

            #region Exclui os clientes
            Retorno<Int32> exclusaoClientes;

            #region Fisica_ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCpfZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCpfZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Fisica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcFisica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE FÍSICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcFisica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica ZEROS
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcCnpjZeros);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA ZEROS] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcCnpjZeros.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #region Jurídica
            exclusaoClientes = rnEmprestimoAux.ExcluirCliente(toClientePxcJuridica);
            MMAssert.IsTrue(exclusaoClientes.OK, String.Format("[ERRO EXCLUSÃO CLIENTE JURÍDICA] Deveria ter excluído o cliente {0}. Mas retornou.\nPara Operador: {1}.\nPara Usuário: {2}.", toClientePxcJuridica.CodCliente.ToString(), exclusaoClientes.Mensagem.ParaOperador, exclusaoClientes.Mensagem.ParaUsuario));
            #endregion
            #endregion

        }
        ///  <summary>
        /// Executa uma ação DEPOIS de cada método de teste da classe.
        /// </summary>
        protected override void AfterEach()
        {
        }
        ///  <summary>
        /// Método para setar os dados necessários para conexão com o PHA no servidor de build.
        /// </summary>
        /// <returns>TO com dados necessários para conexão no servidor de build.</returns>
        protected override TOPhaServidorBuild SetarDadosServidorBuild()
        {
            return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
        }
        #endregion
        #region Métodos Popular
        #region PopularTOClientePxc
        private TOClientePxc PopularTOClientePxc(String sCodCliente, TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = sCodCliente;
            toClientePxc.TipoPessoa = tipoPessoa;

            toClientePxc.Agencia = 100;
            toClientePxc.NomeCliente = "TESTES TESTADOR";

            return toClientePxc;
        }
        #endregion
        #region PopularTOEmprestimo
        /// <summary>Popula TOEmprestimo com alguns valores defaults.</summary>
        /// <param name="codEmprestimo">PK.</param>
        /// <param name="iAgencia">Agencia (default 0100)</param>
        /// <param name="sUF">UF (default RS)</param>
        /// <param name="sCodMunicipio">Cidade (default 4312345)</param>
        /// <param name="dValorEmp">Valor do Empréstimo (default 6.666,99)</param>
        /// <returns>TOEmprestimo populado.</returns>
        private TOEmprestimo PopularTOEmprestimo(Int32 codEmprestimo, Int16 iAgencia = 100, String sUF = "RS", String sCodMunicipio = "4312345", Decimal dValorEmp = 6666.99M)
        {
            return new TOEmprestimo()
            {
                CodEmprestimo = codEmprestimo,
                Agencia = iAgencia,
                Uf = sUF,
                CodMunicipio = sCodMunicipio,
                ValorEmp = dValorEmp
            };
        }
        #endregion
        #region PopularTOClientePxcCompleto
        private TOClientePxc PopularTOClientePxcCompleto()
        {
            TOClientePxc toClientePxc = new TOClientePxc();

            toClientePxc.CodCliente = VariaveisGlobais.CPF_CLI_ZEROS;
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            List<TOEmprestimo> emprestimos = new List<TOEmprestimo>() { this.PopularTOEmprestimo(VariaveisGlobais.EMPRESTIMO_TESTE1) };
            toClientePxc.Emprestimos = emprestimos;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtInclusao = DateTime.Today;

            return toClientePxc;
        }
        #endregion
        #endregion
        #region Enum auxiliar
        /// <summary>Enum auxliar para testes.</summary>
        public enum MetodosEmprestimo
        {
            /// <summary>Incluir.</summary>
            Incluir,
            /// <summary>Alterar.</summary>
            Alterar,
            /// <summary>Excluir.</summary>
            Excluir,
            /// <summary>Pagar.</summary>
            Pagar,
            /// <summary>Cancelar.</summary>
            Cancelar,
        }
        #endregion
        #region Métodos de teste de sucesso.
        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r01_Falha_Pago_EnviandoData([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxc);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r02_Falha_Cancelado_EnviandoData([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                     [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxc);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r03_Falha_Invalido_EnviandoData([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                    [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today.AddDays(110);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxc);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r04_Falha_Pago_NaoEnviandoData([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                   [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // popula NOVO TOClientePxc (sem enviar datas de controle)
            TOClientePxc toClientePxcTeste = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxcTeste.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxcTeste.TipoPessoa = tipoPessoa;
            }
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxcTeste);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r05_Falha_Cancelado_NaoEnviandoData([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                        [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // popula NOVO TOClientePxc (sem enviar datas de controle)
            TOClientePxc toClientePxcTeste = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxcTeste.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxcTeste.TipoPessoa = tipoPessoa;
            }
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxcTeste);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r06_Falha_Invalido_NaoEnviandoData([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                       [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today.AddDays(110);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // popula NOVO TOClientePxc (sem enviar datas de controle)
            TOClientePxc toClientePxcTeste = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxcTeste.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxcTeste.TipoPessoa = tipoPessoa;
            }
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxcTeste);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r07_Falha_Pago_EnviandoData_NULL([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                     [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // popula NOVO TOClientePxc (sem enviar datas de controle)
            TOClientePxc toClientePxcTeste = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxcTeste.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxcTeste.TipoPessoa = tipoPessoa;
            }
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // datas null
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].DtPagto  = new CampoOpcional<DateTime>(null);
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>(null);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxcTeste);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r08_Falha_Cancelado_EnviandoData_NULL([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                          [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // popula NOVO TOClientePxc (sem enviar datas de controle)
            TOClientePxc toClientePxcTeste = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxcTeste.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxcTeste.TipoPessoa = tipoPessoa;
            }
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // datas null
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>(null);
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>(null);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxcTeste);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r09_Falha_Invalido_EnviandoData_NULL([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                                         [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            // popula datas
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today.AddDays(110);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Today.AddDays(10);

            // inclui registro JÁ PAGO via classe auxiliar
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // popula NOVO TOClientePxc (sem enviar datas de controle)
            TOClientePxc toClientePxcTeste = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxcTeste.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxcTeste.TipoPessoa = tipoPessoa;
            }
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // datas null
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>(null);
            toClientePxcTeste.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>(null);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxcTeste);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxcTeste);
                    break;
                default:
                    break;
            }

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r10_Falha_Ativo_EnviandoDataPagto([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                      [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro ATIVO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando)
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r11_Falha_Ativo_EnviandoDataCancelamento([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                             [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro ATIVO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando)
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddDays(-100);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r12_Falha_Ativo_EnviandoDatas([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                  [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro ATIVO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando)
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddDays(-100);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now.AddMonths(+1);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r13_Falha_Ativo_EnviandoDatas_NULL([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                       [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro ATIVO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando) com NULL
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>(null);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>(null);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r14_Falha_invalido_EnviandoDataPagto([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                         [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro INVALIDO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now;

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando)
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>();

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r15_Falha_Invalido_EnviandoDataCancelamento([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                                 [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro INVALIDO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddDays(-1);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now.AddDays(-10);
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando)
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddDays(-100);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>();

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r16_Falha_Invalido_EnviandoDatas([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                     [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro ATIVO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddDays(-10);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now.AddMonths(+11);
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando)
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddDays(-100);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now.AddMonths(+1);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r17_Falha_invalido_NaoEnviandoDatas([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                        [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro INVALIDO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now;

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando)
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>();

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r18_Falha_invalido_EnviandoDatas_NULL([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                                          [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro INVALIDO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Now;
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now;

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;
            // popula datas (sabotando) com null
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>(null);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>(null);

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retorno, "Falha_RNEMP07", "Só é possível excluir empréstimo pago ou cancelado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r19_Sucesso_NaoExclusao([Values(MetodosEmprestimo.Alterar, MetodosEmprestimo.Pagar, MetodosEmprestimo.Cancelar)] MetodosEmprestimo metodo,
                                            [Values("null", "dt_pagamento", "dt_cancelamento", "não setado")] String sTipoTeste,
                                            [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            // inclui registro ATIVO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // testa o tipo do teste
            switch (sTipoTeste)
            {
                case "null":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>(null);
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>(null);
                    break;
                case "dt_pagamento":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today;
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>();
                    break;
                case "dt_cancelamento":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>();
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddYears(-1);
                    break;
                case "não setado":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>();
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>();
                    break;
                default:
                    break;
            }

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = null;
            switch (metodo)
            {
                case MetodosEmprestimo.Alterar:
                    retorno = this.RN.Alterar(toClientePxc);
                    break;
                case MetodosEmprestimo.Pagar:
                    retorno = this.RN.Pagar(toClientePxc);
                    break;
                case MetodosEmprestimo.Cancelar:
                    retorno = this.RN.Cancelar(toClientePxc);
                    break;
                default:
                    break;
            }

            MMAssert.AreNotEqual("Falha_RN07", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual(String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()), retorno.Mensagem.ParaOperador);
            MMAssert.Pass(String.Format("O ideal seria que caísse em mensagem de concorrência.\nMensagem retornada de erro: {0}.", retorno.Mensagem.ParaOperador));
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa RNEMP07.", Author = "B36649")]
        public void r20_Sucesso_Exclusao([Values(MetodosEmprestimo.Excluir)] MetodosEmprestimo metodo,
                                         [Values("ativo", "invalido")] String sTipoRegistro,
                                         [Values("null", "dt_pagamento", "dt_cancelamento", "não setado")] String sTipoTeste,
                                         [Values()] TipoPessoa tipoPessoa)
        {
            TOClientePxc toClientePxc = this.PopularTOClientePxcCompleto();
            if (tipoPessoa == TipoPessoa.Juridica)
            {
                toClientePxc.CodCliente = VariaveisGlobais.CNPJ_CLI_COMPLETO;
                toClientePxc.TipoPessoa = tipoPessoa;
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = VariaveisGlobais.EMPRESTIMO_TESTE1;

            if (sTipoRegistro == "invalido")
            {
                toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today.AddDays(-1);
                toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Today.AddDays(-11);
            }
            // inclui registro ATIVO ou INVALIDO
            EmprestimoAux rnEmprestimoAux = this.Infra.InstanciarRN<EmprestimoAux>();

            Retorno<Int32> inclusao = rnEmprestimoAux.Incluir(toClientePxc);
            MMAssert.IsTrue(inclusao.OK, String.Format("Deveria ter incluído com sucesso para testes. Investigar o que houve.\nMensagem retornada: {0}.", inclusao.Mensagem.ParaOperador));

            // testa o tipo do teste
            switch (sTipoTeste)
            {
                case "null":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>(null);
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>(null);
                    break;
                case "dt_pagamento":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = DateTime.Today;
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>();
                    break;
                case "dt_cancelamento":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>();
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = DateTime.Now.AddYears(-1);
                    break;
                case "não setado":
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtPagto = new CampoOpcional<DateTime>();
                    toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtCancelamento = new CampoOpcional<DateTime>();
                    break;
                default:
                    break;
            }

            // preenche ULT_ATUALIZACAO
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].UltAtualizacao = DateTime.Now;

            // tenta executar o método correspondente
            Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);

            MMAssert.AreNotEqual("Falha_RN07", retorno.Mensagem.Identificador);
            MMAssert.AreNotEqual(String.Format("Só é possível {0} empréstimo ativo.", metodo.ToString().ToLower()), retorno.Mensagem.ParaOperador);
            MMAssert.Pass(String.Format("O ideal seria que caísse em mensagem de concorrência.\nMensagem retornada de erro: {0}.", retorno.Mensagem.ParaOperador));
        }
        #endregion
    }
}