﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.ProvaEmprestimo
{
	
	///  <summary>
	/// Contém os métodos de teste da classe Emprestimo.
	/// </summary>
	[TestFixture(Description="Classe de testes para a classe RN Emprestimo.", Author="B36649")]
	public class A_01_SituacaoEmprestimo : AbstractTesteRegraNegocio<Emprestimo>
	{
		#region Métodos de preparação dos testes
		///  <summary>
		/// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
		/// </summary>
		protected override void BeforeAll()
		{
		}
		///  <summary>
		/// Executa uma ação ANTES de cada método de teste da classe.
		/// </summary>
		protected override void BeforeEach()
		{
		}
		///  <summary>
		/// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
		/// </summary>
		protected override void AfterAll()
		{
		}
		///  <summary>
		/// Executa uma ação DEPOIS de cada método de teste da classe.
		/// </summary>
		protected override void AfterEach()
		{
		}
		///  <summary>
		/// Método para setar os dados necessários para conexão com o PHA no servidor de build.
		/// </summary>
		/// <returns>TO com dados necessários para conexão no servidor de build.</returns>
		protected override TOPhaServidorBuild SetarDadosServidorBuild()
		{
			return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
		}
		#endregion
		#region Métodos de teste de sucesso.
        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a01_Situacao_CampoObrigatorio()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            MMAssert.IsTrue(toEmprestimo.Situacao.GetType() == typeof(CampoObrigatorio<SituacaoEmprestimo>), "Campo está como opcional ou não está do tipo SituacaoEmprestimo.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a02_Situacao_NEW_TO()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            MMAssert.IsFalse(toEmprestimo.Situacao.FoiSetado, "Criei um novo TOEmprestimo. O campo Situação deveria estar não setado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a03_Situacao_DtPagto_Null()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtPagto = new CampoOpcional<DateTime>(null);
            
            MMAssert.IsFalse(toEmprestimo.DtInclusao.FoiSetado, "O campo Situação deveria estar não setado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a04_Situacao_DtCancelamento_Null()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtCancelamento = new CampoOpcional<DateTime>(null);

            MMAssert.IsFalse(toEmprestimo.DtInclusao.FoiSetado, "O campo Situação deveria estar não setado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a05_Situacao_2Datas_Null()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtPagto = new CampoOpcional<DateTime>(null);
            toEmprestimo.DtCancelamento = new CampoOpcional<DateTime>(null);

            MMAssert.IsFalse(toEmprestimo.DtInclusao.FoiSetado, "O campo Situação deveria estar não setado.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a06_Situacao_Ativa()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Ativo, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar ATIVO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a07_Situacao_Ativa_DtPagto_NULL()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtPagto = new CampoOpcional<DateTime>(null);

            MMAssert.AreEqual(SituacaoEmprestimo.Ativo, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar ATIVO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a08_Situacao_Ativa_DtCancelamento_NULL()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtCancelamento = new CampoOpcional<DateTime>(null);

            MMAssert.AreEqual(SituacaoEmprestimo.Ativo, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar ATIVO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a09_Situacao_Ativa_2Datas_NULL()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtPagto = new CampoOpcional<DateTime>(null);
            toEmprestimo.DtCancelamento = new CampoOpcional<DateTime>(null);

            MMAssert.AreEqual(SituacaoEmprestimo.Ativo, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar ATIVO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a10_Situacao_Pago()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtPagto = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Pago, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar PAGO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a11_Situacao_Pago_DtCancelamento_NULL()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtPagto = DateTime.Now;
            toEmprestimo.DtCancelamento = new CampoOpcional<DateTime>(null);

            MMAssert.AreEqual(SituacaoEmprestimo.Pago, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar PAGO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a12_Situacao_Cancelado()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtCancelamento = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Cancelado, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar CANCELADO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a13_Situacao_Cancelado_DtPagto_NULL()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtPagto = new CampoOpcional<DateTime>(null);
            toEmprestimo.DtCancelamento = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Cancelado, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar CANCELADO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a14_Situacao_INVALIDO()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtInclusao = DateTime.Now;
            toEmprestimo.DtPagto = DateTime.Now;
            toEmprestimo.DtCancelamento = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Invalido, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar INVALIDO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a15_Situacao_INVALIDO_DtInclusao_NaoSetada()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtPagto = DateTime.Now;
            toEmprestimo.DtCancelamento = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Invalido, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar INVALIDO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a16_Situacao_INVALIDO_SomenteDtPagto()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtPagto = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Invalido, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar INVALIDO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a17_Situacao_INVALIDO_SomenteDtPagto_DtCancelamento_NULL()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtPagto = DateTime.Now;
            toEmprestimo.DtCancelamento = new CampoOpcional<DateTime>(null);

            MMAssert.AreEqual(SituacaoEmprestimo.Invalido, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar INVALIDO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a18_Situacao_INVALIDO_SomenteDtCancelamento()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtCancelamento = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Invalido, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar INVALIDO.");
        }

        /// <summary>Testes.</summary>
        [Test(Description = "Testa a propriedade Situacao.", Author = "B36649")]
        public void a19_Situacao_INVALIDO_SomenteDtCancelamento_DtPagto_NULL()
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.DtPagto = new CampoOpcional<DateTime>(null);
            toEmprestimo.DtCancelamento = DateTime.Now;

            MMAssert.AreEqual(SituacaoEmprestimo.Invalido, toEmprestimo.Situacao.LerConteudoOuPadrao(), "Era para estar INVALIDO.");
        }
		#endregion
	}
}

