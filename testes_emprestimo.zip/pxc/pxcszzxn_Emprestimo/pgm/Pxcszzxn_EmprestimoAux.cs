﻿using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqzzxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Relatorios;
using Bergs.Pwx.Pwxoiexn.RN;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bergs.Pxc.Pxcszzxn
{ 
    /// <summary>Classe que possui as regras de negócio para o acesso da tabela EMPRESTIMO da base de dados PXC.</summary>
    public class EmprestimoAux : AplicacaoRegraNegocio
    {
        #region Métodos Cliente
        #region IncluirCliente
        /// <summary>Inclui registro na tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> IncluirCliente(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqzzxn.Emprestimo bdClientePxc;
                Retorno<Int32> inclusaoClientePxc;

                #region Validação de campos
                //Valida que os campos obrigatórios foram informados
                if (!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if (!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }
                if (!toClientePxc.Agencia.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("AGENCIA"));
                }
                // não precisa validar cod_operador porque ele é SEMPRE preenchido no método Incluir da camada Q
                toClientePxc.DtAbeCad = DateTime.Now;
                if (!toClientePxc.NomeCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("NOME_CLIENTE"));
                }
                
                #endregion

                bdClientePxc = this.Infra.InstanciarBD<Pxcqzzxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    inclusaoClientePxc = bdClientePxc.IncluirCliente(toClientePxc);
                    if (!inclusaoClientePxc.OK)
                    {
                        return inclusaoClientePxc;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(inclusaoClientePxc.Dados, new OperacaoRealizadaMensagem("Inclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
        #endregion
        #region ExcluirCliente
        /// <summary>Exclui registro da tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> ExcluirCliente(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqzzxn.Emprestimo bdClientePxc;
                Retorno<Int32> exclusaoClientePxc;

                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if (!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }
                //Valida que o campo que mantém o controle de acessos concorrentes foi informado
                //if (!toClientePxc.UltAtualizacao.FoiSetado)
                //{
                //    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("ULT_ATUALIZACAO"));
                //}
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdClientePxc = this.Infra.InstanciarBD<Pxcqzzxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    exclusaoClientePxc = bdClientePxc.ExcluirCliente(toClientePxc);
                    if (!exclusaoClientePxc.OK)
                    {
                        return exclusaoClientePxc;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(exclusaoClientePxc.Dados, new OperacaoRealizadaMensagem("Exclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
        #endregion
        #region ObterCliente
        /// <summary>Obtém registro da tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOClientePxc> ObterCliente(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqzzxn.Emprestimo bdClientePxc;
                Retorno<TOClientePxc> obtencaoClientePxc;

                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if (!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdClientePxc = this.Infra.InstanciarBD<Pxcqzzxn.Emprestimo>();

                obtencaoClientePxc = bdClientePxc.ObterCliente(toClientePxc);
                if (!obtencaoClientePxc.OK)
                {
                    return obtencaoClientePxc;
                }

                return this.Infra.RetornarSucesso(obtencaoClientePxc.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOClientePxc>(ex);
            }
        }
        #endregion
        #endregion

        #region Métodos
        /// <summary>Exclui registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Excluir(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqzzxn.Emprestimo bdEmprestimo;
                Retorno<Int32> exclusaoEmprestimo;
                
                #region Validação de campos
                TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                //Valida que o campo que mantém o controle de acessos concorrentes foi informado
                if (!toEmprestimo.UltAtualizacao.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("ULT_ATUALIZACAO"));
                }
                #endregion
      
                #region Validação de regras de negócio
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqzzxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    exclusaoEmprestimo = bdEmprestimo.Excluir(toClientePxc);
                    if (!exclusaoEmprestimo.OK)
                    {
                        return exclusaoEmprestimo;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(exclusaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Exclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }

        /// <summary>Exclui registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> ExcluirMultiplosEmprestimos(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqzzxn.Emprestimo bdEmprestimo;
                Retorno<Int32> exclusaoEmprestimo;

                #region Validação de campos
                TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if (!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqzzxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    exclusaoEmprestimo = bdEmprestimo.ExcluirMultiplosEmprestimos(toClientePxc);
                    if (!exclusaoEmprestimo.OK)
                    {
                        return exclusaoEmprestimo;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(exclusaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Exclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
    
        /// <summary>Inclui registro na tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Incluir(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqzzxn.Emprestimo bdEmprestimo;
                Retorno<Int32> inclusaoEmprestimo;
                
                #region Validação de campos
                //Valida que os campos obrigatórios foram informados
                if (!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if (!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }
                TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
                if (!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                if (!toEmprestimo.ValorEmp.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("VALOR_EMP"));
                }
                if (!toEmprestimo.DtInclusao.FoiSetado)
                {
                    toEmprestimo.DtInclusao = DateTime.Now;
                }
                if (!toEmprestimo.Uf.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("UF"));
                }
                if (!toEmprestimo.CodMunicipio.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_MUNICIPIO"));
                }
                if (!toEmprestimo.Agencia.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("AGENCIA"));
                }
                #endregion
      
                #region Validação de regras de negócio
                #endregion
      
                bdEmprestimo = this.Infra.InstanciarBD<Pxcqzzxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    inclusaoEmprestimo = bdEmprestimo.Incluir(toClientePxc);
                    if (!inclusaoEmprestimo.OK)
                    {
                        return inclusaoEmprestimo;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(inclusaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Inclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
    
        /// <summary>Obtém registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOEmprestimo> Obter(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqzzxn.Emprestimo bdEmprestimo;
                Retorno<TOEmprestimo> obtencaoEmprestimo;
                
                #region Validação de campos
                TOEmprestimo toEmprestimo = this.ObterEmprestimo(toClientePxc);
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOEmprestimo>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqzzxn.Emprestimo>();

                obtencaoEmprestimo = bdEmprestimo.Obter(toClientePxc);
                if (!obtencaoEmprestimo.OK)
                {
                    return obtencaoEmprestimo;
                }
                
                return this.Infra.RetornarSucesso(obtencaoEmprestimo.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOEmprestimo>(ex);
            }
        }
        #endregion

        #region Métodos auxiliares
        #region ObterEmprestimo
        /// <summary>Método que obtém o primeiro empréstimo da lista de empréstimos do TOClientePxc.</summary>
        /// <param name="toClientePxc">TO de entrada.</param>
        /// <returns>TOEmprestimo populado.</returns>
        private TOEmprestimo ObterEmprestimo(TOClientePxc toClientePxc)
        {
            TOEmprestimo toEmprestimo = new TOEmprestimo();

            if (this.TemEmprestimo(toClientePxc))
            {
                toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];
            }

            return toEmprestimo;
        }
        #endregion
        #region TemEmprestimo
        /// <summary>Método que verifica se há pelo menos um empréstimo na lista de empréstimos do TOClientePxc.</summary>
        /// <param name="toClientePxc">TO de entrada.</param>
        /// <returns>True, se existe empréstimo. False se não existe.</returns>
        private Boolean TemEmprestimo(TOClientePxc toClientePxc)
        {
            return ((toClientePxc.Emprestimos.TemConteudo) && (toClientePxc.Emprestimos.LerConteudoOuPadrao().Count > 0));
        }
        #endregion
        #endregion
	} 
}