﻿using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqemxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Relatorios;
using Bergs.Pwx.Pwxoiexn.RN;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using System;
using Bergs.Pwx.Pwxoiexn.Comunicacao;
using System.Collections.Generic;
using System.Text;
using Bergs.Pxc.Pxcsclxn;

namespace Bergs.Pxc.Pxcsemxn
{
    /// <summary>Classe que possui as regras de negócio para o acesso da tabela EMPRESTIMO da base de dados PXC.</summary>
    public class Emprestimo : AplicacaoRegraNegocio
    {
        #region Métodos
        /// <summary>Altera registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Alterar( TOClientePxc toClientePxc )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<Int32> alteracaoEmprestimo;

                #region Validação de campos
                #region Emprestimos e PK Cliente
                if(!toClientePxc.Emprestimos.TemConteudo || toClientePxc.Emprestimos.LerConteudoOuPadrao().Count <= 0)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("EMPRÉSTIMO"));
                }
                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if(!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                TOEmprestimo toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];
                #endregion

                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                //Valida que o campo que mantém o controle de acessos concorrentes foi informado
                if(!toEmprestimo.UltAtualizacao.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("ULT_ATUALIZACAO"));
                }
                #endregion

                #region Validação de regras de negócio

                Retorno<int> retRN3 = RNN03(toClientePxc.Emprestimos.LerConteudoOuPadrao()[0]);
                if(!retRN3.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN3.Mensagem);
                }
                Retorno<int> retRN5 = RNN05(toClientePxc, "alterar");
                if(!retRN5.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN5.Mensagem);
                }
                Retorno<int> retRN4 = RNN04(toClientePxc.Emprestimos.LerConteudoOuPadrao()[0]);
                if(!retRN4.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN4.Mensagem);
                }             
                Retorno<int> retRN6 = RNN06(toClientePxc,toClientePxc.Emprestimos.LerConteudoOuPadrao()[0], "alterar");
                if(!retRN6.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN6.Mensagem);
                }
                Retorno<int> retRN7 = RNN07(toClientePxc, "alterar");
                if(!retRN7.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN7.Mensagem);
                }
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using(EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    alteracaoEmprestimo = bdEmprestimo.Alterar(toClientePxc);
                    if(!alteracaoEmprestimo.OK)
                    {
                        return alteracaoEmprestimo;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(alteracaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Alteração"));
                }
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }

        /// <summary>Conta quantidade de registros da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int64> Contar( TOClientePxc toClientePxc )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<Int64> contagemEmprestimo;

                #region Emprestimos e PK Cliente
                if(!toClientePxc.Emprestimos.TemConteudo || toClientePxc.Emprestimos.LerConteudoOuPadrao().Count <= 0)
                {
                    return this.Infra.RetornarFalha<long>(new CampoObrigatorioMensagem("EMPRÉSTIMO"));
                }
                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<long>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if(!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<long>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                #endregion

                #region Validação de regras de negócio
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                contagemEmprestimo = bdEmprestimo.Contar(toClientePxc);
                if(!contagemEmprestimo.OK)
                {
                    return contagemEmprestimo;
                }

                return this.Infra.RetornarSucesso(contagemEmprestimo.Dados, new OperacaoRealizadaMensagem());
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<Int64>(ex);
            }
        }

        /// <summary>Exclui registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Excluir( TOClientePxc toClientePxc )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<Int32> exclusaoEmprestimo;

                #region Validação de campos

                #region Emprestimos e PK Cliente
                if(!toClientePxc.Emprestimos.TemConteudo || toClientePxc.Emprestimos.LerConteudoOuPadrao().Count <= 0)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("EMPRÉSTIMO"));
                }
                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if(!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                TOEmprestimo toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];
                #endregion

                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                //Valida que o campo que mantém o controle de acessos concorrentes foi informado
                if(!toEmprestimo.UltAtualizacao.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("ULT_ATUALIZACAO"));
                }
                #endregion

                #region Validação de regras de negócio
                
                Retorno<int> retRN5 = RNN05(toClientePxc, "excluir");
                if(!retRN5.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN5.Mensagem);
                }
                Retorno<int> retRN7 = RNN07(toClientePxc, "excluir");
                if(!retRN7.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN7.Mensagem);
                }
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using(EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    exclusaoEmprestimo = bdEmprestimo.Excluir(toClientePxc);
                    if(!exclusaoEmprestimo.OK)
                    {
                        return exclusaoEmprestimo;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(exclusaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Exclusão"));
                }
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }

        /// <summary>Inclui registro na tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Incluir( TOClientePxc toClientePxc )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<Int32> inclusaoEmprestimo;

                #region Validação de campos
                #region Emprestimos e PK Cliente
                if(!toClientePxc.Emprestimos.TemConteudo || toClientePxc.Emprestimos.LerConteudoOuPadrao().Count <= 0)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("EMPRÉSTIMO"));
                }
                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if(!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                TOEmprestimo toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];
                #endregion

                //Valida que os campos obrigatórios foram informados

                if(!toEmprestimo.ValorEmp.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("VALOR_EMP"));
                }

                if(!toEmprestimo.Uf.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("UF"));
                }
                if(!toEmprestimo.CodMunicipio.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_MUNICIPIO"));
                }
                #endregion

                #region Validação de regras de negócio
                
                Retorno<int> retRN1 = RNN01(toClientePxc);
                if(!retRN1.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN1.Mensagem);
                }
                Retorno<int> retRN2 = RNN02(toClientePxc.Emprestimos.LerConteudoOuPadrao()[0]);
                if(!retRN2.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN2.Mensagem);
                }
                Retorno<int> retRN3 = RNN03(toClientePxc.Emprestimos.LerConteudoOuPadrao()[0]);
                if(!retRN3.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN3.Mensagem);
                }
                Retorno<int> retRN4 = RNN04(toClientePxc.Emprestimos.LerConteudoOuPadrao()[0]);
                if(!retRN4.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN4.Mensagem);
                }
                Retorno<int> retRN6 = RNN06(toClientePxc, toClientePxc.Emprestimos.LerConteudoOuPadrao()[0], "incluir");
                if(!retRN6.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN6.Mensagem);
                }
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using(EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    inclusaoEmprestimo = bdEmprestimo.Incluir(toClientePxc);
                    if(!inclusaoEmprestimo.OK)
                    {
                        return inclusaoEmprestimo;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(inclusaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Inclusão"));
                }
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }

        /// <summary>Lista registros da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <param name="toPaginacao">Classe da infra-estrutura contendo as informações de paginação.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOClientePxc> Listar( TOClientePxc toClientePxc, TOPaginacao toPaginacao )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<List<TOEmprestimo>> listagemEmprestimo;

                #region Emprestimos e PK Cliente
               
                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if(!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                #endregion

                #region Validação de regras de negócio
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                listagemEmprestimo = bdEmprestimo.Listar(toClientePxc, toPaginacao);
                if(!listagemEmprestimo.OK)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(listagemEmprestimo.Mensagem);
                }

                // Devolvendo ToClientepxc
                TOClientePxc toCli = new TOClientePxc();
                toCli.CodCliente = toClientePxc.CodCliente.LerConteudoOuPadrao();
                toCli.TipoPessoa = toClientePxc.TipoPessoa.LerConteudoOuPadrao();
                toCli.Emprestimos = new List<TOEmprestimo>();
                toCli.Emprestimos = listagemEmprestimo.Dados;

                return this.Infra.RetornarSucesso(toCli, new OperacaoRealizadaMensagem());
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<TOClientePxc>(ex);
            }
        }

        /// <summary>Obtém registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOEmprestimo> Obter( TOClientePxc toClientePxc )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<TOEmprestimo> obtencaoEmprestimo;

                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados
                #region Emprestimos e PK Cliente
                if(!toClientePxc.Emprestimos.TemConteudo || toClientePxc.Emprestimos.LerConteudoOuPadrao().Count <= 0)
                {
                    return this.Infra.RetornarFalha<TOEmprestimo>(new CampoObrigatorioMensagem("EMPRÉSTIMO"));
                }
                //Valida que os campos que fazem parte da chave primária foram informados
                
                TOEmprestimo toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];

                #endregion
                if(!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOEmprestimo>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                obtencaoEmprestimo = bdEmprestimo.Obter(toClientePxc);
                if(!obtencaoEmprestimo.OK)
                {
                    return obtencaoEmprestimo;
                }

                return this.Infra.RetornarSucesso(obtencaoEmprestimo.Dados, new OperacaoRealizadaMensagem());
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<TOEmprestimo>(ex);
            }
        }
        #endregion
        #region METODOS CRIADOS

        /// <summary>Pagar registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Pagar( TOClientePxc toClientePxc )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<Int32> alteracaoEmprestimo;

                #region Validação de campos
                #region Emprestimos e PK Cliente
                if(!toClientePxc.Emprestimos.TemConteudo || toClientePxc.Emprestimos.LerConteudoOuPadrao().Count <= 0)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("EMPRÉSTIMO"));
                }
                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if(!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                TOEmprestimo toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];
                #endregion

                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                //Valida que o campo que mantém o controle de acessos concorrentes foi informado
                if(!toEmprestimo.UltAtualizacao.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("ULT_ATUALIZACAO"));
                }
                #endregion

                #region Validação de regras de negócio
                //  RRNEMP05 e RRNEMP07
                Retorno<int> retRN5 = RNN05(toClientePxc, "pagar");
                if(!retRN5.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN5.Mensagem);
                }
                Retorno<int> retRN7 = RNN07(toClientePxc, "pagar");
                if(!retRN7.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN7.Mensagem);
                }

                // Devolvendo ToClientepxc
                TOClientePxc toCli = new TOClientePxc();
                toCli.CodCliente = toClientePxc.CodCliente.LerConteudoOuPadrao();
                toCli.TipoPessoa = toClientePxc.TipoPessoa.LerConteudoOuPadrao();
                toCli.Emprestimos = new List<TOEmprestimo>();
                TOEmprestimo toEmp = new TOEmprestimo();
                toEmp.CodEmprestimo = toEmprestimo.CodEmprestimo.LerConteudoOuPadrao();
                toEmp.DtPagto = DateTime.Now.Date;
                toCli.Emprestimos.LerConteudoOuPadrao().Add(toEmp);
                
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using(EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    alteracaoEmprestimo = bdEmprestimo.Alterar(toCli);
                    if(!alteracaoEmprestimo.OK)
                    {
                        return alteracaoEmprestimo;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(alteracaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Alteração"));
                }
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }

        /// <summary>Cancelar registro da tabela EMPRESTIMO.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela EMPRESTIMO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Cancelar( TOClientePxc toClientePxc )
        {
            try
            {
                Pxcqemxn.Emprestimo bdEmprestimo;
                Retorno<Int32> alteracaoEmprestimo;

                #region Validação de campos
                #region Emprestimos e PK Cliente
                if(!toClientePxc.Emprestimos.TemConteudo || toClientePxc.Emprestimos.LerConteudoOuPadrao().Count <= 0)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("EMPRÉSTIMO"));
                }
                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if(!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                TOEmprestimo toEmprestimo = toClientePxc.Emprestimos.LerConteudoOuPadrao()[0];
                #endregion

                //Valida que os campos que fazem parte da chave primária foram informados
                if(!toEmprestimo.CodEmprestimo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("COD_EMPRESTIMO"));
                }
                //Valida que o campo que mantém o controle de acessos concorrentes foi informado
                if(!toEmprestimo.UltAtualizacao.FoiSetado)
                {
                    return this.Infra.RetornarFalha<Int32>(new CampoObrigatorioMensagem("ULT_ATUALIZACAO"));
                }
                #endregion

                #region Validação de regras de negócio
                //  RRNEMP05 e RRNEMP07
                Retorno<int> retRN5 = RNN05(toClientePxc, "cancelar");
                if(!retRN5.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN5.Mensagem);
                }
                Retorno<int> retRN7 = RNN07(toClientePxc, "cancelar");
                if(!retRN7.OK)
                {
                    return this.Infra.RetornarFalha<int>(retRN7.Mensagem);
                }

                // Devolvendo ToClientepxc
                TOClientePxc toCli = new TOClientePxc();
                toCli.CodCliente = toClientePxc.CodCliente.LerConteudoOuPadrao();
                toCli.TipoPessoa = toClientePxc.TipoPessoa.LerConteudoOuPadrao();
                toCli.Emprestimos = new List<TOEmprestimo>();
                TOEmprestimo toEmp = new TOEmprestimo();
                toEmp.CodEmprestimo = toEmprestimo.CodEmprestimo.LerConteudoOuPadrao();
                toEmp.DtCancelamento = DateTime.Now.Date;
                toCli.Emprestimos.LerConteudoOuPadrao().Add(toEmp);
                #endregion

                bdEmprestimo = this.Infra.InstanciarBD<Pxcqemxn.Emprestimo>();

                //Cria escopo transacional para garantir atomicidade
                using(EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    alteracaoEmprestimo = bdEmprestimo.Alterar(toCli);
                    if(!alteracaoEmprestimo.OK)
                    {
                        return alteracaoEmprestimo;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(alteracaoEmprestimo.Dados, new OperacaoRealizadaMensagem("Alteração"));
                }
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }

        #region METODO DALTON
        /// <summary>Lista registros da tabela BNJTMUL.</summary>

        /// <param name="toBnjtmul">Transfer Object de entrada referente à tabela REG_ATENDIMENTO.</param>

        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>

        public Retorno<List<TOBnjtmul>> ListarCidades( TOBnjtmul toBnjtmul )
        {
            try
            {
                if((!toBnjtmul.Uf.TemConteudo) || (toBnjtmul.Uf.ToString().Length != 2))

                {
                    return this.Infra.RetornarFalha<List<TOBnjtmul>>(new CampoObrigatorioMensagem("UF"));
                }

                TOTabelaBanrisul toEntradaBNJ = new TOTabelaBanrisul("BNJTMUL", 81);

                toEntradaBNJ.Tipo = TOTabelaBanrisul.Pesquisas.Generica;

                toEntradaBNJ.IndiceFiltro = 2;

                toEntradaBNJ.Filtro = toBnjtmul.Uf;

                IList<TOBnjtmul> retornoBNJ;

                Resultado resultado = this.Infra.Comunicacao.TentarConsultarTabelaBanrisul<TOBnjtmul>(toEntradaBNJ, out retornoBNJ);

                if(resultado.RetornoExecucao != 0)

                {
                    return this.Infra.RetornarFalha<List<TOBnjtmul>>(new RegistroInexistenteMensagem());
                }
                return this.Infra.RetornarSucesso<List<TOBnjtmul>>((List<TOBnjtmul>)retornoBNJ, new OperacaoRealizadaMensagem());
            }
            catch(Exception ex)

            {
                return this.Infra.TratarExcecao<List<TOBnjtmul>>(ex);
            }
        }
        #region RN_Emprestimo
        /// <summary>
        /// valida agencia
        /// </summary>
        private Retorno<int> RNN01( TOClientePxc toClientePxc )
        {
            //using Pxcsclxn
            ClientePxc rnCli = this.Infra.InstanciarRN<ClientePxc>();
            Retorno<TOClientePxc> retOb = rnCli.Obter(toClientePxc);
            if(!retOb.OK)
            {
                return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP01));
            }
            if(retOb.Dados.CodCliente.LerConteudoOuPadrao() != toClientePxc.CodCliente.LerConteudoOuPadrao().PadLeft(14, '0'))
            {
                //mensagem:"Cliente não encontrado."
                return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP01));
            }
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].Agencia = retOb.Dados.Agencia.LerConteudoOuPadrao();
            return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
        }

        /// <summary>
        /// valida Data Inicio
        /// </summary>
        private Retorno<int> RNN02( TOEmprestimo toEmprestimo )
        {
            if(toEmprestimo.DtInclusao.FoiSetado)
            {
                if(!(toEmprestimo.DtInclusao.LerConteudoOuPadrao().Date <= DateTime.Now.Date))
                {
                    //“Data de Inclusão, se informada, deve ser menor ou igual a data atual."
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP02));
                }
                return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
            }
            else
            {
                toEmprestimo.DtInclusao = DateTime.Now.Date;
            }
            return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
        }

        /// <summary>
        /// valor_emp taxa
        /// </summary>
        private Retorno<int> RNN03( TOEmprestimo toEmprestimo )
        {
            if(toEmprestimo.ValorEmp.FoiSetado)
            {
                if(!(toEmprestimo.ValorEmp.LerConteudoOuPadrao() >= Convert.ToDecimal(1000.00) && toEmprestimo.ValorEmp.LerConteudoOuPadrao() <= Convert.ToDecimal(1000000.00)))
                {
                    //O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP03_1));
                }
            }
            
            if(toEmprestimo.Taxa.FoiSetado)
            {
                if(!(toEmprestimo.Taxa.LerConteudoOuPadrao() > 0 && toEmprestimo.Taxa.LerConteudoOuPadrao() < 10))
                {
                    //A Taxa do Empréstimo deve ser positiva e menor que 10%.
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP03_2));
                }

            }
            return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
        }

        /// <summary>
        /// UF e CodMunicipio
        /// </summary>
        private Retorno<int> RNN04( TOEmprestimo toEmprestimo )
        {
            if(toEmprestimo.Uf.FoiSetado)
            {
                toEmprestimo.Uf = toEmprestimo.Uf.LerConteudoOuPadrao().ToUpper();

                switch(toEmprestimo.Uf)
                {
                    case "RS":
                    if(toEmprestimo.CodMunicipio.FoiSetado)
                    {
                        if(toEmprestimo.CodMunicipio.LerConteudoOuPadrao().Length != 7)
                        {
                            //O código do município deve ter tamanho 7.
                            return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP04_2));
                        }
                        if(!(toEmprestimo.CodMunicipio.LerConteudoOuPadrao().Substring(0, 2) == "43"))
                        {
                            //Para UF {0}, o Código do Município deve ser iniciado por { 1}.
                            return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP04_3, "RS", "43"));
                        }
                    }
                    break;
                    case "SC":
                    if(toEmprestimo.CodMunicipio.FoiSetado)
                    {
                        if(toEmprestimo.CodMunicipio.LerConteudoOuPadrao().Length != 7)
                        {
                            //O código do município deve ter tamanho 7.
                            return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP04_2));
                        }
                        if(!(toEmprestimo.CodMunicipio.LerConteudoOuPadrao().Substring(0, 2) == "42"))
                        {
                            //Para UF {0}, o Código do Município deve ser iniciado por { 1}.
                            return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP04_3, "SC", "42"));
                        }
                    }
                    break;
                    case "PR":
                    if(toEmprestimo.CodMunicipio.FoiSetado)
                    {
                        if(toEmprestimo.CodMunicipio.LerConteudoOuPadrao().Length != 7)
                        {
                            //O código do município deve ter tamanho 7.
                            return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP04_2));
                        }
                        if(!(toEmprestimo.CodMunicipio.LerConteudoOuPadrao().Substring(0, 2) == "41"))
                        {
                            //Para UF {0}, o Código do Município deve ser iniciado por { 1}.
                            return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP04_3, "PR", "41"));
                        }
                    }
                    break;
                    default:
                    //São aceitas somente as UFs da região Sul do país.
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP04_1));

                }
            }
            return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
        }

        /// <summary>
        /// Garante Existencia Emprestimo
        /// </summary>
        private Retorno<int> RNN05( TOClientePxc toClientePxc, string nomeMetodo )// “alterar”, “excluir”, “pagar” ou “cancelar”
        {
            Retorno<TOEmprestimo> retOb = Obter(toClientePxc);
            if(!retOb.OK)
            {
                return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP05, nomeMetodo));
            }
            if(!(retOb.Dados.CodEmprestimo.LerConteudoOuPadrao() == toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo))
            {
                //mensagem:"Não é possível {0} o empréstimo, pois o mesmo não faz parte dos empréstimos do cliente informado."
                return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP05, nomeMetodo));
            }
            return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
        }

        /// <summary>
        /// DT: Inclusao, Cancelamento, Pagto
        /// </summary>
        private Retorno<int> RNN06(TOClientePxc toClientePxc, TOEmprestimo toEmprestimo, string nomeMetodo )// “alterar” ou “incluir”
        {
            toEmprestimo.DtPagto = new CampoOpcional<DateTime>(null);
            toEmprestimo.DtCancelamento = new CampoOpcional<DateTime>(null);
            if(nomeMetodo == "alterar")
            {
                Retorno<TOEmprestimo> retOb = Obter(toClientePxc);
                if(!retOb.OK)
                {
                    return this.Infra.RetornarFalha<int>(retOb.Mensagem);
                }
                toEmprestimo.DtInclusao = retOb.Dados.DtInclusao.LerConteudoOuPadrao();
            }
            return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
        }

        /// <summary>
        /// Situacao
        /// </summary>
        private Retorno<int> RNN07( TOClientePxc toClientePxc, string nomeMetodo )// “alterar”, “excluir”, “pagar” ou “cancelar”
        {
            Retorno<TOEmprestimo> retOb = Obter(toClientePxc);
            if(!retOb.OK)
            {
                return this.Infra.RetornarFalha<int>(retOb.Mensagem);
            }

            if(nomeMetodo == "alterar" || nomeMetodo == "pagar" || nomeMetodo == "cancelar")
            {

                if(!(retOb.Dados.Situacao == SituacaoEmprestimo.Ativo))
                {
                    //Só é possível {0} empréstimo {1}.
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP07, nomeMetodo, "ativo"));
                }
            }
            if(nomeMetodo == "excluir")
            {

                if(!(retOb.Dados.Situacao == SituacaoEmprestimo.Pago || retOb.Dados.Situacao == SituacaoEmprestimo.Cancelado))
                {
                    //Só é possível {0} empréstimo {1}.
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.Falha_RNEMP07, nomeMetodo, "pago ou cancelado"));
                }
            }
            return this.Infra.RetornarSucesso<int>(1, new OperacaoRealizadaMensagem());
        }
        #endregion

    }
}
#endregion
#endregion
