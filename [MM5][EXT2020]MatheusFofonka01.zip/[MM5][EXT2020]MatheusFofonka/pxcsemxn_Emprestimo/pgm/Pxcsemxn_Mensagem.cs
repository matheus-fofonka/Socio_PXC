﻿using System;

namespace Bergs.Pxc.Pxcsemxn
{
    /// <summary>Mensagens previstas para o componente</summary>
    public enum TipoMensagem
    {
        /// <summary>Cliente não encontrado.</summary>
        Falha_RNEMP01,
        /// <summary>Data de Inclusão, se informada, deve ser menor ou igual a data atual.</summary>
        Falha_RNEMP02,
        /// <summary>O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive</summary>
        Falha_RNEMP03_1,
        /// <summary>A Taxa do Empréstimo deve ser positiva e menor que 10%</summary>
        Falha_RNEMP03_2,
        /// <summary>São aceitas somente as UFs da região Sul do país.</summary>
        Falha_RNEMP04_1,
        /// <summary>O código do município deve ter tamanho 7.</summary>
        Falha_RNEMP04_2,
        /// <summary>Para UF {0}, o Código do Município deve ser iniciado por {1}.</summary>
        Falha_RNEMP04_3,
        /// <summary>Não é possível {0} o empréstimo, pois o mesmo não faz parte dos empréstimos do cliente informado.</summary>
        Falha_RNEMP05,
        /// <summary>Só é possível {0} empréstimo {1}.</summary>
        Falha_RNEMP07,
    }

    class Mensagem : Bergs.Pwx.Pwxoiexn.Mensagens.Mensagem
    {
        /// <summary>
        /// Mensagem
        /// </summary>
        private String mensagem;

        /// <summary>
        /// Tipo de mensagem
        /// </summary>
        private Pxcsemxn.TipoMensagem tipoMensagem;

        /// <summary>
        /// Mensagem para o usuário
        /// </summary>
        public override String ParaUsuario
        {
            get { return this.ParaOperador; }
        }

        /// <summary>
        /// Mensagem para o operador
        /// </summary>
        public override String ParaOperador
        {
            get { return this.mensagem; }
        }

        /// <summary>
        /// Identificador
        /// </summary>
        public override String Identificador
        {
            get { return tipoMensagem.ToString(); }
        }

        /// <summary>
        /// Construtor da classe Mensagem
        /// </summary>
        /// <param name="mensagem">Mensagem</param>
        /// <param name="argumentos">Argumentos</param>
        public Mensagem( Pxcsemxn.TipoMensagem mensagem, params String[] argumentos )
        {
            tipoMensagem = mensagem;

            switch(mensagem)
            {

                case Pxcsemxn.TipoMensagem.Falha_RNEMP01:
                this.mensagem = "Cliente não encontrado.";
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP02:
                this.mensagem = "Data de Inclusão, se informada, deve ser menor ou igual a data atual.";
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP03_1:
                this.mensagem = "O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.";
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP03_2:
                this.mensagem = "A Taxa do Empréstimo deve ser positiva e menor que 10%";
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP04_1:
                this.mensagem = "São aceitas somente as UFs da região Sul do país.";
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP04_2:
                this.mensagem = "O código do município deve ter tamanho 7.";
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP04_3:
                this.mensagem = String.Format("Para UF {0}, o Código do Município deve ser iniciado por {1}.", argumentos[0], argumentos[1]);
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP05:
                this.mensagem = String.Format("Não é possível {0} o empréstimo, pois o mesmo não faz parte dos empréstimos do cliente informado.", argumentos[0]);
                break;
                case Pxcsemxn.TipoMensagem.Falha_RNEMP07:
                this.mensagem = String.Format("Só é possível {0} empréstimo {1}.", argumentos[0], argumentos[1]);
                break;

                default:
                this.mensagem = "Mensagem não definida.";
                break;
            }
        }
    }
}
