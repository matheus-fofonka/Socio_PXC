﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcqemxn")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcqemxn")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2020")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("04acb091-a3e3-49f7-a75f-66971dad0780")]