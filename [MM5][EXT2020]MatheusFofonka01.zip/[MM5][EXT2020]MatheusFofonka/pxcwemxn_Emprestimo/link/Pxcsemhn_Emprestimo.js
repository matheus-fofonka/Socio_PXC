﻿'use strict';

function Pxcsemhn() {}

Pxcsemhn.prototype = {
    load: function () {
        oPxcsemhn.clienteTpPessoa();
        oInfra.getUtil().setarGroupRadio('rdTipoPessoaLista', oInfra.getProduto().getParametros().getItem('xcTpPessoa'));
        $('#txtNomeClienteLista').val(oInfra.getProduto().getParametros().getItem('xcNomeCli'));

        oInfra.getUtil().setarGroupRadio('rdTipoPessoaCadastro', oInfra.getProduto().getParametros().getItem('xcTpPessoa'));

        $('#txtNomeClienteCadastro').val(oInfra.getProduto().getParametros().getItem('xcNomeCli'));

        $('#btnNovoLista').click(this.clicarNovo);
        $('#btnVoltarLista').click(function () {
            oInfra.getServidor().invocarPagina('M5CL');
        });
        $('#btnNovoCadastro').click(this.clicarNovo);
        $('#btnIncluirCadastro').click(this.clicarIncluir);
        $('#btnSalvarCadastro').click(this.clicarSalvar);
        $('#btnHabilitarCadastro').click(function () {
            oInfra.getTela().clicarHabilitarCadastro();

            switch ($('#selCadastroSituacao').val()) {
                case 'A':
                    $('[name="txtCadastroDtPagto"]').hide();
                    $('[name="txtCadastroDtCancelamento"]').hide();
                    $('#btnHabilitarCadastro').show();
                    $('#btnPagar').show();
                    $('#btnCancelar').show();
                    $('#btnExcluirCadastro').hide();
                    $('#btnHabilitarCadastro').hide();
                    break;
                default:
                    break;
            }
        });
        $('#btnPagar').click(this.clicarPagar);
        $('#btnCancelar').click(this.clicarCancelar);
        $('#btnExcluirCadastro').click(this.clicarExcluir);
        $('#btnLimparCadastroCadastro').click(function () {
            oInfra.getTela().limparCamposAtivosFormulario('#boxDadosCadastro');
        });
        $('#btnVoltarCadastro').click(this.clicarVoltar);

        $('#txtCadastroUf').change(oPxcsemhn.CodMun);
        this.clicarPesquisar();
        oInfra.getUtil().carregarValidador();
        oPxcsemhn.carregarTxtCadastroAgencia();
        this.carregarTxtCadastroAgencia();

    },

    clicarVoltar: function () {
        oInfra.getTela().clicarBotaoPrimeiraPagina();
    },

    CodMun: function () {
        switch ($('#txtCadastroUf').val()) {
            case 'RS':
                oPxcsemhn.carregarTxtCadastroCodMunicipio();
                break;
            case 'SC':
                oPxcsemhn.carregarTxtCadastroCodMunicipio();
                break;
            case 'PR':
                oPxcsemhn.carregarTxtCadastroCodMunicipio();
                break;
            default:
                $('#txtCadastroCodMunicipio').attr('disabled', true);
                break;
        }
    },

    clienteTpPessoa: function () {
        switch (oInfra.getProduto().getParametros().getItem('xcTpPessoa')) {
            case 'F':
                $('#txtCodClienteLista').val(oInfra.getProduto().getParametros().getItem('xcCodCli').substr(3));
                oInfra.getUtil().adicionarMascara('#txtCodClienteLista', '{cpf}');
                $('label[for="txtCodClienteLista"]').html('CPF');
                $('#txtCodClienteLista').attr('mm-regras', 'cpf, required');
                $('#txtCodClienteCadastro').val(oInfra.getProduto().getParametros().getItem('xcCodCli').substr(3));
                oInfra.getUtil().adicionarMascara('#txtCodClienteCadastro', '{cpf}');
                $('label[for="txtCodClienteCadastro"]').html('CPF');
                $('#txtCodClienteCadastro').attr('mm-regras', 'cpf, required');
                break;
            case 'J':
                $('#txtCodClienteLista').val(oInfra.getProduto().getParametros().getItem('xcCodCli'));
                oInfra.getUtil().adicionarMascara('#txtCodClienteLista', '{cnpj}');
                $('#txtCodClienteLista').attr('mm-regras', 'cnpj, required');
                $('label[for="txtCodClienteLista"]').html('CNPJ');
                $('#txtCodClienteCadastro').val(oInfra.getProduto().getParametros().getItem('xcCodCli'));
                oInfra.getUtil().adicionarMascara('#txtCodClienteCadastro', '{cnpj}');
                $('#txtCodClienteCadastro').attr('mm-regras', 'cnpj, required');
                $('label[for="txtCodClienteCadastro"]').html('CNPJ');
                break;
            default:
                oInfra.getTela().mensagem(
                    'Nenhum cliente selecionado.',
                    'Atenção',
                    ['Ok'],
                    [
                        function () {
                            oInfra.getServidor().invocarPagina('M5CL');
                        },
                    ]
                );
                return;
        }
    },

    clicarNovo: function () {
        oInfra.getTela().limparCamposFormulario('#formCadastro');
        oInfra.getTela().mostrarTela('Cadastro', 'Inclusao');
        $('#txtCadastroCodMunicipio').attr('disabled', true);

    },
    formatarLinhaListaTabelalista: function (dados) {
        var cod = dados.cod_emprestimo.padStart(7, '0');
        dados.cod_emprestimo_formatado = cod;
        dados.dt_inclusao_formatado = oInfra.getUtil().aplicarMascara(dados.dt_inclusao, '00/00/0000');
        var ag = dados.agencia.padStart(4, '0');
        dados.agencia_formatado = ag;
        dados.valor_emp_formatado = oInfra.getUtil().aplicarMascara(dados.valor_emp, '{moeda}');
        if (dados.taxa === '') {
            dados.taxa_formatado = '-';
        } else {
            dados.taxa_formatado = oInfra.getUtil().aplicarMascara(dados.taxa, '9.00');
        }
        var sit = '';
        switch (dados.situacao) {
            case 'A':
                sit = 'Ativo';
                break;
            case 'C':
                sit = 'Cancelado';
                break;
            case 'P':
                sit = 'Pago';
                break;
            default:
                break;
        }
        dados.situacao_formatado = sit;
        return dados;
    },
    clicarIncluir: function () {
        if (!oInfra.getUtil().validarFormulario('#formCadastro')) {
            return false;
        }
        //RNEMP02;
        //txtCadastroDtInclusao mm regra data atual ou menor
        //RNEMP03;
        //O campo VALOR_EMP deve ser maior ou igual a R$ 1.000,00 e menor ou igual a R$ 1.000.000,00. [min] e [max]
        //O campo TAXA, se informado, deve ser positivo e menor que 10%. 

        var parms = oInfra.getTela().getParametros().oPares;
        parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
        parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
        //
        parms.cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
        parms.dt_inclusao = $('#txtCadastroDtInclusao').val().trim();
        parms.uf = $('#txtCadastroUf').val().trim();
        parms.cod_municipio = $('#txtCadastroCodMunicipio').val().trim();
        parms.valor_emp = $('#txtCadastroValorEmp').val().trim();
        parms.taxa = $('#txtCadastroTaxa').val().trim();
        parms.dt_pagto = $('#txtCadastroDtPagto').val().trim();
        parms.dt_cancelamento = $('#txtCadastroDtCancelamento').val().trim();
        parms.cod_operador = $('#txtCadastroCodOperador').val().trim();
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Incluir', {
            parametros: parms
        });
    },
    clicarSalvar: function () {
        if (!oInfra.getUtil().validarFormulario('#formCadastro')) {
            return false;
        }
        //RNEMP03;
        //O campo VALOR_EMP deve ser maior ou igual a R$ 1.000,00 e menor ou igual a R$ 1.000.000,00. [min] e [max]
        //O campo TAXA, se informado, deve ser positivo e menor que 10%. 

        var parms = oInfra.getTela().getParametros().oPares;
        parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
        parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
        //
        parms.cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
        parms.dt_inclusao = $('#txtCadastroDtInclusao').val().trim();
        parms.agencia = $('#txtCadastroAgencia').val().trim();
        parms.uf = $('#txtCadastroUf').val().trim();
        parms.cod_municipio = $('#txtCadastroCodMunicipio').val().trim();
        parms.valor_emp = $('#txtCadastroValorEmp').val().trim();
        parms.taxa = $('#txtCadastroTaxa').val().trim();
        parms.dt_pagto = $('#txtCadastroDtPagto').val().trim();
        parms.dt_cancelamento = $('#txtCadastroDtCancelamento').val().trim();
        parms.cod_operador = $('#txtCadastroCodOperador').val().trim();
        parms.ult_atualizacao = $('#txtCadastroUltAtualizacao').val().trim();
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Alterar', {
            parametros: parms
        });
    },
    clicarExcluir: function () {
        if ($('#selCadastroSituacao').val() === 'A') {
            oInfra.getTela().mensagem('Só é possível excluir empréstimo com situação Paga ou Cancelada.', 'Atenção', ['Ok'], [
                function () {
                    oInfra.getTela().fecharMensagem();
                    return;
                }
            ]);
        }
        oInfra.getTela().mensagem(
            'Deseja excluir esse empréstimo?',
            'Atenção',
            ['Sim', 'Não'],
            [
                function () {
                    oInfra.getTela().fecharMensagem();

                    var cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
                    var ult_atualizacao = $('#txtCadastroUltAtualizacao').val().trim();
                    var parms = oInfra.getTela().getParametros().oPares;

                    parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
                    parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
                    //
                    parms.cod_emprestimo = cod_emprestimo;
                    parms.ult_atualizacao = ult_atualizacao;
                    oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Excluir', {
                        parametros: parms
                    });
                },
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]
        );
    },

    clicarPesquisar: function () {
        var parms = oInfra.getTransacao().getParametros().oPares;
        parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
        parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/ListarPrimeiraPagina', {
            parametros: parms,
            retorno: oInfra.getUtil().tratarRetornoListar
        });
        oInfra.getTela().clicarBotaoPrimeiraPagina();
    },

    tratarRetornoObterboxDadosCadastro: function (oJson) {
        if (oInfra.getJsonUtil().confirmarSucesso(oJson)) {
            if (oJson.dados) {

                var a = oJson.dados.registrousuario.agencia;
                a = a.padStart(4, '0');
                var cod = oJson.dados.registrousuario.cod_emprestimo.padStart(7, '0');

                oInfra.getTela().popularCamposFormulario('#formCadastro', {
                    situacao: oJson.dados.registrousuario.situacao,
                    cod_emprestimo: oJson.dados.registrousuario.cod_emprestimo,
                    cod_emprestimo_formatado: cod,
                    dt_inclusao: oJson.dados.registrousuario.dt_inclusao,
                    uf: oJson.dados.registrousuario.uf,
                    agencia: a,
                    cod_municipio: oJson.dados.registrousuario.cod_municipio,
                    valor_emp: oJson.dados.registrousuario.valor_emp,
                    taxa: oJson.dados.registrousuario.taxa,
                    dt_pagto: oJson.dados.registrousuario.dt_pagto,
                    dt_cancelamento: oJson.dados.registrousuario.dt_cancelamento,
                    cod_operador: oJson.dados.registrousuario.cod_operador,
                    ult_atualizacao: oJson.dados.registrousuario.ult_atualizacao,
                    ult_atualizacaoFormatado: oJson.dados.registrousuario.ult_atualizacao,
                });
                oPxcsemhn.carregarTxtCadastroCodMunicipio();

                oInfra.getTela().mostrarTela('Cadastro', 'Consulta');

                switch (oJson.dados.registrousuario.situacao) {
                    case 'A':
                        $('[name="txtCadastroDtPagto"]').hide();
                        $('[name="txtCadastroDtCancelamento"]').hide();
                        $('#btnHabilitarCadastro').show();
                        $('#btnPagar').show();
                        $('#btnCancelar').show();
                        $('#btnExcluirCadastro').hide();
                        break;
                    case 'C':
                        $('[name="txtCadastroDtPagto"]').hide();
                        $('[name="txtCadastroDtCancelamento"]').show();
                        $('#btnHabilitarCadastro').hide();
                        $('#btnPagar').hide();
                        $('#btnCancelar').hide();
                        $('#btnExcluirCadastro').show();
                        break;
                    case 'P':
                        $('[name="txtCadastroDtPagto"]').show();
                        $('[name="txtCadastroDtCancelamento"]').hide();
                        $('#btnHabilitarCadastro').hide();
                        $('#btnPagar').hide();
                        $('#btnCancelar').hide();
                        $('#btnExcluirCadastro').show();
                        break;
                    default:
                        break;
                }

            }
        } else {
            oInfra.getTela().mensagem(oInfra.getJsonUtil().lerMensagem(oJson));
        }
    },
    exibirEmprestimo: function (cod_emprestimo) {
        var parms = oInfra.getTela().getParametros().oPares;
        parms.cod_emprestimo = cod_emprestimo;
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Obter', {
            parametros: parms,
            retorno: oPxcsemhn.tratarRetornoObterboxDadosCadastro
        });
    },
    excluirItemTabelaLista: function (cod_emprestimo, ult_atualizacao, situacao) {
        if (situacao === 'A') {
            oInfra.getTela().mensagem('Só é possível excluir empréstimo com situação Paga ou Cancelada.', 'Atenção', ['Ok'], [
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]);
            return;
        }
        oInfra.getTela().mensagem(
            'Deseja excluir esse empréstimo?',
            'Atenção',
            ['Sim', 'Não'],
            [
                function () {
                    oInfra.getTela().fecharMensagem();
                    var parms = oInfra.getTela().getParametros().oPares;
                    parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
                    parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
                    parms.cod_emprestimo = cod_emprestimo;
                    parms.ult_atualizacao = ult_atualizacao;
                    oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Excluir', {
                        parametros: parms
                    });
                },
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]
        );
    },

    carregarTxtCadastroAgencia: function () {
        oInfra.getServidor().invocarServico('Pxcwctxn_Contrato.asmx/CarregarCboAgencia', {
            parametros: oInfra.getTela().getParametros(),
            retorno: function (oJson) {
                if (oInfra.getJsonUtil().confirmarSucesso(oJson)) {
                    if (!oJson.dados) {
                        return;
                    }
                    oInfra.getTela().renderizarCombo('#txtCadastroAgencia', oJson.dados);
                } else {
                    oInfra.getTela().mensagem(oInfra.getJsonUtil().lerMensagem(oJson));
                }
            }
        });
    },

    carregarTxtCadastroCodMunicipio: function () {
        $('#txtCadastroCodMunicipio').attr('disabled', false);
        var parms = oInfra.getTela().getParametros().oPares;
        parms.uf = $('#txtCadastroUf').val();
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/ListarCodMunicipio', {
            parametros: parms,
            retorno: function (oJson) {
                if (oInfra.getJsonUtil().confirmarSucesso(oJson)) {
                    if (!oJson.dados) {
                        return;
                    }
                    oInfra.getTela().renderizarCombo('#txtCadastroCodMunicipio', oJson.dados);
                } else {
                    oInfra.getTela().mensagem(oInfra.getJsonUtil().lerMensagem(oJson));
                }
            }
        });
    },
    clicarPagar: function () {
        oInfra.getTela().mensagem(
            'Deseja pagar esse empréstimo?',
            'Atenção',
            ['Sim', 'Não'],
            [
                function () {
                    oInfra.getTela().fecharMensagem();

                    var cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
                    var ult_atualizacao = $('#txtCadastroUltAtualizacao').val().trim();
                    var parms = oInfra.getTela().getParametros().oPares;

                    parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
                    parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
                    //
                    parms.cod_emprestimo = cod_emprestimo;
                    parms.ult_atualizacao = ult_atualizacao;
                    oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Pagar', {
                        parametros: parms
                    });
                },
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]
        );
    },
    clicarCancelar: function () {
        oInfra.getTela().mensagem(
            'Deseja cancelar esse empréstimo?',
            'Atenção',
            ['Sim', 'Não'],
            [
                function () {
                    oInfra.getTela().fecharMensagem();

                    var cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
                    var ult_atualizacao = $('#txtCadastroUltAtualizacao').val().trim();
                    var parms = oInfra.getTela().getParametros().oPares;

                    parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
                    parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
                    //
                    parms.cod_emprestimo = cod_emprestimo;
                    parms.ult_atualizacao = ult_atualizacao;
                    oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Cancelar', {
                        parametros: parms
                    });
                },
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]
        );
    },

};

//Tirar paginacao
//ult_atualizacao Cadastro
//validar rns mm-regras

//Voltar Console Lista??
//Taxa Lista??