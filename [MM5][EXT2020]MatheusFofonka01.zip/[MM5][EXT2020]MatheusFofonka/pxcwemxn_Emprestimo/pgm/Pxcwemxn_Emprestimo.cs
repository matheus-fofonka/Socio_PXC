﻿using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.IN;
using Bergs.Pwx.Pwxoiexn.IN.Controles;
using Bergs.Pxc.Pxcbtoxn;
using System;
using System.Collections.Generic;
using System.Web.Services;

namespace Bergs.Pxc.Pxcwemxn
{
	
	/// <summary>Classe responsável pela tela da transação.</summary>
	[WebService(Namespace = "Bergs.Pxc.Pxcwemxn")]
	[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
	public class Emprestimo : AplicacaoTelaHtml5
	{
		/// <summary>Construtor.</summary>
		public Emprestimo() : 
				base(0)
		{
		}
		/// <summary>Inclui um registro.</summary>
		/// <returns>Status da operação</returns>
		[WebMethod()]
		public string Incluir()
		{
			try
			{
                TOClientePxc toClientePxc = this.PopularTOEmprestimoCadastro();
				Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
				Retorno<Int32> retorno = rnEmprestimo.Incluir(toClientePxc);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Salva alterações do item detalhado</summary>
		/// <returns>Status da operação.</returns>
		[WebMethod()]
		public string Alterar()
		{
			try
			{
				TOClientePxc toClientePxc = this.PopularTOEmprestimoCadastro();
				Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
				Retorno<Int32> retorno = rnEmprestimo.Alterar(toClientePxc);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Exclui o item detalhado.</summary>
		/// <returns>Status da operação.</returns>
		[WebMethod()]
		public string Excluir()
		{
			try
			{
				TOClientePxc toClientePxc = this.PopularTOEmprestimoCadastro();
				Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
				Retorno<Int32> retorno = rnEmprestimo.Excluir(toClientePxc);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
        /// <summary>Exclui o item detalhado.</summary>
		/// <returns>Status da operação.</returns>
		[WebMethod()]
        public string Cancelar()
        {
            try
            {
                TOClientePxc toClientePxc = this.PopularTOEmprestimoCadastro();
                Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
                Retorno<Int32> retorno = rnEmprestimo.Cancelar(toClientePxc);
                return this.Infra.RetornarJson(retorno);
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecaoJson(ex);
            }
        }
        /// <summary>Exclui o item detalhado.</summary>
		/// <returns>Status da operação.</returns>
		[WebMethod()]
        public string Pagar()
        {
            try
            {
                TOClientePxc toClientePxc = this.PopularTOEmprestimoCadastro();
                Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
                Retorno<Int32> retorno = rnEmprestimo.Pagar(toClientePxc);
                return this.Infra.RetornarJson(retorno);
            }
            catch(Exception ex)
            {
                return this.Infra.TratarExcecaoJson(ex);
            }
        }
        /// <summary>Pesquisa dados referentes ao filtro aplicado</summary>
        /// <param name="pagina">Pagina inicial.</param>
        /// <returns>Lista dos dados obtidos.</returns>
        [WebMethod()]
		protected override string Listar(Int32 pagina)
		{
			try
			{
				Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
                TOClientePxc toClientePxc = this.PopularTOEmprestimoCadastro();
				Retorno<Int64> contagemEmprestimo = rnEmprestimo.Contar(toClientePxc);
                if(!(contagemEmprestimo.OK && contagemEmprestimo.Dados > 0))
                {
                    return this.Infra.RetornarJson(contagemEmprestimo);
                }
				TOPaginacao toPaginacao = new TOPaginacao(1,contagemEmprestimo.Dados);
				Retorno<TOClientePxc> retorno = rnEmprestimo.Listar(toClientePxc, toPaginacao);
				ListaHtml5<TOEmprestimo> lista = new ListaHtml5<TOEmprestimo>(retorno.Dados.Emprestimos.LerConteudoOuPadrao(), toPaginacao);
				return this.Infra.RetornarJson(retorno, lista);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Obtém o objeto pela chave.</summary>
		/// <returns>Objeto</returns>
		[WebMethod()]
		public string Obter()
		{
			try
			{
                TOClientePxc toClientePxc = new TOClientePxc();
                toClientePxc.Emprestimos = new List<TOEmprestimo>();
				TOEmprestimo toEmprestimo = this.PopularTOEmprestimoLista();
                toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

                Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
				Retorno<TOEmprestimo> retorno = rnEmprestimo.Obter(toClientePxc);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}

		/// <summary>Pesquisa dados referentes ao filtro aplicado</summary>
		/// <returns>Lista dos dados obtidos para preencher o combo.</returns>
		[WebMethod()]
		public string ListarCodMunicipio()
		{
			try
			{
				TOBnjtmul tOBnjtmul = new TOBnjtmul();
				if (this.LerValorCliente("uf") != null)
				{
					tOBnjtmul.Uf = this.LerValorCliente("uf");
				}
				Pxcsemxn.Emprestimo rnEmprestimo = this.Infra.InstanciarRN<Pxcsemxn.Emprestimo>();
				Retorno<List<TOBnjtmul>> retorno = rnEmprestimo.ListarCidades(tOBnjtmul);
				ListaHtml5<TOBnjtmul> lista = new ListaHtml5<TOBnjtmul>(retorno.Dados, null);
				return this.Infra.RetornarJson(retorno, lista);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Popula um TOEmprestimo para ser utilizado nos métodos de Cadastro.</summary>
		/// <returns>TO populado</returns>
		private TOClientePxc PopularTOEmprestimoCadastro()
		{
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
			TOEmprestimo toEmprestimo = new TOEmprestimo();
            if(this.LerValorCliente("xcCodCli") != null)
            {
                toClientePxc.CodCliente = this.LerValorCliente("xcCodCli");
            }
            if(this.LerValorCliente("xcTpPessoa") != null)
            {
                toClientePxc.TipoPessoa = (TipoPessoa)Convert.ToChar(this.LerValorCliente("xcTpPessoa"));
            }

            if (this.LerValorCliente("cod_emprestimo") != null)
			{
				toEmprestimo.CodEmprestimo = Convert.ToDecimal(this.LerValorCliente("cod_emprestimo"));
			}
			if (this.LerValorCliente("dt_inclusao") != null)
			{
				toEmprestimo.DtInclusao = Convert.ToDateTime(this.LerValorCliente("dt_inclusao"));
			}
			if (this.LerValorCliente("agencia") != null)
			{
				toEmprestimo.Agencia = Convert.ToInt16(this.LerValorCliente("agencia"));
			}
			if (this.LerValorCliente("uf") != null)
			{
				toEmprestimo.Uf = this.LerValorCliente("uf");
			}
			if (this.LerValorCliente("cod_municipio") != null)
			{
				toEmprestimo.CodMunicipio = this.LerValorCliente("cod_municipio");
			}
			if (this.LerValorCliente("valor_emp") != null)
			{
				toEmprestimo.ValorEmp = Convert.ToDecimal(this.LerValorCliente("valor_emp"));
			}
			if (this.LerValorCliente("taxa") != null)
			{
				toEmprestimo.Taxa = Convert.ToDecimal(this.LerValorCliente("taxa"));
			}
			if (this.LerValorCliente("dt_pagto") != null)
			{
				toEmprestimo.DtPagto = Convert.ToDateTime(this.LerValorCliente("dt_pagto"));
			}
			if (this.LerValorCliente("dt_cancelamento") != null)
			{
				toEmprestimo.DtCancelamento = Convert.ToDateTime(this.LerValorCliente("dt_cancelamento"));
			}
			if (this.LerValorCliente("cod_operador") != null)
			{
				toEmprestimo.CodOperador = this.LerValorCliente("cod_operador");
			}
			if (this.LerValorCliente("ult_atualizacao") != null)
			{
				toEmprestimo.UltAtualizacao = Convert.ToDateTime(this.LerValorCliente("ult_atualizacao"));
			}

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			return toClientePxc;
		}
		/// <summary>Popula um TOEmprestimo para ser utilizado nos métodos de Cadastro.</summary>
		/// <returns>TO populado</returns>
		private TOEmprestimo PopularTOEmprestimoLista()
		{
			TOEmprestimo toEmprestimo = new TOEmprestimo();
			if (this.LerValorCliente("cod_emprestimo") != null)
			{
				toEmprestimo.CodEmprestimo = Convert.ToDecimal(this.LerValorCliente("cod_emprestimo"));
			}
			return toEmprestimo;
		}
	}
}

