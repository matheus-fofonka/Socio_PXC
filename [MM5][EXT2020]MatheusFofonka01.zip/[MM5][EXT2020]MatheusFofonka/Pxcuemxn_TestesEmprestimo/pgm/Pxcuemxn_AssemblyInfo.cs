﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcuemxn.Test")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcuemxn.Test")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2020")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("0c9b1bab-61cf-447e-97e8-cd77eddf8cc3")]