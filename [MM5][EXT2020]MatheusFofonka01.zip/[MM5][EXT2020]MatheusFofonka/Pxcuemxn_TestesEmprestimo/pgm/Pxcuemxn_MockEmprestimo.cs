﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqemxn;
using Bergs.Pxc.Pxcsemxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.Tests
{
	
	///  <summary>
	/// Contém os métodos de mock para testes da classe Emprestimo.
	/// </summary>
	public class MockEmprestimo : AbstractMmMock
	{
		#region Construtor
		///  <summary>
		/// Construtor da classe de mocks
		/// </summary>
		/// <param name="infra">Infra</param>
		public MockEmprestimo(InfraTeste infra) : 
				base(infra)
		{
		}
		#endregion
		#region Métodos de mock de Falha.
		///  <summary>
		/// Registra um mock para o método Alterar.
		/// </summary>
		public void AlterarComFalha()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Alterar(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.RetornarFalha<Int32>(new MensagemFalhaTestador("Alterar")));
		}
		///  <summary>
		/// Registra um mock para o método Contar.
		/// </summary>
		public void ContarComFalha()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Contar(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.RetornarFalha<Int64>(new MensagemFalhaTestador("Contar")));
		}
		///  <summary>
		/// Registra um mock para o método Excluir.
		/// </summary>
		public void ExcluirComFalha()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Excluir(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.RetornarFalha<Int32>(new MensagemFalhaTestador("Excluir")));
		}
		///  <summary>
		/// Registra um mock para o método Incluir.
		/// </summary>
		public void IncluirComFalha()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Incluir(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.RetornarFalha<Int32>(new MensagemFalhaTestador("Incluir")));
		}
		///  <summary>
		/// Registra um mock para o método Obter.
		/// </summary>
		public void ObterComFalha()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Obter(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.RetornarFalha<TOEmprestimo>(new MensagemFalhaTestador("Obter")));
		}
		#endregion
		#region Métodos de mock de Excecao.
		///  <summary>
		/// Registra um mock para o método Alterar.
		/// </summary>
		public void AlterarComExcecao()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Alterar(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.TratarExcecao<Int32>(new Exception("Simulação de teste de exceção do método Alterar.")));
		}
		///  <summary>
		/// Registra um mock para o método Contar.
		/// </summary>
		public void ContarComExcecao()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Contar(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.TratarExcecao<Int64>(new Exception("Simulação de teste de exceção do método Contar.")));
		}
		///  <summary>
		/// Registra um mock para o método Excluir.
		/// </summary>
		public void ExcluirComExcecao()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Excluir(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.TratarExcecao<Int32>(new Exception("Simulação de teste de exceção do método Excluir.")));
		}
		///  <summary>
		/// Registra um mock para o método Incluir.
		/// </summary>
		public void IncluirComExcecao()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Incluir(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.TratarExcecao<Int32>(new Exception("Simulação de teste de exceção do método Incluir.")));
		}
		///  <summary>
		/// Registra um mock para o método Obter.
		/// </summary>
		public void ObterComExcecao()
		{
			Pxcqemxn.Emprestimo mockEmprestimoBD = this.Mock.Para<Pxcqemxn.Emprestimo>();
			mockEmprestimoBD.Obter(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.TratarExcecao<TOEmprestimo>(new Exception("Simulação de teste de exceção do método Obter.")));
		}
		#endregion
	}
}

