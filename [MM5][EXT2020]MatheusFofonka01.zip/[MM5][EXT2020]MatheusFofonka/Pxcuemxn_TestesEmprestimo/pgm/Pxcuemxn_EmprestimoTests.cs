﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsemxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuemxn.Tests
{
	
	///  <summary>
	/// Contém os métodos de teste da classe Emprestimo.
	/// </summary>
	[TestFixture(Description="Classe de testes para a classe RN Emprestimo.", Author="E30277")]
	public class EmprestimoTests : AbstractTesteRegraNegocio<Emprestimo>
	{
		#region Métodos de preparação dos testes
		///  <summary>
		/// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
		/// </summary>
		protected override void BeforeAll()
		{
		}
		///  <summary>
		/// Executa uma ação ANTES de cada método de teste da classe.
		/// </summary>
		protected override void BeforeEach()
		{
		}
		///  <summary>
		/// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
		/// </summary>
		protected override void AfterAll()
		{
		}
		///  <summary>
		/// Executa uma ação DEPOIS de cada método de teste da classe.
		/// </summary>
		protected override void AfterEach()
		{
		}
		///  <summary>
		/// Método para setar os dados necessários para conexão com o PHA no servidor de build.
		/// </summary>
		/// <returns>TO com dados necessários para conexão no servidor de build.</returns>
		protected override TOPhaServidorBuild SetarDadosServidorBuild()
		{
			return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
		}
        #endregion
        #region Métodos de teste de sucesso.
        #region RNs

        ///  <summary>
        /// Realiza o teste padrão para o método RNN01.
        /// </summary>
        [Test(Description = "Testa a RNN01.", Author = "E30277")]
        public void aRN01()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "19";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(retInc,identificador: "Falha_RNEMP01",mensagemEsperada: "Cliente não encontrado.");
        }

        ///  <summary>
        /// Realiza o teste padrão para o método RNN02.
        /// </summary>
        [Test(Description = "Testa a RNN02.", Author = "E30277")]
        public void aRN02()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);
            toEmprestimo.DtInclusao = DateTime.Now.Date.AddDays(1);

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(retInc, identificador: "Falha_RNEMP02", mensagemEsperada: "Data de Inclusão, se informada, deve ser menor ou igual a data atual.");
        }

        ///  <summary>
        /// Realiza o teste padrão para o método RNN03_1.
        /// </summary>
        [Test(Description = "Testa a RNN03_1.", Author = "E30277")]
        public void aRN03_1([Values(999, 1000001)]decimal valor, [Values(0.1, 9.9)]decimal taxa )
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = valor;//valor;
            toEmprestimo.Taxa = taxa;

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(retInc, identificador: "Falha_RNEMP03_1", mensagemEsperada: "O Valor do Empréstimo deve estar compreendido entre R$ 1.000,00 e R$ 1.000.000,00, inclusive.");
        }
        ///  <summary>
        /// Realiza o teste padrão para o método RNN03_2.
        /// </summary>
        [Test(Description = "Testa a RNN03_2.", Author = "E30277")]
        public void aRN03_2( [Values(1000, 1000000)]decimal valor, [Values(0, 10)]decimal taxa)
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = valor;
            toEmprestimo.Taxa = taxa;

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(retInc, identificador: "Falha_RNEMP03_2", mensagemEsperada: "A Taxa do Empréstimo deve ser positiva e menor que 10%");
        }
        ///  <summary>
        /// Realiza o teste padrão para o método RNN04_1.
        /// </summary>
        [Test(Description = "Testa a RNN04_1.", Author = "E30277")]
        public void aRN04_1()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "SP";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(retInc, identificador: "Falha_RNEMP04_1", mensagemEsperada: "São aceitas somente as UFs da região Sul do país.");
        }

        ///  <summary>
        /// Realiza o teste padrão para o método RNN04_2.
        /// </summary>
        [Test(Description = "Testa a RNN04_2.", Author = "E30277")]
        public void aRN04_2()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "430000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(retInc, identificador: "Falha_RNEMP04_2", mensagemEsperada: "O código do município deve ter tamanho 7.");
        }

        ///  <summary>
        /// Realiza o teste padrão para o método RNN04_3.
        /// </summary>
        [Test(Description = "Testa a RNN04_3.", Author = "E30277")]
        public void aRN04_3()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4100000";
            toEmprestimo.Uf = "sc";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.FalhaComMensagem<Mensagem>(retInc, identificador: "Falha_RNEMP04_3", mensagemEsperada: "Para UF SC, o Código do Município deve ser iniciado por 42.");
        }

        ///  <summary>
        /// Realiza o teste padrão para o método RNN05.
        /// </summary>
        [Test(Description = "Testa a RNN05.", Author = "E30277")]
        public void aRN05()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Juridica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb2 = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb2);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb2.Dados);
            toClientePxc.CodCliente = "84574111000100";

            Retorno<int> retAlt = RN.Alterar(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retAlt, identificador: "Falha_RNEMP05", mensagemEsperada: "Não é possível alterar o empréstimo, pois o mesmo não faz parte dos empréstimos do cliente informado.");
        }

        ///  <summary>
        /// Realiza o teste padrão para o método RNN06.
        /// </summary>
        [Test(Description = "Testa a RNN06.", Author = "E30277")]
        public void aRN06()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);
            toEmprestimo.DtCancelamento = DateTime.Now.Date;
            toEmprestimo.DtPagto = DateTime.Now.Date;
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb);

            MMAssert.IsFalse(retOb.Dados.DtPagto.TemConteudo);
            MMAssert.IsFalse(retOb.Dados.DtCancelamento.TemConteudo);
            DateTime a = retOb.Dados.DtInclusao;

            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb.Dados);
            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].DtInclusao = new DateTime(2020, 3, 2);

            TestarAlterar<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb2 = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb2);

            MMAssert.AreEqual(DateTime.Now.Date, retOb.Dados.DtInclusao.LerConteudoOuPadrao(), "Data inclusão alterou para {0}", retOb.Dados.DtInclusao.LerConteudoOuPadrao().ToString());
        }

        ///  <summary>
        /// Realiza o teste padrão para o método RNN07.
        /// </summary>
        [Test(Description = "Testa a RNN07.", Author = "E30277")]
        public void aRN07()
        {
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Juridica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);

            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb.Dados);
            Retorno<int> retCanc = RN.Cancelar(toClientePxc);
            MMAssert.Sucesso<int>(retCanc);

            Retorno<TOEmprestimo> retOb2 = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb2);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb2.Dados);

            Retorno<int> retAlt = RN.Alterar(toClientePxc);

            MMAssert.FalhaComMensagem<Mensagem>(retAlt, identificador: "Falha_RNEMP07", mensagemEsperada: "Só é possível alterar empréstimo ativo.");
        }

        #endregion
        ///  <summary>
        /// Realiza o teste padrão para o método Alterar(TOClientePxc).
        /// Validações realizadas: 
        /// - Altera o registro na base, conforme os dados informados.
        /// - Verifica se o retorno do método Alterar foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Obtém o TO novamente da base, utilizando o método Obter.
        /// - Compara o retorno do Obter com os dados do TO preenchido.
        /// </summary>
        [Test(Description="Testa o método Alterar(TOClientePxc).", Author="E30277")]
		public void AlterarComSucessoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar valores necessários para o toClientePxc
			 toClientePxc.CodCliente = "191";
			toClientePxc.TipoPessoa = TipoPessoa.Fisica;
			toClientePxc.Emprestimos = new List<TOEmprestimo>();
			TOEmprestimo toEmprestimo = new TOEmprestimo();
			toEmprestimo.CodMunicipio = "4300000";
			toEmprestimo.Uf = "RS";
			toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
			toEmprestimo.Taxa = Convert.ToDecimal(1);

			toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);

            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb.Dados);

            TestarAlterar<TOClientePxc, TOEmprestimo>(toClientePxc);

        }
		///  <summary>
		/// Realiza o teste padrão para o método Contar(TOClientePxc).
		/// Validações realizadas: 
		/// - Chama o Contar usando os filtros informados.
		/// - Verifica se o retorno do método Contar foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// 4 - Retorno.Dados não é zero.
		/// 
		/// </summary>
		[Test(Description="Testa o método Contar(TOClientePxc).", Author="E30277")]
		public void ContarComSucessoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar valores necessários para o toClientePxc
			 toClientePxc.CodCliente = "191";
			toClientePxc.TipoPessoa = TipoPessoa.Fisica;
			toClientePxc.Emprestimos = new List<TOEmprestimo>();
			TOEmprestimo toEmprestimo = new TOEmprestimo();
			toEmprestimo.CodMunicipio = "4300000";
			toEmprestimo.Uf = "RS";
			toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
			toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			base.TestarContar(toClientePxc);
		}
		///  <summary>
		/// Realiza o teste padrão para o método Excluir(TOClientePxc).
		/// Validações realizadas: 
		/// - Exclui o registro na base, conforme a chave informada.
		/// - Verifica se o retorno do método Excluir foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// - Tenta obter o registro novamente da base, através do método Obter.
		/// - Verifica se o registro não existe mais.
		/// </summary>
		[Test(Description="Testa o método Excluir(TOClientePxc).", Author="E30277")]
		public void ExcluirComSucessoTest()
		{
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);
            // toClientePxc.IndFuncBanrisul = ;
            // toClientePxc.NomeFantasia = ;
            // toClientePxc.NomeMae = ;
            // toClientePxc.UltNossoNro = ;
            // toClientePxc.VlrCapitalSocial = ;
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
            // toClientePxc.Cartoes = ;
            // toClientePxc.Filiais = ;
            // toClientePxc.Extratos = ;
            // toClientePxc.Emprestimos = ;
            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb.Dados);
            Retorno<int> retCanc = RN.Cancelar(toClientePxc);
            MMAssert.Sucesso<int>(retCanc);

            Retorno<TOEmprestimo> retOb2 = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb2);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb2.Dados);

            base.TestarExcluir<TOClientePxc, TOEmprestimo>(toClientePxc);
		}
		///  <summary>
		/// Realiza o teste padrão para o método Incluir(TOClientePxc).
		/// Validações realizadas: 
		/// - Chama o método Incluir usando os filtros informados.
		/// - Verifica se o retorno do método Incluir foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// - Obtém o TO novamente da base, utilizando o método Obter.
		/// - Compara o retorno do Obter com os dados do TO preenchido.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc).", Author="E30277")]
		public void IncluirComSucessoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
             toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);
            // toClientePxc.IndFuncBanrisul = ;
            // toClientePxc.NomeFantasia = ;
            // toClientePxc.NomeMae = ;
            // toClientePxc.UltNossoNro = ;
            // toClientePxc.VlrCapitalSocial = ;
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
            // toClientePxc.Cartoes = ;
            // toClientePxc.Filiais = ;
            // toClientePxc.Extratos = ;
            // toClientePxc.Emprestimos = ;
        
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
            base.TestarIncluir<TOClientePxc,TOEmprestimo>(toClientePxc);
		}
		///  <summary>
		/// Realiza um teste para o método Listar.
		/// </summary>
		[Test(Description="Testa o método Listar(TOClientePxc, TOPaginacao).", Author="E30277")]
		public void ListarComSucessoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			 toClientePxc.CodCliente = "191";
			toClientePxc.TipoPessoa = TipoPessoa.Fisica;
			toClientePxc.Emprestimos = new List<TOEmprestimo>();
			TOEmprestimo toEmprestimo = new TOEmprestimo();
			toEmprestimo.CodMunicipio = "4300000";
			toEmprestimo.Uf = "RS";
			toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
			toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			TOPaginacao toPaginacao = null;
			// TODO: Setar os valores necessários para o toPaginacao
			Retorno<TOClientePxc> retorno = this.RN.Listar(toClientePxc, toPaginacao);
			MMAssert.Sucesso(retorno);
			// TODO: Incluir as Assertivas necessárias para o Listar
		}
		///  <summary>
		/// Realiza o teste padrão para o método Obter(TOClientePxc).
		/// Validações realizadas: 
		/// - Chama o método Obter usando os filtros de chave informados.
		/// - Verifica se o retorno do método Obter foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
		/// </summary>
		[Test(Description="Testa o método Obter(TOClientePxc).", Author="E30277")]
		public void ObterComSucessoTest()
		{
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);
            // toClientePxc.IndFuncBanrisul = ;
            // toClientePxc.NomeFantasia = ;
            // toClientePxc.NomeMae = ;
            // toClientePxc.UltNossoNro = ;
            // toClientePxc.VlrCapitalSocial = ;
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
            // toClientePxc.Cartoes = ;
            // toClientePxc.Filiais = ;
            // toClientePxc.Extratos = ;
            // toClientePxc.Emprestimos = ;
            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb);
        }
		///  <summary>
		/// Realiza um teste para o método Pagar.
		/// </summary>
		[Test(Description="Testa o método Pagar(TOClientePxc).", Author="E30277")]
		public void PagarComSucessoTest()
		{
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);
            // toClientePxc.IndFuncBanrisul = ;
            // toClientePxc.NomeFantasia = ;
            // toClientePxc.NomeMae = ;
            // toClientePxc.UltNossoNro = ;
            // toClientePxc.VlrCapitalSocial = ;
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
            // toClientePxc.Cartoes = ;
            // toClientePxc.Filiais = ;
            // toClientePxc.Extratos = ;
            // toClientePxc.Emprestimos = ;
            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb.Dados);

            Retorno<Int32> retorno = this.RN.Pagar(toClientePxc);
            MMAssert.Sucesso(retorno);
            // TODO: Incluir as Assertivas necessárias para o Cancelar
        }
        ///  <summary>
        /// Realiza um teste para o método Cancelar.
        /// </summary>
        [Test(Description="Testa o método Cancelar(TOClientePxc).", Author="E30277")]
		public void CancelarComSucessoTest()
		{
            TOClientePxc toClientePxc = new TOClientePxc();
            // TODO: Setar valores necessários para o toClientePxc
            toClientePxc.CodCliente = "191";
            toClientePxc.TipoPessoa = TipoPessoa.Fisica;
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            TOEmprestimo toEmprestimo = new TOEmprestimo();
            toEmprestimo.CodMunicipio = "4300000";
            toEmprestimo.Uf = "RS";
            toEmprestimo.ValorEmp = Convert.ToDecimal(2000.00);
            toEmprestimo.Taxa = Convert.ToDecimal(1);
            // toClientePxc.IndFuncBanrisul = ;
            // toClientePxc.NomeFantasia = ;
            // toClientePxc.NomeMae = ;
            // toClientePxc.UltNossoNro = ;
            // toClientePxc.VlrCapitalSocial = ;
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
            // toClientePxc.Cartoes = ;
            // toClientePxc.Filiais = ;
            // toClientePxc.Extratos = ;
            // toClientePxc.Emprestimos = ;
            Retorno<int> retInc = RN.Incluir(toClientePxc);
            MMAssert.SucessoIncluir(retInc);

            toClientePxc.Emprestimos.LerConteudoOuPadrao()[0].CodEmprestimo = retInc.Dados;

            TestarObter<TOClientePxc, TOEmprestimo>(toClientePxc);

            Retorno<TOEmprestimo> retOb = RN.Obter(toClientePxc);
            MMAssert.Sucesso<TOEmprestimo>(retOb);
            toClientePxc.Emprestimos = new List<TOEmprestimo>();
            toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(retOb.Dados);

            Retorno<Int32> retorno = this.RN.Cancelar(toClientePxc);
			MMAssert.Sucesso(retorno);
			// TODO: Incluir as Assertivas necessárias para o Cancelar
		}
		///  <summary>
		/// Realiza um teste para o método ListarCidades.
		/// </summary>
		[Test(Description="Testa o método ListarCidades(TOBnjtmul).", Author="E30277")]
		public void ListarCidadesComSucessoTest()
		{
			TOBnjtmul toBnjtmul = new TOBnjtmul();
			// TODO: Setar os valores necessários para o toBnjtmul
			// toBnjtmul.CodMunici = ;
			// toBnjtmul.Uf = ;
			// toBnjtmul.Municipio = ;
			Retorno<List<TOBnjtmul>> retorno = this.RN.ListarCidades(toBnjtmul);
			MMAssert.Sucesso(retorno);
			// TODO: Incluir as Assertivas necessárias para o ListarCidades
		}
		#endregion
		#region Teste de falha de campo obrigatório
		///  <summary>
		/// Realiza um teste para o método Alterar com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Alterar(TOClientePxc) com falha de campo obrigatório (CodCliente)." +
			"", Author="E30277")]
		public void AlterarFalhaCampoObrigatorioCodClienteTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.UltAtualizacao = new System.DateTime();
			Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "COD_CLIENTE");
			// TODO: Incluir as Assertivas necessárias para o Alterar
		}
		///  <summary>
		/// Realiza um teste para o método Alterar com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Alterar(TOClientePxc) com falha de campo obrigatório (TipoPessoa)." +
			"", Author="E30277")]
		public void AlterarFalhaCampoObrigatorioTipoPessoaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
			Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "TIPO_PESSOA");
			// TODO: Incluir as Assertivas necessárias para o Alterar
		}
		///  <summary>
		/// Realiza um teste para o método Alterar com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Alterar(TOClientePxc) com falha de campo obrigatório (UltAtualizac" +
			"ao).", Author="E30277")]
		public void AlterarFalhaCampoObrigatorioUltAtualizacaoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "ULT_ATUALIZACAO");
			// TODO: Incluir as Assertivas necessárias para o Alterar
		}
		///  <summary>
		/// Realiza um teste para o método Excluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Excluir(TOClientePxc) com falha de campo obrigatório (CodCliente)." +
			"", Author="E30277")]
		public void ExcluirFalhaCampoObrigatorioCodClienteTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.UltAtualizacao = new System.DateTime();
			Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "COD_CLIENTE");
			// TODO: Incluir as Assertivas necessárias para o Excluir
		}
		///  <summary>
		/// Realiza um teste para o método Excluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Excluir(TOClientePxc) com falha de campo obrigatório (TipoPessoa)." +
			"", Author="E30277")]
		public void ExcluirFalhaCampoObrigatorioTipoPessoaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
			Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "TIPO_PESSOA");
			// TODO: Incluir as Assertivas necessárias para o Excluir
		}
		///  <summary>
		/// Realiza um teste para o método Excluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Excluir(TOClientePxc) com falha de campo obrigatório (UltAtualizac" +
			"ao).", Author="E30277")]
		public void ExcluirFalhaCampoObrigatorioUltAtualizacaoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "ULT_ATUALIZACAO");
			// TODO: Incluir as Assertivas necessárias para o Excluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc) com falha de campo obrigatório (CodCliente)." +
			"", Author="E30277")]
		public void IncluirFalhaCampoObrigatorioCodClienteTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "COD_CLIENTE");
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc) com falha de campo obrigatório (TipoPessoa)." +
			"", Author="E30277")]
		public void IncluirFalhaCampoObrigatorioTipoPessoaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "TIPO_PESSOA");
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc) com falha de campo obrigatório (Agencia).", Author="E30277")]
		public void IncluirFalhaCampoObrigatorioAgenciaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "AGENCIA");
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc) com falha de campo obrigatório (CodOperador)" +
			".", Author="E30277")]
		public void IncluirFalhaCampoObrigatorioCodOperadorTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "COD_OPERADOR");
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc) com falha de campo obrigatório (DtAbeCad).", Author="E30277")]
		public void IncluirFalhaCampoObrigatorioDtAbeCadTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "DT_ABE_CAD");
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc) com falha de campo obrigatório (NomeCliente)" +
			".", Author="E30277")]
		public void IncluirFalhaCampoObrigatorioNomeClienteTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "NOME_CLIENTE");
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Obter com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Obter(TOClientePxc) com falha de campo obrigatório (CodCliente).", Author="E30277")]
		public void ObterFalhaCampoObrigatorioCodClienteTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			Retorno<TOEmprestimo> retorno = this.RN.Obter(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "COD_CLIENTE");
			// TODO: Incluir as Assertivas necessárias para o Obter
		}
		///  <summary>
		/// Realiza um teste para o método Obter com teste de falha de campo obrigatório.
		/// </summary>
		[Test(Description="Testa o método Obter(TOClientePxc) com falha de campo obrigatório (TipoPessoa).", Author="E30277")]
		public void ObterFalhaCampoObrigatorioTipoPessoaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
			Retorno<TOEmprestimo> retorno = this.RN.Obter(toClientePxc);
			MMAssert.FalhaCampoObrigatorio(retorno, "TIPO_PESSOA");
			// TODO: Incluir as Assertivas necessárias para o Obter
		}
		#endregion
		#region Métodos de teste de Falha.
		///  <summary>
		/// Realiza um teste para o método Alterar com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Alterar(TOClientePxc).", Author="E30277")]
		public void AlterarComFalhaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
			//toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			//toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.AlterarComFalha();
			Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);
			MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Alterar
		}
		///  <summary>
		/// Realiza um teste para o método Contar com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Contar(TOClientePxc).", Author="E30277")]
		public void ContarComFalhaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
			//toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			//toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.ContarComFalha();
			Retorno<Int64> retorno = this.RN.Contar(toClientePxc);
			MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Contar
		}
		///  <summary>
		/// Realiza um teste para o método Excluir com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Excluir(TOClientePxc).", Author="E30277")]
		public void ExcluirComFalhaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
		//	toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
		//	toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.ExcluirComFalha();
			Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);
			MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Excluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc).", Author="E30277")]
		public void IncluirComFalhaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
			//toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			//toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.IncluirComFalha();
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Obter com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Obter(TOClientePxc).", Author="E30277")]
		public void ObterComFalhaTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
			//toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			//toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.ObterComFalha();
			Retorno<TOEmprestimo> retorno = this.RN.Obter(toClientePxc);
			MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Obter
		}
		#endregion
		#region Métodos de teste de Excecao.
		///  <summary>
		/// Realiza um teste para o método Alterar com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Alterar(TOClientePxc).", Author="E30277")]
		public void AlterarComExcecaoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
			//toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			//toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.AlterarComExcecao();
			Retorno<Int32> retorno = this.RN.Alterar(toClientePxc);
			MMAssert.Excecao<Exception>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Alterar
		}
		///  <summary>
		/// Realiza um teste para o método Contar com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Contar(TOClientePxc).", Author="E30277")]
		public void ContarComExcecaoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
		//	toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
		//	toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.ContarComExcecao();
			Retorno<Int64> retorno = this.RN.Contar(toClientePxc);
			MMAssert.Excecao<Exception>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Contar
		}
		///  <summary>
		/// Realiza um teste para o método Excluir com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Excluir(TOClientePxc).", Author="E30277")]
		public void ExcluirComExcecaoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
		//	toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
		//	toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.ExcluirComExcecao();
			Retorno<Int32> retorno = this.RN.Excluir(toClientePxc);
			MMAssert.Excecao<Exception>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Excluir
		}
		///  <summary>
		/// Realiza um teste para o método Incluir com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Incluir(TOClientePxc).", Author="E30277")]
		public void IncluirComExcecaoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
		//	toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
		//	toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.IncluirComExcecao();
			Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);
			MMAssert.Excecao<Exception>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Incluir
		}
		///  <summary>
		/// Realiza um teste para o método Obter com teste de falha.
		/// </summary>
		[Test(Description="Testa o método Obter(TOClientePxc).", Author="E30277")]
		public void ObterComExcecaoTest()
		{
			TOClientePxc toClientePxc = new TOClientePxc();
			// TODO: Setar os valores necessários para o toClientePxc
			toClientePxc.CodCliente = "Inserir um valor para toClientePxc.CodCliente caso necessário.";
		 toClientePxc.TipoPessoa = TipoPessoa.Juridica;
			toClientePxc.Agencia = 0;
			toClientePxc.CodOperador = "Inserir um valor para toClientePxc.CodOperador caso necessário.";
			toClientePxc.DtAbeCad = new System.DateTime();
			toClientePxc.NomeCliente = "Inserir um valor para toClientePxc.NomeCliente caso necessário.";
			toClientePxc.UltAtualizacao = new System.DateTime();
		//	toEmprestimo.Taxa = Convert.ToDecimal(1);
			// toClientePxc.IndFuncBanrisul = ;
			// toClientePxc.NomeFantasia = ;
			// toClientePxc.NomeMae = ;
			// toClientePxc.UltNossoNro = ;
			// toClientePxc.VlrCapitalSocial = ;
			//toClientePxc.Emprestimos.LerConteudoOuPadrao().Add(toEmprestimo);
			// toClientePxc.Cartoes = ;
			// toClientePxc.Filiais = ;
			// toClientePxc.Extratos = ;
			// toClientePxc.Emprestimos = ;
			MockEmprestimo classeMock = new MockEmprestimo(this.Infra);
			classeMock.ObterComExcecao();
			Retorno<TOEmprestimo> retorno = this.RN.Obter(toClientePxc);
			MMAssert.Excecao<Exception>(retorno);
			// TODO: Incluir as Assertivas necessárias para o Obter
		}
		#endregion
	}
}

