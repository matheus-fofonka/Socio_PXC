if(!dojo._hasResource["dijit.tests.Container"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests.Container"] = true;
dojo.provide("dijit.tests.Container");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.Container", dojo.moduleUrl("dijit", "tests/Container.html"));
}

}
