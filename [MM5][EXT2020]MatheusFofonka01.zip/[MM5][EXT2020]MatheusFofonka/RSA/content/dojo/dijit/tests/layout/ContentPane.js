if(!dojo._hasResource["dijit.tests.layout.ContentPane"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests.layout.ContentPane"] = true;
dojo.provide("dijit.tests.layout.ContentPane");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.layout.ContentPane", dojo.moduleUrl("dijit", "tests/layout/ContentPane.html"), 30000);
}

}
