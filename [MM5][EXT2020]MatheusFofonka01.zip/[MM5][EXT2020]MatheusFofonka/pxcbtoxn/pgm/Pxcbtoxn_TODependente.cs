﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela DEPENDENTE da base de dados PXC.</summary>
    public class TODependente : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codDependente;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<String> tipoPessoaDep;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<String> indAtivo;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Int16> agenciaDep;
        private CampoOpcional<DateTime> dataDesligamento;
        private CampoOpcional<DateTime> dataFundacao;
        private CampoOpcional<DateTime> dataNascimento;
        private CampoOpcional<Int16> estadoCivil;
        private CampoOpcional<String> nomeDependente;
        private CampoOpcional<String> nomeFantasia;
        private CampoOpcional<Decimal> percentParticip;
        private CampoOpcional<Int16> regimeCasamento;
        private CampoOpcional<Decimal> valorCapital;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_CLIENTE da tabela DEPENDENTE.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        {
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_DEPENDENTE da tabela DEPENDENTE.</summary>
        [XmlAttribute("cod_dependente")]
        [CampoTabela("COD_DEPENDENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodDependente
        {
            get { return this.codDependente; }
            set { this.codDependente = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela DEPENDENTE.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        {
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo TIPO_PESSOA_DEP da tabela DEPENDENTE.</summary>
        [XmlAttribute("tipo_pessoa_dep")]
        [CampoTabela("TIPO_PESSOA_DEP", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoaDep
        {
            get { return this.tipoPessoaDep; }
            set { this.tipoPessoaDep = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela DEPENDENTE.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo IND_ATIVO da tabela DEPENDENTE.</summary>
        [XmlAttribute("ind_ativo")]
        [CampoTabela("IND_ATIVO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndAtivo
        { 
            get { return this.indAtivo; }
            set { this.indAtivo = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela DEPENDENTE.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo AGENCIA_DEP da tabela DEPENDENTE.</summary>
        [XmlAttribute("agencia_dep")]
        [CampoTabela("AGENCIA_DEP", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> AgenciaDep
        {
            get { return this.agenciaDep; }
            set { this.agenciaDep = value; }
        }

        /// <summary>Campo DATA_DESLIGAMENTO da tabela DEPENDENTE.</summary>
        [XmlAttribute("data_desligamento")]
        [CampoTabela("DATA_DESLIGAMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataDesligamento
        {
            get { return this.dataDesligamento; }
            set { this.dataDesligamento = value; }
        }

        /// <summary>Campo DATA_FUNDACAO da tabela DEPENDENTE.</summary>
        [XmlAttribute("data_fundacao")]
        [CampoTabela("DATA_FUNDACAO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataFundacao
        {
            get { return this.dataFundacao; }
            set { this.dataFundacao = value; }
        }

        /// <summary>Campo DATA_NASCIMENTO da tabela DEPENDENTE.</summary>
        [XmlAttribute("data_nascimento")]
        [CampoTabela("DATA_NASCIMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataNascimento
        {
            get { return this.dataNascimento; }
            set { this.dataNascimento = value; }
        }

        /// <summary>Campo ESTADO_CIVIL da tabela DEPENDENTE.</summary>
        [XmlAttribute("estado_civil")]
        [CampoTabela("ESTADO_CIVIL", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> EstadoCivil
        {
            get { return this.estadoCivil; }
            set { this.estadoCivil = value; }
        }

        /// <summary>Campo NOME_DEPENDENTE da tabela DEPENDENTE.</summary>
        [XmlAttribute("nome_dependente")]
        [CampoTabela("NOME_DEPENDENTE", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> NomeDependente
        {
            get { return this.nomeDependente; }
            set { this.nomeDependente = value; }
        }

        /// <summary>Campo NOME_FANTASIA da tabela DEPENDENTE.</summary>
        [XmlAttribute("nome_fantasia")]
        [CampoTabela("NOME_FANTASIA", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> NomeFantasia
        {
            get { return this.nomeFantasia; }
            set { this.nomeFantasia = value; }
        }

        /// <summary>Campo PERCENT_PARTICIP da tabela DEPENDENTE.</summary>
        [XmlAttribute("percent_particip")]
        [CampoTabela("PERCENT_PARTICIP", TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoOpcional<Decimal> PercentParticip
        {
            get { return this.percentParticip; }
            set { this.percentParticip = value; }
        }

        /// <summary>Campo REGIME_CASAMENTO da tabela DEPENDENTE.</summary>
        [XmlAttribute("regime_casamento")]
        [CampoTabela("REGIME_CASAMENTO", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> RegimeCasamento
        {
            get { return this.regimeCasamento; }
            set { this.regimeCasamento = value; }
        }

        /// <summary>Campo VALOR_CAPITAL da tabela DEPENDENTE.</summary>
        [XmlAttribute("valor_capital")]
        [CampoTabela("VALOR_CAPITAL", TipoParametro = DbType.Decimal, 
            Tamanho = 18, Precisao = 18, Escala = 2)]
        public CampoOpcional<Decimal> ValorCapital
        {
            get { return this.valorCapital; }
            set { this.valorCapital = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_DEPENDENTE":
                        this.codDependente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA_DEP":
                        this.tipoPessoaDep = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_ATIVO":
                        this.indAtivo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "AGENCIA_DEP":
                        this.agenciaDep = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "DATA_DESLIGAMENTO":
                        this.dataDesligamento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DATA_FUNDACAO":
                        this.dataFundacao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DATA_NASCIMENTO":
                        this.dataNascimento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "ESTADO_CIVIL":
                        this.estadoCivil = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "NOME_DEPENDENTE":
                        this.nomeDependente = this.LerCampoOpcional<String>(campo);
                        if(this.nomeDependente.TemConteudo)
                        {
                            this.nomeDependente = this.nomeDependente.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "NOME_FANTASIA":
                        this.nomeFantasia = this.LerCampoOpcional<String>(campo);
                        if(this.nomeFantasia.TemConteudo)
                        {
                            this.nomeFantasia = this.nomeFantasia.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PERCENT_PARTICIP":
                        this.percentParticip = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "REGIME_CASAMENTO":
                        this.regimeCasamento = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "VALOR_CAPITAL":
                        this.valorCapital = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}