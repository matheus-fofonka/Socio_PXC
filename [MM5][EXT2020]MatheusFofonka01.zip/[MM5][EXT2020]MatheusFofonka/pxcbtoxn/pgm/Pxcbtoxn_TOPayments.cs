﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela PAYMENTS da base de dados PXC.</summary>
    public class TOPayments : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int32> customernumber;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> amount;
        private CampoOpcional<String> checknumber;
        private CampoOpcional<DateTime> paymentdate;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CUSTOMERNUMBER da tabela PAYMENTS.</summary>
        [XmlAttribute("customernumber")]
        [CampoTabela("CUSTOMERNUMBER", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> Customernumber
        { 
            get { return this.customernumber; }
            set { this.customernumber = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo AMOUNT da tabela PAYMENTS.</summary>
        [XmlAttribute("amount")]
        [CampoTabela("AMOUNT", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoOpcional<Decimal> Amount
        {
            get { return this.amount; }
            set { this.amount = value; }
        }

        /// <summary>Campo CHECKNUMBER da tabela PAYMENTS.</summary>
        [XmlAttribute("checknumber")]
        [CampoTabela("CHECKNUMBER", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Checknumber
        {
            get { return this.checknumber; }
            set { this.checknumber = value; }
        }

        /// <summary>Campo PAYMENTDATE da tabela PAYMENTS.</summary>
        [XmlAttribute("paymentdate")]
        [CampoTabela("PAYMENTDATE", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> Paymentdate
        {
            get { return this.paymentdate; }
            set { this.paymentdate = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CUSTOMERNUMBER":
                        this.customernumber = Convert.ToInt32(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "AMOUNT":
                        this.amount = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "CHECKNUMBER":
                        this.checknumber = this.LerCampoOpcional<String>(campo);
                        if(this.checknumber.TemConteudo)
                        {
                            this.checknumber = this.checknumber.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PAYMENTDATE":
                        this.paymentdate = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}