﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_LOCAL da base de dados PXC.</summary>
    public class TOMmdLocal : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codLocal;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> nome;
        private CampoObrigatorio<String> uf;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_LOCAL da tabela MMD_LOCAL.</summary>
        [XmlAttribute("cod_local")]
        [CampoTabela("COD_LOCAL", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<Decimal> CodLocal
        {
            get { return this.codLocal; }
            set { this.codLocal = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo NOME da tabela MMD_LOCAL.</summary>
        [XmlAttribute("nome")]
        [CampoTabela("NOME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Nome
        { 
            get { return this.nome; }
            set { this.nome = value; }
        }

        /// <summary>Campo UF da tabela MMD_LOCAL.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> Uf
        { 
            get { return this.uf; }
            set { this.uf = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_LOCAL":
                        this.codLocal = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "NOME":
                        this.nome = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "UF":
                        this.uf = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}