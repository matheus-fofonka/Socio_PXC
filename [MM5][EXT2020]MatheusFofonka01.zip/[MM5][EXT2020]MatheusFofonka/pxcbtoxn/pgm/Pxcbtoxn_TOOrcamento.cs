﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ORCAMENTO da base de dados PXC.</summary>
    public class TOOrcamento : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codProposta;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codUsuario;
        private CampoObrigatorio<DateTime> dthrUltAtu;
        private CampoObrigatorio<String> unidProdutiva;
        private CampoObrigatorio<Decimal> vlrCusto;
        private CampoObrigatorio<Decimal> vlrReceita;
        private CampoObrigatorio<Decimal> vlrUnidProdutiva;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> unidOrcamento;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_PROPOSTA da tabela ORCAMENTO.</summary>
        [XmlAttribute("cod_proposta")]
        [CampoTabela("COD_PROPOSTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<Decimal> CodProposta
        {
            get { return this.codProposta; }
            set { this.codProposta = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_USUARIO da tabela ORCAMENTO.</summary>
        [XmlAttribute("cod_usuario")]
        [CampoTabela("COD_USUARIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodUsuario
        { 
            get { return this.codUsuario; }
            set { this.codUsuario = value; }
        }

        /// <summary>Campo DTHR_ULT_ATU da tabela ORCAMENTO.</summary>
        [XmlAttribute("dthr_ult_atu")]
        [CampoTabela("DTHR_ULT_ATU", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DthrUltAtu
        { 
            get { return this.dthrUltAtu; }
            set { this.dthrUltAtu = value; }
        }

        /// <summary>Campo UNID_PRODUTIVA da tabela ORCAMENTO.</summary>
        [XmlAttribute("unid_produtiva")]
        [CampoTabela("UNID_PRODUTIVA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<String> UnidProdutiva
        { 
            get { return this.unidProdutiva; }
            set { this.unidProdutiva = value; }
        }

        /// <summary>Campo VLR_CUSTO da tabela ORCAMENTO.</summary>
        [XmlAttribute("vlr_custo")]
        [CampoTabela("VLR_CUSTO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> VlrCusto
        { 
            get { return this.vlrCusto; }
            set { this.vlrCusto = value; }
        }

        /// <summary>Campo VLR_RECEITA da tabela ORCAMENTO.</summary>
        [XmlAttribute("vlr_receita")]
        [CampoTabela("VLR_RECEITA", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> VlrReceita
        { 
            get { return this.vlrReceita; }
            set { this.vlrReceita = value; }
        }

        /// <summary>Campo VLR_UNID_PRODUTIVA da tabela ORCAMENTO.</summary>
        [XmlAttribute("vlr_unid_produtiva")]
        [CampoTabela("VLR_UNID_PRODUTIVA", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> VlrUnidProdutiva
        { 
            get { return this.vlrUnidProdutiva; }
            set { this.vlrUnidProdutiva = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo UNID_ORCAMENTO da tabela ORCAMENTO.</summary>
        [XmlAttribute("unid_orcamento")]
        [CampoTabela("UNID_ORCAMENTO", TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<String> UnidOrcamento
        {
            get { return this.unidOrcamento; }
            set { this.unidOrcamento = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_PROPOSTA":
                        this.codProposta = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_USUARIO":
                        this.codUsuario = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DTHR_ULT_ATU":
                        this.dthrUltAtu = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "UNID_PRODUTIVA":
                        this.unidProdutiva = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "VLR_CUSTO":
                        this.vlrCusto = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "VLR_RECEITA":
                        this.vlrReceita = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "VLR_UNID_PRODUTIVA":
                        this.vlrUnidProdutiva = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "UNID_ORCAMENTO":
                        this.unidOrcamento = this.LerCampoOpcional<String>(campo);
                        if(this.unidOrcamento.TemConteudo)
                        {
                            this.unidOrcamento = this.unidOrcamento.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}