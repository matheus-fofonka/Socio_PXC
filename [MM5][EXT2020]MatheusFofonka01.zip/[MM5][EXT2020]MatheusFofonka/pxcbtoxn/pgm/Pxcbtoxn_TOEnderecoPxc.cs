﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ENDERECO_PXC da base de dados PXC.</summary>
    public class TOEnderecoPxc : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codEndereco;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> bairro;
        private CampoObrigatorio<String> cep;
        private CampoObrigatorio<String> cidade;
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<Int16> codSituacao;
        private CampoObrigatorio<Int16> codTipoEndereco;
        private CampoObrigatorio<String> logradouro;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<String> uf;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> complemento;
        private CampoOpcional<String> indTitular;
        private CampoOpcional<Int32> numero;
        private CampoOpcional<Int16> resideDesde;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_ENDERECO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("cod_endereco")]
        [CampoTabela("COD_ENDERECO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodEndereco
        {
            get { return this.codEndereco; }
            set { this.codEndereco = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo BAIRRO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("bairro")]
        [CampoTabela("BAIRRO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoObrigatorio<String> Bairro
        { 
            get { return this.bairro; }
            set { this.bairro = value; }
        }

        /// <summary>Campo CEP da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> Cep
        { 
            get { return this.cep; }
            set { this.cep = value; }
        }

        /// <summary>Campo CIDADE da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("cidade")]
        [CampoTabela("CIDADE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> Cidade
        { 
            get { return this.cidade; }
            set { this.cidade = value; }
        }

        /// <summary>Campo COD_CLIENTE da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo COD_SITUACAO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("cod_situacao")]
        [CampoTabela("COD_SITUACAO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> CodSituacao
        { 
            get { return this.codSituacao; }
            set { this.codSituacao = value; }
        }

        /// <summary>Campo COD_TIPO_ENDERECO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("cod_tipo_endereco")]
        [CampoTabela("COD_TIPO_ENDERECO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> CodTipoEndereco
        { 
            get { return this.codTipoEndereco; }
            set { this.codTipoEndereco = value; }
        }

        /// <summary>Campo LOGRADOURO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("logradouro")]
        [CampoTabela("LOGRADOURO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Logradouro
        { 
            get { return this.logradouro; }
            set { this.logradouro = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo UF da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> Uf
        { 
            get { return this.uf; }
            set { this.uf = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo COMPLEMENTO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("complemento")]
        [CampoTabela("COMPLEMENTO", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> Complemento
        {
            get { return this.complemento; }
            set { this.complemento = value; }
        }

        /// <summary>Campo IND_TITULAR da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("ind_titular")]
        [CampoTabela("IND_TITULAR", TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoOpcional<String> IndTitular
        {
            get { return this.indTitular; }
            set { this.indTitular = value; }
        }

        /// <summary>Campo NUMERO da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("numero")]
        [CampoTabela("NUMERO", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> Numero
        {
            get { return this.numero; }
            set { this.numero = value; }
        }

        /// <summary>Campo RESIDE_DESDE da tabela ENDERECO_PXC.</summary>
        [XmlAttribute("reside_desde")]
        [CampoTabela("RESIDE_DESDE", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> ResideDesde
        {
            get { return this.resideDesde; }
            set { this.resideDesde = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_ENDERECO":
                        this.codEndereco = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "BAIRRO":
                        this.bairro = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "CEP":
                        this.cep = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "CIDADE":
                        this.cidade = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_SITUACAO":
                        this.codSituacao = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "COD_TIPO_ENDERECO":
                        this.codTipoEndereco = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "LOGRADOURO":
                        this.logradouro = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "UF":
                        this.uf = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "COMPLEMENTO":
                        this.complemento = this.LerCampoOpcional<String>(campo);
                        if(this.complemento.TemConteudo)
                        {
                            this.complemento = this.complemento.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "IND_TITULAR":
                        this.indTitular = this.LerCampoOpcional<String>(campo);
                        if(this.indTitular.TemConteudo)
                        {
                            this.indTitular = this.indTitular.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "NUMERO":
                        this.numero = this.LerCampoOpcional<Int32>(campo);
                        break;
                    case "RESIDE_DESDE":
                        this.resideDesde = this.LerCampoOpcional<Int16>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}