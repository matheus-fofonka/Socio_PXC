﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela INVESTIMENTO da base de dados PXC.</summary>
    public class TOInvestimento : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<Decimal> codInvestimento;
        private CampoObrigatorio<String> tipoPessoa;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> dataInicio;
        private CampoObrigatorio<String> estado;
        private CampoObrigatorio<String> tipoInvestimento;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valor;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Int16> agencia;
        private CampoOpcional<DateTime> dataFim;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_CLIENTE da tabela INVESTIMENTO.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        {
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_INVESTIMENTO da tabela INVESTIMENTO.</summary>
        [XmlAttribute("cod_investimento")]
        [CampoTabela("COD_INVESTIMENTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 7, Precisao = 7)]
        public CampoObrigatorio<Decimal> CodInvestimento
        {
            get { return this.codInvestimento; }
            set { this.codInvestimento = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela INVESTIMENTO.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        {
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela INVESTIMENTO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DATA_INICIO da tabela INVESTIMENTO.</summary>
        [XmlAttribute("data_inicio")]
        [CampoTabela("DATA_INICIO", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataInicio
        { 
            get { return this.dataInicio; }
            set { this.dataInicio = value; }
        }

        /// <summary>Campo ESTADO da tabela INVESTIMENTO.</summary>
        [XmlAttribute("estado")]
        [CampoTabela("ESTADO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> Estado
        { 
            get { return this.estado; }
            set { this.estado = value; }
        }

        /// <summary>Campo TIPO_INVESTIMENTO da tabela INVESTIMENTO.</summary>
        [XmlAttribute("tipo_investimento")]
        [CampoTabela("TIPO_INVESTIMENTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoInvestimento
        { 
            get { return this.tipoInvestimento; }
            set { this.tipoInvestimento = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela INVESTIMENTO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR da tabela INVESTIMENTO.</summary>
        [XmlAttribute("valor")]
        [CampoTabela("VALOR", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> Valor
        { 
            get { return this.valor; }
            set { this.valor = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo AGENCIA da tabela INVESTIMENTO.</summary>
        [XmlAttribute("agencia")]
        [CampoTabela("AGENCIA", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> Agencia
        {
            get { return this.agencia; }
            set { this.agencia = value; }
        }

        /// <summary>Campo DATA_FIM da tabela INVESTIMENTO.</summary>
        [XmlAttribute("data_fim")]
        [CampoTabela("DATA_FIM", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataFim
        {
            get { return this.dataFim; }
            set { this.dataFim = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_INVESTIMENTO":
                        this.codInvestimento = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_INICIO":
                        this.dataInicio = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "ESTADO":
                        this.estado = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_INVESTIMENTO":
                        this.tipoInvestimento = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR":
                        this.valor = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "AGENCIA":
                        this.agencia = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "DATA_FIM":
                        this.dataFim = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}