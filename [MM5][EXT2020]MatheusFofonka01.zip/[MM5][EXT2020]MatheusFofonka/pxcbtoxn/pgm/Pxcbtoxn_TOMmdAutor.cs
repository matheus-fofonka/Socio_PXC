﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_AUTOR da base de dados PXC.</summary>
    public class TOMmdAutor : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codigo;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> codNacionalidade;
        private CampoObrigatorio<String> nome;
        private CampoObrigatorio<String> sobrenome;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CODIGO da tabela MMD_AUTOR.</summary>
        [XmlAttribute("codigo")]
        [CampoTabela("CODIGO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> Codigo
        {
            get { return this.codigo; }
            set { this.codigo = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_NACIONALIDADE da tabela MMD_AUTOR.</summary>
        [XmlAttribute("cod_nacionalidade")]
        [CampoTabela("COD_NACIONALIDADE", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 3, Precisao = 3)]
        public CampoObrigatorio<Decimal> CodNacionalidade
        { 
            get { return this.codNacionalidade; }
            set { this.codNacionalidade = value; }
        }

        /// <summary>Campo NOME da tabela MMD_AUTOR.</summary>
        [XmlAttribute("nome")]
        [CampoTabela("NOME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> Nome
        { 
            get { return this.nome; }
            set { this.nome = value; }
        }

        /// <summary>Campo SOBRENOME da tabela MMD_AUTOR.</summary>
        [XmlAttribute("sobrenome")]
        [CampoTabela("SOBRENOME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> Sobrenome
        { 
            get { return this.sobrenome; }
            set { this.sobrenome = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CODIGO":
                        this.codigo = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_NACIONALIDADE":
                        this.codNacionalidade = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "NOME":
                        this.nome = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "SOBRENOME":
                        this.sobrenome = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}