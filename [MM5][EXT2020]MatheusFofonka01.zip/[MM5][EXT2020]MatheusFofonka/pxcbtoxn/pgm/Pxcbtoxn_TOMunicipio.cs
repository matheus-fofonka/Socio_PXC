﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MUNICIPIO da base de dados PXC.</summary>
    public class TOMunicipio : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codMunicipio;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codUsuario;
        private CampoObrigatorio<String> descrMunicipio;
        private CampoObrigatorio<DateTime> dthrUltAtu;
        private CampoObrigatorio<String> ufMunicipio;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_MUNICIPIO da tabela MUNICIPIO.</summary>
        [XmlAttribute("cod_municipio")]
        [CampoTabela("COD_MUNICIPIO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodMunicipio
        {
            get { return this.codMunicipio; }
            set { this.codMunicipio = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_USUARIO da tabela MUNICIPIO.</summary>
        [XmlAttribute("cod_usuario")]
        [CampoTabela("COD_USUARIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodUsuario
        { 
            get { return this.codUsuario; }
            set { this.codUsuario = value; }
        }

        /// <summary>Campo DESCR_MUNICIPIO da tabela MUNICIPIO.</summary>
        [XmlAttribute("descr_municipio")]
        [CampoTabela("DESCR_MUNICIPIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> DescrMunicipio
        { 
            get { return this.descrMunicipio; }
            set { this.descrMunicipio = value; }
        }

        /// <summary>Campo DTHR_ULT_ATU da tabela MUNICIPIO.</summary>
        [XmlAttribute("dthr_ult_atu")]
        [CampoTabela("DTHR_ULT_ATU", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DthrUltAtu
        { 
            get { return this.dthrUltAtu; }
            set { this.dthrUltAtu = value; }
        }

        /// <summary>Campo UF_MUNICIPIO da tabela MUNICIPIO.</summary>
        [XmlAttribute("uf_municipio")]
        [CampoTabela("UF_MUNICIPIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> UfMunicipio
        { 
            get { return this.ufMunicipio; }
            set { this.ufMunicipio = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_MUNICIPIO":
                        this.codMunicipio = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_USUARIO":
                        this.codUsuario = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DESCR_MUNICIPIO":
                        this.descrMunicipio = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DTHR_ULT_ATU":
                        this.dthrUltAtu = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "UF_MUNICIPIO":
                        this.ufMunicipio = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}