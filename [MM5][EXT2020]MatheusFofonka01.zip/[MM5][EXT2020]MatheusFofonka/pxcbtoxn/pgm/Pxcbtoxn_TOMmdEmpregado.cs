﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_EMPREGADO da base de dados PXC.</summary>
    public class TOMmdEmpregado : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codEmpregado;
        private CampoObrigatorio<Decimal> ncEmpregado;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> codCcusto;
        private CampoObrigatorio<Decimal> cpf;
        private CampoObrigatorio<DateTime> dataAdmissao;
        private CampoObrigatorio<DateTime> dataNascimento;
        private CampoObrigatorio<String> nomeEmpregado;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> cep;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_EMPREGADO da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("cod_empregado")]
        [CampoTabela("COD_EMPREGADO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodEmpregado
        {
            get { return this.codEmpregado; }
            set { this.codEmpregado = value; }
        }

        /// <summary>Campo NC_EMPREGADO da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("nc_empregado")]
        [CampoTabela("NC_EMPREGADO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Decimal> NcEmpregado
        {
            get { return this.ncEmpregado; }
            set { this.ncEmpregado = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CCUSTO da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("cod_ccusto")]
        [CampoTabela("COD_CCUSTO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<Decimal> CodCcusto
        { 
            get { return this.codCcusto; }
            set { this.codCcusto = value; }
        }

        /// <summary>Campo CPF da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("cpf")]
        [CampoTabela("CPF", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 11, Precisao = 11)]
        public CampoObrigatorio<Decimal> Cpf
        { 
            get { return this.cpf; }
            set { this.cpf = value; }
        }

        /// <summary>Campo DATA_ADMISSAO da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("data_admissao")]
        [CampoTabela("DATA_ADMISSAO", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataAdmissao
        { 
            get { return this.dataAdmissao; }
            set { this.dataAdmissao = value; }
        }

        /// <summary>Campo DATA_NASCIMENTO da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("data_nascimento")]
        [CampoTabela("DATA_NASCIMENTO", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataNascimento
        { 
            get { return this.dataNascimento; }
            set { this.dataNascimento = value; }
        }

        /// <summary>Campo NOME_EMPREGADO da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("nome_empregado")]
        [CampoTabela("NOME_EMPREGADO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> NomeEmpregado
        { 
            get { return this.nomeEmpregado; }
            set { this.nomeEmpregado = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo CEP da tabela MMD_EMPREGADO.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", TipoParametro = DbType.Decimal, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<Decimal> Cep
        {
            get { return this.cep; }
            set { this.cep = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_EMPREGADO":
                        this.codEmpregado = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "NC_EMPREGADO":
                        this.ncEmpregado = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CCUSTO":
                        this.codCcusto = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "CPF":
                        this.cpf = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "DATA_ADMISSAO":
                        this.dataAdmissao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DATA_NASCIMENTO":
                        this.dataNascimento = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "NOME_EMPREGADO":
                        this.nomeEmpregado = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CEP":
                        this.cep = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}