﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela PROPOSTA da base de dados PXC.</summary>
    public class TOProposta : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codProposta;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int32> codAtividade;
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<Int32> codMunicipio;
        private CampoObrigatorio<Int32> codOrigem;
        private CampoObrigatorio<String> codUsuario;
        private CampoObrigatorio<DateTime> dataProposta;
        private CampoObrigatorio<DateTime> dthrUltAtu;
        private CampoObrigatorio<String> indArrendamento;
        private CampoObrigatorio<String> indProjTecnico;
        private CampoObrigatorio<String> indSegurada;
        private CampoObrigatorio<String> indSituacao;
        private CampoObrigatorio<String> tipoPessoa;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> cpfTecnico;
        private CampoOpcional<DateTime> dtAssinatura;
        private CampoOpcional<DateTime> dtPrimParcela;
        private CampoOpcional<Int32> qtdeParcela;
        private CampoOpcional<Decimal> vlrArrendamento;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_PROPOSTA da tabela PROPOSTA.</summary>
        [XmlAttribute("cod_proposta")]
        [CampoTabela("COD_PROPOSTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<Decimal> CodProposta
        {
            get { return this.codProposta; }
            set { this.codProposta = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_ATIVIDADE da tabela PROPOSTA.</summary>
        [XmlAttribute("cod_atividade")]
        [CampoTabela("COD_ATIVIDADE", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodAtividade
        { 
            get { return this.codAtividade; }
            set { this.codAtividade = value; }
        }

        /// <summary>Campo COD_CLIENTE da tabela PROPOSTA.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_MUNICIPIO da tabela PROPOSTA.</summary>
        [XmlAttribute("cod_municipio")]
        [CampoTabela("COD_MUNICIPIO", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodMunicipio
        { 
            get { return this.codMunicipio; }
            set { this.codMunicipio = value; }
        }

        /// <summary>Campo COD_ORIGEM da tabela PROPOSTA.</summary>
        [XmlAttribute("cod_origem")]
        [CampoTabela("COD_ORIGEM", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodOrigem
        { 
            get { return this.codOrigem; }
            set { this.codOrigem = value; }
        }

        /// <summary>Campo COD_USUARIO da tabela PROPOSTA.</summary>
        [XmlAttribute("cod_usuario")]
        [CampoTabela("COD_USUARIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodUsuario
        { 
            get { return this.codUsuario; }
            set { this.codUsuario = value; }
        }

        /// <summary>Campo DATA_PROPOSTA da tabela PROPOSTA.</summary>
        [XmlAttribute("data_proposta")]
        [CampoTabela("DATA_PROPOSTA", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataProposta
        { 
            get { return this.dataProposta; }
            set { this.dataProposta = value; }
        }

        /// <summary>Campo DTHR_ULT_ATU da tabela PROPOSTA.</summary>
        [XmlAttribute("dthr_ult_atu")]
        [CampoTabela("DTHR_ULT_ATU", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DthrUltAtu
        { 
            get { return this.dthrUltAtu; }
            set { this.dthrUltAtu = value; }
        }

        /// <summary>Campo IND_ARRENDAMENTO da tabela PROPOSTA.</summary>
        [XmlAttribute("ind_arrendamento")]
        [CampoTabela("IND_ARRENDAMENTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndArrendamento
        { 
            get { return this.indArrendamento; }
            set { this.indArrendamento = value; }
        }

        /// <summary>Campo IND_PROJ_TECNICO da tabela PROPOSTA.</summary>
        [XmlAttribute("ind_proj_tecnico")]
        [CampoTabela("IND_PROJ_TECNICO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndProjTecnico
        { 
            get { return this.indProjTecnico; }
            set { this.indProjTecnico = value; }
        }

        /// <summary>Campo IND_SEGURADA da tabela PROPOSTA.</summary>
        [XmlAttribute("ind_segurada")]
        [CampoTabela("IND_SEGURADA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndSegurada
        { 
            get { return this.indSegurada; }
            set { this.indSegurada = value; }
        }

        /// <summary>Campo IND_SITUACAO da tabela PROPOSTA.</summary>
        [XmlAttribute("ind_situacao")]
        [CampoTabela("IND_SITUACAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndSituacao
        { 
            get { return this.indSituacao; }
            set { this.indSituacao = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela PROPOSTA.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo CPF_TECNICO da tabela PROPOSTA.</summary>
        [XmlAttribute("cpf_tecnico")]
        [CampoTabela("CPF_TECNICO", TipoParametro = DbType.Decimal, 
            Tamanho = 11, Precisao = 11)]
        public CampoOpcional<Decimal> CpfTecnico
        {
            get { return this.cpfTecnico; }
            set { this.cpfTecnico = value; }
        }

        /// <summary>Campo DT_ASSINATURA da tabela PROPOSTA.</summary>
        [XmlAttribute("dt_assinatura")]
        [CampoTabela("DT_ASSINATURA", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtAssinatura
        {
            get { return this.dtAssinatura; }
            set { this.dtAssinatura = value; }
        }

        /// <summary>Campo DT_PRIM_PARCELA da tabela PROPOSTA.</summary>
        [XmlAttribute("dt_prim_parcela")]
        [CampoTabela("DT_PRIM_PARCELA", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtPrimParcela
        {
            get { return this.dtPrimParcela; }
            set { this.dtPrimParcela = value; }
        }

        /// <summary>Campo QTDE_PARCELA da tabela PROPOSTA.</summary>
        [XmlAttribute("qtde_parcela")]
        [CampoTabela("QTDE_PARCELA", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> QtdeParcela
        {
            get { return this.qtdeParcela; }
            set { this.qtdeParcela = value; }
        }

        /// <summary>Campo VLR_ARRENDAMENTO da tabela PROPOSTA.</summary>
        [XmlAttribute("vlr_arrendamento")]
        [CampoTabela("VLR_ARRENDAMENTO", TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> VlrArrendamento
        {
            get { return this.vlrArrendamento; }
            set { this.vlrArrendamento = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_PROPOSTA":
                        this.codProposta = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_ATIVIDADE":
                        this.codAtividade = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_MUNICIPIO":
                        this.codMunicipio = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "COD_ORIGEM":
                        this.codOrigem = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "COD_USUARIO":
                        this.codUsuario = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_PROPOSTA":
                        this.dataProposta = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DTHR_ULT_ATU":
                        this.dthrUltAtu = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "IND_ARRENDAMENTO":
                        this.indArrendamento = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_PROJ_TECNICO":
                        this.indProjTecnico = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_SEGURADA":
                        this.indSegurada = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_SITUACAO":
                        this.indSituacao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CPF_TECNICO":
                        this.cpfTecnico = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "DT_ASSINATURA":
                        this.dtAssinatura = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DT_PRIM_PARCELA":
                        this.dtPrimParcela = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "QTDE_PARCELA":
                        this.qtdeParcela = this.LerCampoOpcional<Int32>(campo);
                        break;
                    case "VLR_ARRENDAMENTO":
                        this.vlrArrendamento = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}