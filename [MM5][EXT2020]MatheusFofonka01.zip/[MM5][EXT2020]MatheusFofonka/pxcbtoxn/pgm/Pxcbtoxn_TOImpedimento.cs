﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela IMPEDIMENTO da base de dados PXC.</summary>
    public class TOImpedimento : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codImpedimento;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> dtInclusao;
        private CampoObrigatorio<String> especie;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> cnpjCredor;
        private CampoOpcional<DateTime> dtRegularizacao;
        private CampoOpcional<String> natureza;
        private CampoOpcional<Decimal> valor;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_IMPEDIMENTO da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("cod_impedimento")]
        [CampoTabela("COD_IMPEDIMENTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodImpedimento
        {
            get { return this.codImpedimento; }
            set { this.codImpedimento = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CLIENTE da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DT_INCLUSAO da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("dt_inclusao")]
        [CampoTabela("DT_INCLUSAO", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtInclusao
        { 
            get { return this.dtInclusao; }
            set { this.dtInclusao = value; }
        }

        /// <summary>Campo ESPECIE da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("especie")]
        [CampoTabela("ESPECIE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> Especie
        { 
            get { return this.especie; }
            set { this.especie = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo CNPJ_CREDOR da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("cnpj_credor")]
        [CampoTabela("CNPJ_CREDOR", TipoParametro = DbType.Decimal, 
            Tamanho = 14, Precisao = 14)]
        public CampoOpcional<Decimal> CnpjCredor
        {
            get { return this.cnpjCredor; }
            set { this.cnpjCredor = value; }
        }

        /// <summary>Campo DT_REGULARIZACAO da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("dt_regularizacao")]
        [CampoTabela("DT_REGULARIZACAO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtRegularizacao
        {
            get { return this.dtRegularizacao; }
            set { this.dtRegularizacao = value; }
        }

        /// <summary>Campo NATUREZA da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("natureza")]
        [CampoTabela("NATUREZA", TipoParametro = DbType.String, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<String> Natureza
        {
            get { return this.natureza; }
            set { this.natureza = value; }
        }

        /// <summary>Campo VALOR da tabela IMPEDIMENTO.</summary>
        [XmlAttribute("valor")]
        [CampoTabela("VALOR", TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> Valor
        {
            get { return this.valor; }
            set { this.valor = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_IMPEDIMENTO":
                        this.codImpedimento = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DT_INCLUSAO":
                        this.dtInclusao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "ESPECIE":
                        this.especie = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CNPJ_CREDOR":
                        this.cnpjCredor = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "DT_REGULARIZACAO":
                        this.dtRegularizacao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "NATUREZA":
                        this.natureza = this.LerCampoOpcional<String>(campo);
                        if(this.natureza.TemConteudo)
                        {
                            this.natureza = this.natureza.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "VALOR":
                        this.valor = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}