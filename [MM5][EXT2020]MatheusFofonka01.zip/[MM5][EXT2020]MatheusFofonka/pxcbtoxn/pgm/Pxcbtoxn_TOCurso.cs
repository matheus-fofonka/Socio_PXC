﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CURSO da base de dados PXC.</summary>
    public class TOCurso : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codCurso;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> cargaHoraria;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> dataCriacao;
        private CampoObrigatorio<String> descricao;
        private CampoObrigatorio<String> externo;
        private CampoObrigatorio<String> nomeEntidade;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> coffeeBreak;
        private CampoOpcional<Decimal> custo;
        private CampoOpcional<String> numContrato;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_CURSO da tabela CURSO.</summary>
        [XmlAttribute("cod_curso")]
        [CampoTabela("COD_CURSO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodCurso
        {
            get { return this.codCurso; }
            set { this.codCurso = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CARGA_HORARIA da tabela CURSO.</summary>
        [XmlAttribute("carga_horaria")]
        [CampoTabela("CARGA_HORARIA", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<Decimal> CargaHoraria
        { 
            get { return this.cargaHoraria; }
            set { this.cargaHoraria = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela CURSO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DATA_CRIACAO da tabela CURSO.</summary>
        [XmlAttribute("data_criacao")]
        [CampoTabela("DATA_CRIACAO", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataCriacao
        { 
            get { return this.dataCriacao; }
            set { this.dataCriacao = value; }
        }

        /// <summary>Campo DESCRICAO da tabela CURSO.</summary>
        [XmlAttribute("descricao")]
        [CampoTabela("DESCRICAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 300, Precisao = 255)]
        public CampoObrigatorio<String> Descricao
        { 
            get { return this.descricao; }
            set { this.descricao = value; }
        }

        /// <summary>Campo EXTERNO da tabela CURSO.</summary>
        [XmlAttribute("externo")]
        [CampoTabela("EXTERNO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> Externo
        { 
            get { return this.externo; }
            set { this.externo = value; }
        }

        /// <summary>Campo NOME_ENTIDADE da tabela CURSO.</summary>
        [XmlAttribute("nome_entidade")]
        [CampoTabela("NOME_ENTIDADE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 100, Precisao = 100)]
        public CampoObrigatorio<String> NomeEntidade
        { 
            get { return this.nomeEntidade; }
            set { this.nomeEntidade = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela CURSO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo COFFEE_BREAK da tabela CURSO.</summary>
        [XmlAttribute("coffee_break")]
        [CampoTabela("COFFEE_BREAK", TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoOpcional<String> CoffeeBreak
        {
            get { return this.coffeeBreak; }
            set { this.coffeeBreak = value; }
        }

        /// <summary>Campo CUSTO da tabela CURSO.</summary>
        [XmlAttribute("custo")]
        [CampoTabela("CUSTO", TipoParametro = DbType.Decimal, 
            Tamanho = 9, Precisao = 9, Escala = 2)]
        public CampoOpcional<Decimal> Custo
        {
            get { return this.custo; }
            set { this.custo = value; }
        }

        /// <summary>Campo NUM_CONTRATO da tabela CURSO.</summary>
        [XmlAttribute("num_contrato")]
        [CampoTabela("NUM_CONTRATO", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> NumContrato
        {
            get { return this.numContrato; }
            set { this.numContrato = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CURSO":
                        this.codCurso = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CARGA_HORARIA":
                        this.cargaHoraria = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_CRIACAO":
                        this.dataCriacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DESCRICAO":
                        this.descricao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "EXTERNO":
                        this.externo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME_ENTIDADE":
                        this.nomeEntidade = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "COFFEE_BREAK":
                        this.coffeeBreak = this.LerCampoOpcional<String>(campo);
                        if(this.coffeeBreak.TemConteudo)
                        {
                            this.coffeeBreak = this.coffeeBreak.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CUSTO":
                        this.custo = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "NUM_CONTRATO":
                        this.numContrato = this.LerCampoOpcional<String>(campo);
                        if(this.numContrato.TemConteudo)
                        {
                            this.numContrato = this.numContrato.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}