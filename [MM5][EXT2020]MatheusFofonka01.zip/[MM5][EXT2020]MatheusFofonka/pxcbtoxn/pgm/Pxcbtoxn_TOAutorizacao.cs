﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela AUTORIZACAO da base de dados PXC.</summary>
    public class TOAutorizacao : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> cnpjGestor;
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<DateTime> dtAutorizacao;
        private CampoObrigatorio<String> tipoPessoa;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<String> indCompartilhado;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<DateTime> dtCancelamento;
        private CampoOpcional<String> tipoCompartilhado;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CNPJ_GESTOR da tabela AUTORIZACAO.</summary>
        [XmlAttribute("cnpj_gestor")]
        [CampoTabela("CNPJ_GESTOR", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<Decimal> CnpjGestor
        {
            get { return this.cnpjGestor; }
            set { this.cnpjGestor = value; }
        }

        /// <summary>Campo COD_CLIENTE da tabela AUTORIZACAO.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        {
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo DT_AUTORIZACAO da tabela AUTORIZACAO.</summary>
        [XmlAttribute("dt_autorizacao")]
        [CampoTabela("DT_AUTORIZACAO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Date,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtAutorizacao
        {
            get { return this.dtAutorizacao; }
            set { this.dtAutorizacao = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela AUTORIZACAO.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        {
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela AUTORIZACAO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo IND_COMPARTILHADO da tabela AUTORIZACAO.</summary>
        [XmlAttribute("ind_compartilhado")]
        [CampoTabela("IND_COMPARTILHADO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndCompartilhado
        { 
            get { return this.indCompartilhado; }
            set { this.indCompartilhado = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela AUTORIZACAO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo DT_CANCELAMENTO da tabela AUTORIZACAO.</summary>
        [XmlAttribute("dt_cancelamento")]
        [CampoTabela("DT_CANCELAMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtCancelamento
        {
            get { return this.dtCancelamento; }
            set { this.dtCancelamento = value; }
        }

        /// <summary>Campo TIPO_COMPARTILHADO da tabela AUTORIZACAO.</summary>
        [XmlAttribute("tipo_compartilhado")]
        [CampoTabela("TIPO_COMPARTILHADO", TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoOpcional<String> TipoCompartilhado
        {
            get { return this.tipoCompartilhado; }
            set { this.tipoCompartilhado = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CNPJ_GESTOR":
                        this.cnpjGestor = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DT_AUTORIZACAO":
                        this.dtAutorizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_COMPARTILHADO":
                        this.indCompartilhado = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "DT_CANCELAMENTO":
                        this.dtCancelamento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "TIPO_COMPARTILHADO":
                        this.tipoCompartilhado = this.LerCampoOpcional<String>(campo);
                        if(this.tipoCompartilhado.TemConteudo)
                        {
                            this.tipoCompartilhado = this.tipoCompartilhado.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}