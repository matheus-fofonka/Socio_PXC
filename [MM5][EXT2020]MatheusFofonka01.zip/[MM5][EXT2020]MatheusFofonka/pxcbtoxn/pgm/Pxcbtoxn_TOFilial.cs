﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela FILIAL da base de dados PXC.</summary>
    public class TOFilial : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> cnpjFilial;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<String> nomeFantasiaFil;
        private CampoObrigatorio<String> nomeFilial;
        private CampoObrigatorio<String> situacao;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valorCapital;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> bairro;
        private CampoOpcional<Int32> cep;
        private CampoOpcional<String> cidade;
        private CampoOpcional<String> complemento;
        private CampoOpcional<String> logradouro;
        private CampoOpcional<Decimal> numero;
        private CampoOpcional<String> uf;
        private CampoOpcional<Decimal> valorTotal;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CNPJ_FILIAL da tabela FILIAL.</summary>
        [XmlAttribute("cnpj_filial")]
        [CampoTabela("CNPJ_FILIAL", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<Decimal> CnpjFilial
        {
            get { return this.cnpjFilial; }
            set { this.cnpjFilial = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CLIENTE da tabela FILIAL.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela FILIAL.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo NOME_FANTASIA_FIL da tabela FILIAL.</summary>
        [XmlAttribute("nome_fantasia_fil")]
        [CampoTabela("NOME_FANTASIA_FIL", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> NomeFantasiaFil
        { 
            get { return this.nomeFantasiaFil; }
            set { this.nomeFantasiaFil = value; }
        }

        /// <summary>Campo NOME_FILIAL da tabela FILIAL.</summary>
        [XmlAttribute("nome_filial")]
        [CampoTabela("NOME_FILIAL", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> NomeFilial
        { 
            get { return this.nomeFilial; }
            set { this.nomeFilial = value; }
        }

        /// <summary>Campo SITUACAO da tabela FILIAL.</summary>
        [XmlAttribute("situacao")]
        [CampoTabela("SITUACAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> Situacao
        { 
            get { return this.situacao; }
            set { this.situacao = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela FILIAL.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela FILIAL.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR_CAPITAL da tabela FILIAL.</summary>
        [XmlAttribute("valor_capital")]
        [CampoTabela("VALOR_CAPITAL", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> ValorCapital
        { 
            get { return this.valorCapital; }
            set { this.valorCapital = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo BAIRRO da tabela FILIAL.</summary>
        [XmlAttribute("bairro")]
        [CampoTabela("BAIRRO", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> Bairro
        {
            get { return this.bairro; }
            set { this.bairro = value; }
        }

        /// <summary>Campo CEP da tabela FILIAL.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> Cep
        {
            get { return this.cep; }
            set { this.cep = value; }
        }

        /// <summary>Campo CIDADE da tabela FILIAL.</summary>
        [XmlAttribute("cidade")]
        [CampoTabela("CIDADE", TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoOpcional<String> Cidade
        {
            get { return this.cidade; }
            set { this.cidade = value; }
        }

        /// <summary>Campo COMPLEMENTO da tabela FILIAL.</summary>
        [XmlAttribute("complemento")]
        [CampoTabela("COMPLEMENTO", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> Complemento
        {
            get { return this.complemento; }
            set { this.complemento = value; }
        }

        /// <summary>Campo LOGRADOURO da tabela FILIAL.</summary>
        [XmlAttribute("logradouro")]
        [CampoTabela("LOGRADOURO", TipoParametro = DbType.String, 
            Tamanho = 71, Precisao = 71)]
        public CampoOpcional<String> Logradouro
        {
            get { return this.logradouro; }
            set { this.logradouro = value; }
        }

        /// <summary>Campo NUMERO da tabela FILIAL.</summary>
        [XmlAttribute("numero")]
        [CampoTabela("NUMERO", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<Decimal> Numero
        {
            get { return this.numero; }
            set { this.numero = value; }
        }

        /// <summary>Campo UF da tabela FILIAL.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<String> Uf
        {
            get { return this.uf; }
            set { this.uf = value; }
        }

        /// <summary>Campo VALOR_TOTAL da tabela FILIAL.</summary>
        [XmlAttribute("valor_total")]
        [CampoTabela("VALOR_TOTAL", TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> ValorTotal
        {
            get { return this.valorTotal; }
            set { this.valorTotal = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CNPJ_FILIAL":
                        this.cnpjFilial = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME_FANTASIA_FIL":
                        this.nomeFantasiaFil = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME_FILIAL":
                        this.nomeFilial = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "SITUACAO":
                        this.situacao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR_CAPITAL":
                        this.valorCapital = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "BAIRRO":
                        this.bairro = this.LerCampoOpcional<String>(campo);
                        if(this.bairro.TemConteudo)
                        {
                            this.bairro = this.bairro.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CEP":
                        this.cep = this.LerCampoOpcional<Int32>(campo);
                        break;
                    case "CIDADE":
                        this.cidade = this.LerCampoOpcional<String>(campo);
                        if(this.cidade.TemConteudo)
                        {
                            this.cidade = this.cidade.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "COMPLEMENTO":
                        this.complemento = this.LerCampoOpcional<String>(campo);
                        if(this.complemento.TemConteudo)
                        {
                            this.complemento = this.complemento.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "LOGRADOURO":
                        this.logradouro = this.LerCampoOpcional<String>(campo);
                        if(this.logradouro.TemConteudo)
                        {
                            this.logradouro = this.logradouro.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "NUMERO":
                        this.numero = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "UF":
                        this.uf = this.LerCampoOpcional<String>(campo);
                        if(this.uf.TemConteudo)
                        {
                            this.uf = this.uf.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "VALOR_TOTAL":
                        this.valorTotal = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}