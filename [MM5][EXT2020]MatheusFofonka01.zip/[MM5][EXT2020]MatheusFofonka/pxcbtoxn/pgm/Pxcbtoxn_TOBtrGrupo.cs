﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela BTR_GRUPO da base de dados PXC.</summary>
    public class TOBtrGrupo : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int16> codGrupo;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> categoria;
        private CampoObrigatorio<DateTime> dataCriacao;
        private CampoObrigatorio<String> descGrupo;
        private CampoObrigatorio<String> indExclusao;
        private CampoObrigatorio<String> siglaSistema;
        private CampoObrigatorio<String> titulo;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<String> usuAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Int16> codReferencia;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_GRUPO da tabela BTR_GRUPO.</summary>
        [XmlAttribute("cod_grupo")]
        [CampoTabela("COD_GRUPO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int16,
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> CodGrupo
        {
            get { return this.codGrupo; }
            set { this.codGrupo = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CATEGORIA da tabela BTR_GRUPO.</summary>
        [XmlAttribute("categoria")]
        [CampoTabela("CATEGORIA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> Categoria
        { 
            get { return this.categoria; }
            set { this.categoria = value; }
        }

        /// <summary>Campo DATA_CRIACAO da tabela BTR_GRUPO.</summary>
        [XmlAttribute("data_criacao")]
        [CampoTabela("DATA_CRIACAO", Obrigatorio = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DataCriacao
        { 
            get { return this.dataCriacao; }
            set { this.dataCriacao = value; }
        }

        /// <summary>Campo DESC_GRUPO da tabela BTR_GRUPO.</summary>
        [XmlAttribute("desc_grupo")]
        [CampoTabela("DESC_GRUPO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 128, Precisao = 128)]
        public CampoObrigatorio<String> DescGrupo
        { 
            get { return this.descGrupo; }
            set { this.descGrupo = value; }
        }

        /// <summary>Campo IND_EXCLUSAO da tabela BTR_GRUPO.</summary>
        [XmlAttribute("ind_exclusao")]
        [CampoTabela("IND_EXCLUSAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndExclusao
        { 
            get { return this.indExclusao; }
            set { this.indExclusao = value; }
        }

        /// <summary>Campo SIGLA_SISTEMA da tabela BTR_GRUPO.</summary>
        [XmlAttribute("sigla_sistema")]
        [CampoTabela("SIGLA_SISTEMA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 3, Precisao = 3)]
        public CampoObrigatorio<String> SiglaSistema
        { 
            get { return this.siglaSistema; }
            set { this.siglaSistema = value; }
        }

        /// <summary>Campo TITULO da tabela BTR_GRUPO.</summary>
        [XmlAttribute("titulo")]
        [CampoTabela("TITULO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> Titulo
        { 
            get { return this.titulo; }
            set { this.titulo = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela BTR_GRUPO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo USU_ATUALIZACAO da tabela BTR_GRUPO.</summary>
        [XmlAttribute("usu_atualizacao")]
        [CampoTabela("USU_ATUALIZACAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> UsuAtualizacao
        { 
            get { return this.usuAtualizacao; }
            set { this.usuAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo COD_REFERENCIA da tabela BTR_GRUPO.</summary>
        [XmlAttribute("cod_referencia")]
        [CampoTabela("COD_REFERENCIA", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> CodReferencia
        {
            get { return this.codReferencia; }
            set { this.codReferencia = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_GRUPO":
                        this.codGrupo = Convert.ToInt16(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CATEGORIA":
                        this.categoria = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_CRIACAO":
                        this.dataCriacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DESC_GRUPO":
                        this.descGrupo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_EXCLUSAO":
                        this.indExclusao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "SIGLA_SISTEMA":
                        this.siglaSistema = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TITULO":
                        this.titulo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "USU_ATUALIZACAO":
                        this.usuAtualizacao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "COD_REFERENCIA":
                        this.codReferencia = this.LerCampoOpcional<Int16>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}