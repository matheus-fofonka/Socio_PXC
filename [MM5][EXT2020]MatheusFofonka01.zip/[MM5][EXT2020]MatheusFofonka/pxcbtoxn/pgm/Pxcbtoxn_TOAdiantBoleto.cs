﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ADIANT_BOLETO da base de dados PXC.</summary>
    public class TOAdiantBoleto : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<Int32> codNossoNro;
        private CampoObrigatorio<String> tipoPessoa;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<String> indTotal;
        private CampoObrigatorio<Decimal> taxaAdiant;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<DateTime> dtContratacao;
        private CampoOpcional<Decimal> valorAdiant;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_CLIENTE da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        {
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_NOSSO_NRO da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("cod_nosso_nro")]
        [CampoTabela("COD_NOSSO_NRO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodNossoNro
        {
            get { return this.codNossoNro; }
            set { this.codNossoNro = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        {
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo IND_TOTAL da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("ind_total")]
        [CampoTabela("IND_TOTAL", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndTotal
        { 
            get { return this.indTotal; }
            set { this.indTotal = value; }
        }

        /// <summary>Campo TAXA_ADIANT da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("taxa_adiant")]
        [CampoTabela("TAXA_ADIANT", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 4, Precisao = 4, Escala = 2)]
        public CampoObrigatorio<Decimal> TaxaAdiant
        { 
            get { return this.taxaAdiant; }
            set { this.taxaAdiant = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo DT_CONTRATACAO da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("dt_contratacao")]
        [CampoTabela("DT_CONTRATACAO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtContratacao
        {
            get { return this.dtContratacao; }
            set { this.dtContratacao = value; }
        }

        /// <summary>Campo VALOR_ADIANT da tabela ADIANT_BOLETO.</summary>
        [XmlAttribute("valor_adiant")]
        [CampoTabela("VALOR_ADIANT", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoOpcional<Decimal> ValorAdiant
        {
            get { return this.valorAdiant; }
            set { this.valorAdiant = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_NOSSO_NRO":
                        this.codNossoNro = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_TOTAL":
                        this.indTotal = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TAXA_ADIANT":
                        this.taxaAdiant = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "DT_CONTRATACAO":
                        this.dtContratacao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "VALOR_ADIANT":
                        this.valorAdiant = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        break;
                }
            }
        }
        #endregion
    }
}