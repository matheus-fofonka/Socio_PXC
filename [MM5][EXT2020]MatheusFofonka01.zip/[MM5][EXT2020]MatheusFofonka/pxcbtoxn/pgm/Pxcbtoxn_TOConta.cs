﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CONTA da base de dados PXC.</summary>
    public class TOConta : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> agenciaConta;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> nomeCorrentista;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> cpfCnpjCorrent;
        private CampoOpcional<Decimal> saldo;
        private CampoOpcional<DateTime> ultAtualizacao;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo AGENCIA_CONTA da tabela CONTA.</summary>
        [XmlAttribute("agencia_conta")]
        [CampoTabela("AGENCIA_CONTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 20, Precisao = 20)]
        public CampoObrigatorio<String> AgenciaConta
        {
            get { return this.agenciaConta; }
            set { this.agenciaConta = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo NOME_CORRENTISTA da tabela CONTA.</summary>
        [XmlAttribute("nome_correntista")]
        [CampoTabela("NOME_CORRENTISTA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> NomeCorrentista
        { 
            get { return this.nomeCorrentista; }
            set { this.nomeCorrentista = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo CPF_CNPJ_CORRENT da tabela CONTA.</summary>
        [XmlAttribute("cpf_cnpj_corrent")]
        [CampoTabela("CPF_CNPJ_CORRENT", TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoOpcional<String> CpfCnpjCorrent
        {
            get { return this.cpfCnpjCorrent; }
            set { this.cpfCnpjCorrent = value; }
        }

        /// <summary>Campo SALDO da tabela CONTA.</summary>
        [XmlAttribute("saldo")]
        [CampoTabela("SALDO", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoOpcional<Decimal> Saldo
        {
            get { return this.saldo; }
            set { this.saldo = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela CONTA.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoOpcional<DateTime> UltAtualizacao
        {
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "AGENCIA_CONTA":
                        this.agenciaConta = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "NOME_CORRENTISTA":
                        this.nomeCorrentista = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CPF_CNPJ_CORRENT":
                        this.cpfCnpjCorrent = this.LerCampoOpcional<String>(campo);
                        if(this.cpfCnpjCorrent.TemConteudo)
                        {
                            this.cpfCnpjCorrent = this.cpfCnpjCorrent.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "SALDO":
                        this.saldo = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}