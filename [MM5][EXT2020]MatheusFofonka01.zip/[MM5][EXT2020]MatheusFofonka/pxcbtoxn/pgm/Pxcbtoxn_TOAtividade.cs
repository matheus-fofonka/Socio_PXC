﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ATIVIDADE da base de dados PXC.</summary>
    public class TOAtividade : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codAtividade;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codUsuario;
        private CampoObrigatorio<String> descrAtividade;
        private CampoObrigatorio<DateTime> dthrUltAtu;
        private CampoObrigatorio<Decimal> vlrMaximo;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_ATIVIDADE da tabela ATIVIDADE.</summary>
        [XmlAttribute("cod_atividade")]
        [CampoTabela("COD_ATIVIDADE", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodAtividade
        {
            get { return this.codAtividade; }
            set { this.codAtividade = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_USUARIO da tabela ATIVIDADE.</summary>
        [XmlAttribute("cod_usuario")]
        [CampoTabela("COD_USUARIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodUsuario
        { 
            get { return this.codUsuario; }
            set { this.codUsuario = value; }
        }

        /// <summary>Campo DESCR_ATIVIDADE da tabela ATIVIDADE.</summary>
        [XmlAttribute("descr_atividade")]
        [CampoTabela("DESCR_ATIVIDADE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> DescrAtividade
        { 
            get { return this.descrAtividade; }
            set { this.descrAtividade = value; }
        }

        /// <summary>Campo DTHR_ULT_ATU da tabela ATIVIDADE.</summary>
        [XmlAttribute("dthr_ult_atu")]
        [CampoTabela("DTHR_ULT_ATU", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DthrUltAtu
        { 
            get { return this.dthrUltAtu; }
            set { this.dthrUltAtu = value; }
        }

        /// <summary>Campo VLR_MAXIMO da tabela ATIVIDADE.</summary>
        [XmlAttribute("vlr_maximo")]
        [CampoTabela("VLR_MAXIMO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> VlrMaximo
        { 
            get { return this.vlrMaximo; }
            set { this.vlrMaximo = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_ATIVIDADE":
                        this.codAtividade = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_USUARIO":
                        this.codUsuario = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DESCR_ATIVIDADE":
                        this.descrAtividade = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DTHR_ULT_ATU":
                        this.dthrUltAtu = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VLR_MAXIMO":
                        this.vlrMaximo = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}