﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela VEICULO_BEM da base de dados PXC.</summary>
    public class TOVeiculoBem : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> idBem;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int16> anoFabricacao;
        private CampoObrigatorio<Int16> anoModelo;
        private CampoObrigatorio<String> indGravame;
        private CampoObrigatorio<String> marca;
        private CampoObrigatorio<String> modelo;
        private CampoObrigatorio<String> numChassi;
        private CampoObrigatorio<String> tpChassi;
        private CampoObrigatorio<String> tpCombustivel;
        private CampoObrigatorio<String> tpVeiculo;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> codFipe;
        private CampoOpcional<String> cor;
        private CampoOpcional<String> notaFiscal;
        private CampoOpcional<String> placa;
        private CampoOpcional<String> renavam;
        private CampoOpcional<String> ufPlaca;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo ID_BEM da tabela VEICULO_BEM.</summary>
        [XmlAttribute("id_bem")]
        [CampoTabela("ID_BEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> IdBem
        {
            get { return this.idBem; }
            set { this.idBem = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo ANO_FABRICACAO da tabela VEICULO_BEM.</summary>
        [XmlAttribute("ano_fabricacao")]
        [CampoTabela("ANO_FABRICACAO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> AnoFabricacao
        { 
            get { return this.anoFabricacao; }
            set { this.anoFabricacao = value; }
        }

        /// <summary>Campo ANO_MODELO da tabela VEICULO_BEM.</summary>
        [XmlAttribute("ano_modelo")]
        [CampoTabela("ANO_MODELO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> AnoModelo
        { 
            get { return this.anoModelo; }
            set { this.anoModelo = value; }
        }

        /// <summary>Campo IND_GRAVAME da tabela VEICULO_BEM.</summary>
        [XmlAttribute("ind_gravame")]
        [CampoTabela("IND_GRAVAME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndGravame
        { 
            get { return this.indGravame; }
            set { this.indGravame = value; }
        }

        /// <summary>Campo MARCA da tabela VEICULO_BEM.</summary>
        [XmlAttribute("marca")]
        [CampoTabela("MARCA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoObrigatorio<String> Marca
        { 
            get { return this.marca; }
            set { this.marca = value; }
        }

        /// <summary>Campo MODELO da tabela VEICULO_BEM.</summary>
        [XmlAttribute("modelo")]
        [CampoTabela("MODELO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoObrigatorio<String> Modelo
        { 
            get { return this.modelo; }
            set { this.modelo = value; }
        }

        /// <summary>Campo NUM_CHASSI da tabela VEICULO_BEM.</summary>
        [XmlAttribute("num_chassi")]
        [CampoTabela("NUM_CHASSI", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 17, Precisao = 17)]
        public CampoObrigatorio<String> NumChassi
        { 
            get { return this.numChassi; }
            set { this.numChassi = value; }
        }

        /// <summary>Campo TP_CHASSI da tabela VEICULO_BEM.</summary>
        [XmlAttribute("tp_chassi")]
        [CampoTabela("TP_CHASSI", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TpChassi
        { 
            get { return this.tpChassi; }
            set { this.tpChassi = value; }
        }

        /// <summary>Campo TP_COMBUSTIVEL da tabela VEICULO_BEM.</summary>
        [XmlAttribute("tp_combustivel")]
        [CampoTabela("TP_COMBUSTIVEL", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TpCombustivel
        { 
            get { return this.tpCombustivel; }
            set { this.tpCombustivel = value; }
        }

        /// <summary>Campo TP_VEICULO da tabela VEICULO_BEM.</summary>
        [XmlAttribute("tp_veiculo")]
        [CampoTabela("TP_VEICULO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TpVeiculo
        { 
            get { return this.tpVeiculo; }
            set { this.tpVeiculo = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo COD_FIPE da tabela VEICULO_BEM.</summary>
        [XmlAttribute("cod_fipe")]
        [CampoTabela("COD_FIPE", TipoParametro = DbType.String, 
            Tamanho = 7, Precisao = 7)]
        public CampoOpcional<String> CodFipe
        {
            get { return this.codFipe; }
            set { this.codFipe = value; }
        }

        /// <summary>Campo COR da tabela VEICULO_BEM.</summary>
        [XmlAttribute("cor")]
        [CampoTabela("COR", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> Cor
        {
            get { return this.cor; }
            set { this.cor = value; }
        }

        /// <summary>Campo NOTA_FISCAL da tabela VEICULO_BEM.</summary>
        [XmlAttribute("nota_fiscal")]
        [CampoTabela("NOTA_FISCAL", TipoParametro = DbType.String, 
            Tamanho = 44, Precisao = 44)]
        public CampoOpcional<String> NotaFiscal
        {
            get { return this.notaFiscal; }
            set { this.notaFiscal = value; }
        }

        /// <summary>Campo PLACA da tabela VEICULO_BEM.</summary>
        [XmlAttribute("placa")]
        [CampoTabela("PLACA", TipoParametro = DbType.String, 
            Tamanho = 7, Precisao = 7)]
        public CampoOpcional<String> Placa
        {
            get { return this.placa; }
            set { this.placa = value; }
        }

        /// <summary>Campo RENAVAM da tabela VEICULO_BEM.</summary>
        [XmlAttribute("renavam")]
        [CampoTabela("RENAVAM", TipoParametro = DbType.String, 
            Tamanho = 9, Precisao = 9)]
        public CampoOpcional<String> Renavam
        {
            get { return this.renavam; }
            set { this.renavam = value; }
        }

        /// <summary>Campo UF_PLACA da tabela VEICULO_BEM.</summary>
        [XmlAttribute("uf_placa")]
        [CampoTabela("UF_PLACA", TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<String> UfPlaca
        {
            get { return this.ufPlaca; }
            set { this.ufPlaca = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "ID_BEM":
                        this.idBem = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "ANO_FABRICACAO":
                        this.anoFabricacao = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "ANO_MODELO":
                        this.anoModelo = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "IND_GRAVAME":
                        this.indGravame = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "MARCA":
                        this.marca = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "MODELO":
                        this.modelo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NUM_CHASSI":
                        this.numChassi = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TP_CHASSI":
                        this.tpChassi = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TP_COMBUSTIVEL":
                        this.tpCombustivel = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TP_VEICULO":
                        this.tpVeiculo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "COD_FIPE":
                        this.codFipe = this.LerCampoOpcional<String>(campo);
                        if(this.codFipe.TemConteudo)
                        {
                            this.codFipe = this.codFipe.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "COR":
                        this.cor = this.LerCampoOpcional<String>(campo);
                        if(this.cor.TemConteudo)
                        {
                            this.cor = this.cor.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "NOTA_FISCAL":
                        this.notaFiscal = this.LerCampoOpcional<String>(campo);
                        if(this.notaFiscal.TemConteudo)
                        {
                            this.notaFiscal = this.notaFiscal.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PLACA":
                        this.placa = this.LerCampoOpcional<String>(campo);
                        if(this.placa.TemConteudo)
                        {
                            this.placa = this.placa.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "RENAVAM":
                        this.renavam = this.LerCampoOpcional<String>(campo);
                        if(this.renavam.TemConteudo)
                        {
                            this.renavam = this.renavam.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "UF_PLACA":
                        this.ufPlaca = this.LerCampoOpcional<String>(campo);
                        if(this.ufPlaca.TemConteudo)
                        {
                            this.ufPlaca = this.ufPlaca.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}