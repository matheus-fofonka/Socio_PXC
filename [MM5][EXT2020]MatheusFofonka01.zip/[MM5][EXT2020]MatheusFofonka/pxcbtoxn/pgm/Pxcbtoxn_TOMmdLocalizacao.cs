﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_LOCALIZACAO da base de dados PXC.</summary>
    public class TOMmdLocalizacao : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> cep;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> cidade;
        private CampoObrigatorio<String> uf;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CEP da tabela MMD_LOCALIZACAO.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<Decimal> Cep
        {
            get { return this.cep; }
            set { this.cep = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CIDADE da tabela MMD_LOCALIZACAO.</summary>
        [XmlAttribute("cidade")]
        [CampoTabela("CIDADE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 120, Precisao = 120)]
        public CampoObrigatorio<String> Cidade
        { 
            get { return this.cidade; }
            set { this.cidade = value; }
        }

        /// <summary>Campo UF da tabela MMD_LOCALIZACAO.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> Uf
        { 
            get { return this.uf; }
            set { this.uf = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CEP":
                        this.cep = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CIDADE":
                        this.cidade = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "UF":
                        this.uf = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}