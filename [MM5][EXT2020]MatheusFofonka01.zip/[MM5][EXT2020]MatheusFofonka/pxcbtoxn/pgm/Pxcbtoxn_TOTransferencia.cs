﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela TRANSFERENCIA da base de dados PXC.</summary>
    public class TOTransferencia : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> id;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> agContaDestino;
        private CampoObrigatorio<String> agContaOrigem;
        private CampoObrigatorio<String> banco;
        private CampoObrigatorio<DateTime> dataTransferencia;
        private CampoObrigatorio<Decimal> valor;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> finalidade;
        private CampoOpcional<DateTime> ultAtualizacao;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo ID da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("id")]
        [CampoTabela("ID", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> Id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo AG_CONTA_DESTINO da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("ag_conta_destino")]
        [CampoTabela("AG_CONTA_DESTINO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoObrigatorio<String> AgContaDestino
        { 
            get { return this.agContaDestino; }
            set { this.agContaDestino = value; }
        }

        /// <summary>Campo AG_CONTA_ORIGEM da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("ag_conta_origem")]
        [CampoTabela("AG_CONTA_ORIGEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoObrigatorio<String> AgContaOrigem
        { 
            get { return this.agContaOrigem; }
            set { this.agContaOrigem = value; }
        }

        /// <summary>Campo BANCO da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("banco")]
        [CampoTabela("BANCO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Banco
        { 
            get { return this.banco; }
            set { this.banco = value; }
        }

        /// <summary>Campo DATA_TRANSFERENCIA da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("data_transferencia")]
        [CampoTabela("DATA_TRANSFERENCIA", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataTransferencia
        { 
            get { return this.dataTransferencia; }
            set { this.dataTransferencia = value; }
        }

        /// <summary>Campo VALOR da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("valor")]
        [CampoTabela("VALOR", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoObrigatorio<Decimal> Valor
        { 
            get { return this.valor; }
            set { this.valor = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo FINALIDADE da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("finalidade")]
        [CampoTabela("FINALIDADE", TipoParametro = DbType.String, 
            Tamanho = 100, Precisao = 100)]
        public CampoOpcional<String> Finalidade
        {
            get { return this.finalidade; }
            set { this.finalidade = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela TRANSFERENCIA.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoOpcional<DateTime> UltAtualizacao
        {
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "ID":
                        this.id = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "AG_CONTA_DESTINO":
                        this.agContaDestino = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "AG_CONTA_ORIGEM":
                        this.agContaOrigem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "BANCO":
                        this.banco = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_TRANSFERENCIA":
                        this.dataTransferencia = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR":
                        this.valor = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "FINALIDADE":
                        this.finalidade = this.LerCampoOpcional<String>(campo);
                        if(this.finalidade.TemConteudo)
                        {
                            this.finalidade = this.finalidade.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}