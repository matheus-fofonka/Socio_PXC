﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela EXTRATO_CLIENTE da base de dados PXC.</summary>
    public class TOExtratoCliente : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codItem;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> data;
        private CampoObrigatorio<String> descricao;
        private CampoObrigatorio<String> indPago;
        private CampoObrigatorio<String> tipoDespesa;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valor;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> cpfDependente;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_ITEM da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("cod_item")]
        [CampoTabela("COD_ITEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodItem
        {
            get { return this.codItem; }
            set { this.codItem = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CLIENTE da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DATA da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("data")]
        [CampoTabela("DATA", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> Data
        { 
            get { return this.data; }
            set { this.data = value; }
        }

        /// <summary>Campo DESCRICAO da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("descricao")]
        [CampoTabela("DESCRICAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 35, Precisao = 35)]
        public CampoObrigatorio<String> Descricao
        { 
            get { return this.descricao; }
            set { this.descricao = value; }
        }

        /// <summary>Campo IND_PAGO da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("ind_pago")]
        [CampoTabela("IND_PAGO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndPago
        { 
            get { return this.indPago; }
            set { this.indPago = value; }
        }

        /// <summary>Campo TIPO_DESPESA da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("tipo_despesa")]
        [CampoTabela("TIPO_DESPESA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoDespesa
        { 
            get { return this.tipoDespesa; }
            set { this.tipoDespesa = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("valor")]
        [CampoTabela("VALOR", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> Valor
        { 
            get { return this.valor; }
            set { this.valor = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo CPF_DEPENDENTE da tabela EXTRATO_CLIENTE.</summary>
        [XmlAttribute("cpf_dependente")]
        [CampoTabela("CPF_DEPENDENTE", TipoParametro = DbType.Decimal, 
            Tamanho = 11, Precisao = 11)]
        public CampoOpcional<Decimal> CpfDependente
        {
            get { return this.cpfDependente; }
            set { this.cpfDependente = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_ITEM":
                        this.codItem = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA":
                        this.data = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DESCRICAO":
                        this.descricao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_PAGO":
                        this.indPago = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_DESPESA":
                        this.tipoDespesa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR":
                        this.valor = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CPF_DEPENDENTE":
                        this.cpfDependente = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}