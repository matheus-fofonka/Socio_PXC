﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ORDERS da base de dados PXC.</summary>
    public class TOOrders : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int32> ordernumber;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> comments;
        private CampoOpcional<Int32> customernumber;
        private CampoOpcional<DateTime> orderdate;
        private CampoOpcional<DateTime> requireddate;
        private CampoOpcional<DateTime> shippeddate;
        private CampoOpcional<String> status;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo ORDERNUMBER da tabela ORDERS.</summary>
        [XmlAttribute("ordernumber")]
        [CampoTabela("ORDERNUMBER", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> Ordernumber
        { 
            get { return this.ordernumber; }
            set { this.ordernumber = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo COMMENTS da tabela ORDERS.</summary>
        [XmlAttribute("comments")]
        [CampoTabela("COMMENTS", TipoParametro = DbType.String, 
            Tamanho = 200, Precisao = 200)]
        public CampoOpcional<String> Comments
        {
            get { return this.comments; }
            set { this.comments = value; }
        }

        /// <summary>Campo CUSTOMERNUMBER da tabela ORDERS.</summary>
        [XmlAttribute("customernumber")]
        [CampoTabela("CUSTOMERNUMBER", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> Customernumber
        {
            get { return this.customernumber; }
            set { this.customernumber = value; }
        }

        /// <summary>Campo ORDERDATE da tabela ORDERS.</summary>
        [XmlAttribute("orderdate")]
        [CampoTabela("ORDERDATE", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> Orderdate
        {
            get { return this.orderdate; }
            set { this.orderdate = value; }
        }

        /// <summary>Campo REQUIREDDATE da tabela ORDERS.</summary>
        [XmlAttribute("requireddate")]
        [CampoTabela("REQUIREDDATE", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> Requireddate
        {
            get { return this.requireddate; }
            set { this.requireddate = value; }
        }

        /// <summary>Campo SHIPPEDDATE da tabela ORDERS.</summary>
        [XmlAttribute("shippeddate")]
        [CampoTabela("SHIPPEDDATE", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> Shippeddate
        {
            get { return this.shippeddate; }
            set { this.shippeddate = value; }
        }

        /// <summary>Campo STATUS da tabela ORDERS.</summary>
        [XmlAttribute("status")]
        [CampoTabela("STATUS", TipoParametro = DbType.String, 
            Tamanho = 15, Precisao = 15)]
        public CampoOpcional<String> Status
        {
            get { return this.status; }
            set { this.status = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias                        
                    #endregion

                    #region Campos Obrigatórios
                    case "ORDERNUMBER":
                        this.ordernumber = Convert.ToInt32(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "COMMENTS":
                        this.comments = this.LerCampoOpcional<String>(campo);
                        if(this.comments.TemConteudo)
                        {
                            this.comments = this.comments.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CUSTOMERNUMBER":
                        this.customernumber = this.LerCampoOpcional<Int32>(campo);
                        break;
                    case "ORDERDATE":
                        this.orderdate = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "REQUIREDDATE":
                        this.requireddate = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "SHIPPEDDATE":
                        this.shippeddate = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "STATUS":
                        this.status = this.LerCampoOpcional<String>(campo);
                        if(this.status.TemConteudo)
                        {
                            this.status = this.status.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}