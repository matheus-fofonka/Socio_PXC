﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{
    #region :: Exercício 3 - Contrato ::
    /// <summary>Classe que representa o TOAgencia.</summary>
    public class TOAgencia : TOTabela
    {
        /// <summary>Campo AGENCIA.</summary>
        [XmlAttribute("agencia")]
        public CampoObrigatorio<String> Agencia { get; set; }

        /// <summary>Campo NOME_AGENCIA.</summary>
        [XmlAttribute("nome_ag")]
        public CampoObrigatorio<String> NomeAgencia { get; set; }
    }
    #endregion
}
