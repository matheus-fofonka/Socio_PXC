﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela PROPRIETARIO_BEM da base de dados PXC.</summary>
    public class TOProprietarioBem : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> cpfCnpjProp;
        private CampoObrigatorio<Int32> idBem;
        private CampoObrigatorio<String> tpPessoaProp;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<Decimal> percProp;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CPF_CNPJ_PROP da tabela PROPRIETARIO_BEM.</summary>
        [XmlAttribute("cpf_cnpj_prop")]
        [CampoTabela("CPF_CNPJ_PROP", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<Decimal> CpfCnpjProp
        {
            get { return this.cpfCnpjProp; }
            set { this.cpfCnpjProp = value; }
        }

        /// <summary>Campo ID_BEM da tabela PROPRIETARIO_BEM.</summary>
        [XmlAttribute("id_bem")]
        [CampoTabela("ID_BEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> IdBem
        {
            get { return this.idBem; }
            set { this.idBem = value; }
        }

        /// <summary>Campo TP_PESSOA_PROP da tabela PROPRIETARIO_BEM.</summary>
        [XmlAttribute("tp_pessoa_prop")]
        [CampoTabela("TP_PESSOA_PROP", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TpPessoaProp
        {
            get { return this.tpPessoaProp; }
            set { this.tpPessoaProp = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela PROPRIETARIO_BEM.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo PERC_PROP da tabela PROPRIETARIO_BEM.</summary>
        [XmlAttribute("perc_prop")]
        [CampoTabela("PERC_PROP", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoObrigatorio<Decimal> PercProp
        { 
            get { return this.percProp; }
            set { this.percProp = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela PROPRIETARIO_BEM.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CPF_CNPJ_PROP":
                        this.cpfCnpjProp = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "ID_BEM":
                        this.idBem = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "TP_PESSOA_PROP":
                        this.tpPessoaProp = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "PERC_PROP":
                        this.percProp = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}