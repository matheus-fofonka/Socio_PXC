﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{
    /// <summary>Representa um registro da tabela EMPRESTIMO da base de dados PXC.</summary>
    public class TOEmprestimo : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codEmprestimo;//
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> valorEmp;//
        private CampoObrigatorio<DateTime> dtInclusao;//
        private CampoObrigatorio<String> uf;//
        private CampoObrigatorio<String> codMunicipio;//
        private CampoObrigatorio<Int16> agencia;//
        private CampoObrigatorio<String> codOperador;//
        private CampoObrigatorio<DateTime> ultAtualizacao;//
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> taxa;//
        private CampoOpcional<DateTime> dtPagto;//
        private CampoOpcional<DateTime> dtCancelamento;//
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_EMPRESTIMO da tabela EMPRESTIMO.</summary>
        [XmlAttribute("cod_emprestimo")]
        [CampoTabela("COD_EMPRESTIMO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 7, Precisao = 7)]
        public CampoObrigatorio<Decimal> CodEmprestimo
        {
            get { return this.codEmprestimo; }
            set { this.codEmprestimo = value; }
        }

        #endregion

        #region Campos Obrigatórios

        #region 
        /// <summary>Campo VALOR_EMP da tabela EMPRESTIMO.</summary>
        [XmlAttribute("situacao")]

        public CampoObrigatorio<SituacaoEmprestimo> Situacao
        {
            get
            {
                if(!DtInclusao.FoiSetado && !DtPagto.TemConteudo && !DtCancelamento.TemConteudo)
                {
                    return new CampoObrigatorio<SituacaoEmprestimo>();
                }
                if(DtInclusao.FoiSetado && !DtPagto.TemConteudo && !DtCancelamento.TemConteudo)
                {
                    return SituacaoEmprestimo.Ativo;
                }
                if(DtInclusao.FoiSetado && DtPagto.TemConteudo && !DtCancelamento.TemConteudo)
                {
                    return SituacaoEmprestimo.Pago;
                }
                if(DtInclusao.FoiSetado && !DtPagto.TemConteudo && DtCancelamento.TemConteudo)
                {
                    return SituacaoEmprestimo.Cancelado;
                }
                return SituacaoEmprestimo.Invalido;
            }
        }

        #endregion

        /// <summary>Campo VALOR_EMP da tabela EMPRESTIMO.</summary>
        [XmlAttribute("valor_emp")]
        [CampoTabela("VALOR_EMP", Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> ValorEmp
        {
            get { return this.valorEmp; }
            set { this.valorEmp = value; }
        }

        /// <summary>Campo DT_INCLUSAO da tabela EMPRESTIMO.</summary>
        [XmlAttribute("dt_inclusao")]
        [CampoTabela("DT_INCLUSAO", Obrigatorio = true, TipoParametro = DbType.Date,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtInclusao
        {
            get { return this.dtInclusao; }
            set { this.dtInclusao = value; }
        }

        /// <summary>Campo UF da tabela EMPRESTIMO.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> Uf
        {
            get { return this.uf; }
            set { this.uf = value; }
        }

        /// <summary>Campo COD_MUNICIPIO da tabela EMPRESTIMO.</summary>
        [XmlAttribute("cod_municipio")]
        [CampoTabela("COD_MUNICIPIO", Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 7, Precisao = 7)]
        public CampoObrigatorio<String> CodMunicipio
        {
            get { return this.codMunicipio; }
            set { this.codMunicipio = value; }
        }

        /// <summary>Campo AGENCIA da tabela EMPRESTIMO.</summary>
        [XmlAttribute("agencia")]
        [CampoTabela("AGENCIA", Obrigatorio = true, TipoParametro = DbType.Int16,
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> Agencia
        {
            get { return this.agencia; }
            set { this.agencia = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela EMPRESTIMO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        {
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela EMPRESTIMO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime,
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        {
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo TAXA da tabela EMPRESTIMO.</summary>
        [XmlAttribute("taxa")]
        [CampoTabela("TAXA", TipoParametro = DbType.Decimal,
            Tamanho = 3, Precisao = 3, Escala = 2)]
        public CampoOpcional<Decimal> Taxa
        {
            get { return this.taxa; }
            set { this.taxa = value; }
        }

        /// <summary>Campo DT_PAGTO da tabela EMPRESTIMO.</summary>
        [XmlAttribute("dt_pagto")]
        [CampoTabela("DT_PAGTO", TipoParametro = DbType.Date,
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtPagto
        {
            get { return this.dtPagto; }
            set { this.dtPagto = value; }
        }

        /// <summary>Campo DT_CANCELAMENTO da tabela EMPRESTIMO.</summary>
        [XmlAttribute("dt_cancelamento")]
        [CampoTabela("DT_CANCELAMENTO", TipoParametro = DbType.Date,
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtCancelamento
        {
            get { return this.dtCancelamento; }
            set { this.dtCancelamento = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno( Linha linha )
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach(Campo campo in linha.Campos)
            {
                switch(campo.Nome)
                {
                    #region Chaves Primárias
                    case "COD_EMPRESTIMO":
                    this.codEmprestimo = Convert.ToDecimal(campo.Conteudo);
                    break;
                    #endregion

                    #region Campos Obrigatórios

                    case "VALOR_EMP":
                    this.valorEmp = Convert.ToDecimal(campo.Conteudo);
                    break;
                    case "DT_INCLUSAO":
                    this.dtInclusao = Convert.ToDateTime(campo.Conteudo);
                    break;
                    case "UF":
                    this.uf = Convert.ToString(campo.Conteudo).Trim();
                    break;
                    case "COD_MUNICIPIO":
                    this.codMunicipio = Convert.ToString(campo.Conteudo).Trim();
                    break;
                    case "AGENCIA":
                    this.agencia = Convert.ToInt16(campo.Conteudo);
                    break;
                    case "COD_OPERADOR":
                    this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                    break;
                    case "ULT_ATUALIZACAO":
                    this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                    break;
                    #endregion

                    #region Campos Opcionais
                    case "TAXA":
                    this.taxa = this.LerCampoOpcional<Decimal>(campo);
                    break;
                    case "DT_PAGTO":
                    this.dtPagto = this.LerCampoOpcional<DateTime>(campo);
                    break;
                    case "DT_CANCELAMENTO":
                    this.dtCancelamento = this.LerCampoOpcional<DateTime>(campo);
                    break;
                    #endregion

                    default:
                    //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                    break;
                }
            }
        }
        #endregion
    }
}