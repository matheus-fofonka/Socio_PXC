﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_EQUIPAMENTO da base de dados PXC.</summary>
    public class TOMmdEquipamento : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codEquipamento;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codUsuario;
        private CampoObrigatorio<DateTime> dataCriacao;
        private CampoObrigatorio<String> descEquipamento;
        private CampoObrigatorio<String> indExclusao;
        private CampoObrigatorio<String> titulo;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_EQUIPAMENTO da tabela MMD_EQUIPAMENTO.</summary>
        [XmlAttribute("cod_equipamento")]
        [CampoTabela("COD_EQUIPAMENTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodEquipamento
        {
            get { return this.codEquipamento; }
            set { this.codEquipamento = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_USUARIO da tabela MMD_EQUIPAMENTO.</summary>
        [XmlAttribute("cod_usuario")]
        [CampoTabela("COD_USUARIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodUsuario
        { 
            get { return this.codUsuario; }
            set { this.codUsuario = value; }
        }

        /// <summary>Campo DATA_CRIACAO da tabela MMD_EQUIPAMENTO.</summary>
        [XmlAttribute("data_criacao")]
        [CampoTabela("DATA_CRIACAO", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataCriacao
        { 
            get { return this.dataCriacao; }
            set { this.dataCriacao = value; }
        }

        /// <summary>Campo DESC_EQUIPAMENTO da tabela MMD_EQUIPAMENTO.</summary>
        [XmlAttribute("desc_equipamento")]
        [CampoTabela("DESC_EQUIPAMENTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> DescEquipamento
        { 
            get { return this.descEquipamento; }
            set { this.descEquipamento = value; }
        }

        /// <summary>Campo IND_EXCLUSAO da tabela MMD_EQUIPAMENTO.</summary>
        [XmlAttribute("ind_exclusao")]
        [CampoTabela("IND_EXCLUSAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndExclusao
        { 
            get { return this.indExclusao; }
            set { this.indExclusao = value; }
        }

        /// <summary>Campo TITULO da tabela MMD_EQUIPAMENTO.</summary>
        [XmlAttribute("titulo")]
        [CampoTabela("TITULO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Titulo
        { 
            get { return this.titulo; }
            set { this.titulo = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela MMD_EQUIPAMENTO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_EQUIPAMENTO":
                        this.codEquipamento = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_USUARIO":
                        this.codUsuario = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_CRIACAO":
                        this.dataCriacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DESC_EQUIPAMENTO":
                        this.descEquipamento = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_EXCLUSAO":
                        this.indExclusao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TITULO":
                        this.titulo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}