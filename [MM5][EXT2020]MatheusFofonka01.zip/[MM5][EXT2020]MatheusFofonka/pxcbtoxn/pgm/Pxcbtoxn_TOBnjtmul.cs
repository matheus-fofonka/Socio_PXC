﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxodaxn;

namespace Bergs.Pxc.Pxcbtoxn
{
    /// <summary>TO de dados da tabela de municípios acessada por rotina BNJ.</summary>
    [CLSCompliant(true)]
    public class TOBnjtmul : TOTabela, Pwx.Pwxoiexn.Comunicacao.ILeitorTabelaBanrisul
    {
        #region Atributos

        #region Chaves Primárias
        private CampoObrigatorio<String> codMunici;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> uf;
        private CampoOpcional<String> municipio;
        #endregion

        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Códico do município.</summary>
		[XmlAttribute("cod_municipio")]
        public CampoObrigatorio<String> CodMunici
        {
            get
            {
                return this.codMunici;
            }
            set
            {
                this.codMunici = value;
            }
        }
        #endregion

        #region Campos Opcionais
        /// <summary>Unidade da federação.</summary>
		[XmlAttribute("cod_uf")]
        public CampoOpcional<String> Uf
        {
            get
            { 
                return this.uf;
            }
            set
            {
                this.uf = value;
            }
        }

        /// <summary>Unidade da federação.</summary>
		[XmlAttribute("municipio")]
        public CampoOpcional<String> Municipio
        {
            get
            {
                return this.municipio;
            }
            set
            {
                this.municipio = value;
            }
        }
        #endregion
        #endregion

        #region Métodos
        #region ILeitorTabelaBanrisul Members

        void Bergs.Pwx.Pwxoiexn.Comunicacao.ILeitorTabelaBanrisul.PopularRetorno(string registro)
        {
            this.CodMunici = registro.Substring(0, 7);
            this.Uf = registro.Substring(7, 2);
            this.Municipio = registro.Substring(9, 72);
        }
        #endregion
        #endregion
    }
}

