﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CAD_PRODUTO da base de dados PXC.</summary>
    public class TOCadProduto : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codProduto;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int32> codCategoria;
        private CampoObrigatorio<String> descProduto;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_PRODUTO da tabela CAD_PRODUTO.</summary>
        [XmlAttribute("cod_produto")]
        [CampoTabela("COD_PRODUTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodProduto
        {
            get { return this.codProduto; }
            set { this.codProduto = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CATEGORIA da tabela CAD_PRODUTO.</summary>
        [XmlAttribute("cod_categoria")]
        [CampoTabela("COD_CATEGORIA", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodCategoria
        { 
            get { return this.codCategoria; }
            set { this.codCategoria = value; }
        }

        /// <summary>Campo DESC_PRODUTO da tabela CAD_PRODUTO.</summary>
        [XmlAttribute("desc_produto")]
        [CampoTabela("DESC_PRODUTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> DescProduto
        { 
            get { return this.descProduto; }
            set { this.descProduto = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_PRODUTO":
                        this.codProduto = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CATEGORIA":
                        this.codCategoria = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "DESC_PRODUTO":
                        this.descProduto = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}