﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_INSTRUTOR da base de dados PXC.</summary>
    public class TOMmdInstrutor : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codInstrutor;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> cep;
        private CampoObrigatorio<Decimal> cpf;
        private CampoObrigatorio<String> email;
        private CampoObrigatorio<String> endereco;
        private CampoObrigatorio<String> nome;
        private CampoObrigatorio<String> telefone;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_INSTRUTOR da tabela MMD_INSTRUTOR.</summary>
        [XmlAttribute("cod_instrutor")]
        [CampoTabela("COD_INSTRUTOR", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodInstrutor
        {
            get { return this.codInstrutor; }
            set { this.codInstrutor = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CEP da tabela MMD_INSTRUTOR.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<Decimal> Cep
        { 
            get { return this.cep; }
            set { this.cep = value; }
        }

        /// <summary>Campo CPF da tabela MMD_INSTRUTOR.</summary>
        [XmlAttribute("cpf")]
        [CampoTabela("CPF", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 11, Precisao = 11)]
        public CampoObrigatorio<Decimal> Cpf
        { 
            get { return this.cpf; }
            set { this.cpf = value; }
        }

        /// <summary>Campo EMAIL da tabela MMD_INSTRUTOR.</summary>
        [XmlAttribute("email")]
        [CampoTabela("EMAIL", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Email
        { 
            get { return this.email; }
            set { this.email = value; }
        }

        /// <summary>Campo ENDERECO da tabela MMD_INSTRUTOR.</summary>
        [XmlAttribute("endereco")]
        [CampoTabela("ENDERECO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Endereco
        { 
            get { return this.endereco; }
            set { this.endereco = value; }
        }

        /// <summary>Campo NOME da tabela MMD_INSTRUTOR.</summary>
        [XmlAttribute("nome")]
        [CampoTabela("NOME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Nome
        { 
            get { return this.nome; }
            set { this.nome = value; }
        }

        /// <summary>Campo TELEFONE da tabela MMD_INSTRUTOR.</summary>
        [XmlAttribute("telefone")]
        [CampoTabela("TELEFONE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 13, Precisao = 13)]
        public CampoObrigatorio<String> Telefone
        { 
            get { return this.telefone; }
            set { this.telefone = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_INSTRUTOR":
                        this.codInstrutor = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CEP":
                        this.cep = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "CPF":
                        this.cpf = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "EMAIL":
                        this.email = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ENDERECO":
                        this.endereco = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME":
                        this.nome = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TELEFONE":
                        this.telefone = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}