﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela PRODUCTLINES da base de dados PXC.</summary>
    public class TOProductlines : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> productline;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> textdescription;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo PRODUCTLINE da tabela PRODUCTLINES.</summary>
        [XmlAttribute("productline")]
        [CampoTabela("PRODUCTLINE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> Productline
        { 
            get { return this.productline; }
            set { this.productline = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo TEXTDESCRIPTION da tabela PRODUCTLINES.</summary>
        [XmlAttribute("textdescription")]
        [CampoTabela("TEXTDESCRIPTION", TipoParametro = DbType.String, 
            Tamanho = 400, Precisao = 255)]
        public CampoOpcional<String> Textdescription
        {
            get { return this.textdescription; }
            set { this.textdescription = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias                        
                    #endregion

                    #region Campos Obrigatórios
                    case "PRODUCTLINE":
                        this.productline = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "TEXTDESCRIPTION":
                        this.textdescription = this.LerCampoOpcional<String>(campo);
                        if(this.textdescription.TemConteudo)
                        {
                            this.textdescription = this.textdescription.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}