﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela BTR_OCORRENCIA da base de dados PXC.</summary>
    public class TOBtrOcorrencia : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<DateTime> dataHoraOcor;
        private CampoObrigatorio<String> produto;
        private CampoObrigatorio<String> siglaSistema;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> chaveGrupo;
        private CampoObrigatorio<Int16> codGrupo;
        private CampoObrigatorio<Int32> codOcorrencia;
        private CampoObrigatorio<String> idBaseDados;
        private CampoObrigatorio<String> maquinaCliente;
        private CampoObrigatorio<String> maquinaOrigem;
        private CampoObrigatorio<Int16> particaoMes;
        private CampoObrigatorio<String> perfilAcessoUsu;
        private CampoObrigatorio<String> programa;
        private CampoObrigatorio<Int32> seq;
        private CampoObrigatorio<String> tipoEquipamento;
        private CampoObrigatorio<String> tipoOperacao;
        private CampoObrigatorio<String> tipoProcesso;
        private CampoObrigatorio<String> usuarioBd;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Int16> codReferencia;
        private CampoOpcional<String> conteudoAnterior;
        private CampoOpcional<String> conteudoAtual;
        private CampoOpcional<String> idEntradaRede;
        private CampoOpcional<String> idProcesso;
        private CampoOpcional<String> mnemonico;
        private CampoOpcional<String> nivelAcessoUsu;
        private CampoOpcional<String> processo;
        private CampoOpcional<String> programaOrigem;
        private CampoOpcional<String> referencia;
        private CampoOpcional<String> transacao;
        private CampoOpcional<String> usuarioOrigem;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo DATA_HORA_OCOR da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("data_hora_ocor")]
        [CampoTabela("DATA_HORA_OCOR", Chave = true, Obrigatorio = true, TipoParametro = DbType.DateTime,
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DataHoraOcor
        {
            get { return this.dataHoraOcor; }
            set { this.dataHoraOcor = value; }
        }

        /// <summary>Campo PRODUTO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("produto")]
        [CampoTabela("PRODUTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 16, Precisao = 16)]
        public CampoObrigatorio<String> Produto
        {
            get { return this.produto; }
            set { this.produto = value; }
        }

        /// <summary>Campo SIGLA_SISTEMA da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("sigla_sistema")]
        [CampoTabela("SIGLA_SISTEMA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 3, Precisao = 3)]
        public CampoObrigatorio<String> SiglaSistema
        {
            get { return this.siglaSistema; }
            set { this.siglaSistema = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CHAVE_GRUPO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("chave_grupo")]
        [CampoTabela("CHAVE_GRUPO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 254, Precisao = 254)]
        public CampoObrigatorio<String> ChaveGrupo
        { 
            get { return this.chaveGrupo; }
            set { this.chaveGrupo = value; }
        }

        /// <summary>Campo COD_GRUPO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("cod_grupo")]
        [CampoTabela("COD_GRUPO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> CodGrupo
        { 
            get { return this.codGrupo; }
            set { this.codGrupo = value; }
        }

        /// <summary>Campo COD_OCORRENCIA da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("cod_ocorrencia")]
        [CampoTabela("COD_OCORRENCIA", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodOcorrencia
        { 
            get { return this.codOcorrencia; }
            set { this.codOcorrencia = value; }
        }

        /// <summary>Campo ID_BASE_DADOS da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("id_base_dados")]
        [CampoTabela("ID_BASE_DADOS", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> IdBaseDados
        { 
            get { return this.idBaseDados; }
            set { this.idBaseDados = value; }
        }

        /// <summary>Campo MAQUINA_CLIENTE da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("maquina_cliente")]
        [CampoTabela("MAQUINA_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 40, Precisao = 40)]
        public CampoObrigatorio<String> MaquinaCliente
        { 
            get { return this.maquinaCliente; }
            set { this.maquinaCliente = value; }
        }

        /// <summary>Campo MAQUINA_ORIGEM da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("maquina_origem")]
        [CampoTabela("MAQUINA_ORIGEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> MaquinaOrigem
        { 
            get { return this.maquinaOrigem; }
            set { this.maquinaOrigem = value; }
        }

        /// <summary>Campo PARTICAO_MES da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("particao_mes")]
        [CampoTabela("PARTICAO_MES", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> ParticaoMes
        { 
            get { return this.particaoMes; }
            set { this.particaoMes = value; }
        }

        /// <summary>Campo PERFIL_ACESSO_USU da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("perfil_acesso_usu")]
        [CampoTabela("PERFIL_ACESSO_USU", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> PerfilAcessoUsu
        { 
            get { return this.perfilAcessoUsu; }
            set { this.perfilAcessoUsu = value; }
        }

        /// <summary>Campo PROGRAMA da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("programa")]
        [CampoTabela("PROGRAMA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> Programa
        { 
            get { return this.programa; }
            set { this.programa = value; }
        }

        /// <summary>Campo SEQ da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("seq")]
        [CampoTabela("SEQ", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> Seq
        { 
            get { return this.seq; }
            set { this.seq = value; }
        }

        /// <summary>Campo TIPO_EQUIPAMENTO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("tipo_equipamento")]
        [CampoTabela("TIPO_EQUIPAMENTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoEquipamento
        { 
            get { return this.tipoEquipamento; }
            set { this.tipoEquipamento = value; }
        }

        /// <summary>Campo TIPO_OPERACAO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("tipo_operacao")]
        [CampoTabela("TIPO_OPERACAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoOperacao
        { 
            get { return this.tipoOperacao; }
            set { this.tipoOperacao = value; }
        }

        /// <summary>Campo TIPO_PROCESSO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("tipo_processo")]
        [CampoTabela("TIPO_PROCESSO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoProcesso
        { 
            get { return this.tipoProcesso; }
            set { this.tipoProcesso = value; }
        }

        /// <summary>Campo USUARIO_BD da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("usuario_bd")]
        [CampoTabela("USUARIO_BD", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> UsuarioBd
        { 
            get { return this.usuarioBd; }
            set { this.usuarioBd = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo COD_REFERENCIA da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("cod_referencia")]
        [CampoTabela("COD_REFERENCIA", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> CodReferencia
        {
            get { return this.codReferencia; }
            set { this.codReferencia = value; }
        }

        /// <summary>Campo CONTEUDO_ANTERIOR da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("conteudo_anterior")]
        [CampoTabela("CONTEUDO_ANTERIOR", TipoParametro = DbType.String, 
            Tamanho = 254, Precisao = 254)]
        public CampoOpcional<String> ConteudoAnterior
        {
            get { return this.conteudoAnterior; }
            set { this.conteudoAnterior = value; }
        }

        /// <summary>Campo CONTEUDO_ATUAL da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("conteudo_atual")]
        [CampoTabela("CONTEUDO_ATUAL", TipoParametro = DbType.String, 
            Tamanho = 254, Precisao = 254)]
        public CampoOpcional<String> ConteudoAtual
        {
            get { return this.conteudoAtual; }
            set { this.conteudoAtual = value; }
        }

        /// <summary>Campo ID_ENTRADA_REDE da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("id_entrada_rede")]
        [CampoTabela("ID_ENTRADA_REDE", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> IdEntradaRede
        {
            get { return this.idEntradaRede; }
            set { this.idEntradaRede = value; }
        }

        /// <summary>Campo ID_PROCESSO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("id_processo")]
        [CampoTabela("ID_PROCESSO", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> IdProcesso
        {
            get { return this.idProcesso; }
            set { this.idProcesso = value; }
        }

        /// <summary>Campo MNEMONICO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("mnemonico")]
        [CampoTabela("MNEMONICO", TipoParametro = DbType.String, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<String> Mnemonico
        {
            get { return this.mnemonico; }
            set { this.mnemonico = value; }
        }

        /// <summary>Campo NIVEL_ACESSO_USU da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("nivel_acesso_usu")]
        [CampoTabela("NIVEL_ACESSO_USU", TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoOpcional<String> NivelAcessoUsu
        {
            get { return this.nivelAcessoUsu; }
            set { this.nivelAcessoUsu = value; }
        }

        /// <summary>Campo PROCESSO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("processo")]
        [CampoTabela("PROCESSO", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> Processo
        {
            get { return this.processo; }
            set { this.processo = value; }
        }

        /// <summary>Campo PROGRAMA_ORIGEM da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("programa_origem")]
        [CampoTabela("PROGRAMA_ORIGEM", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> ProgramaOrigem
        {
            get { return this.programaOrigem; }
            set { this.programaOrigem = value; }
        }

        /// <summary>Campo REFERENCIA da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("referencia")]
        [CampoTabela("REFERENCIA", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> Referencia
        {
            get { return this.referencia; }
            set { this.referencia = value; }
        }

        /// <summary>Campo TRANSACAO da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("transacao")]
        [CampoTabela("TRANSACAO", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> Transacao
        {
            get { return this.transacao; }
            set { this.transacao = value; }
        }

        /// <summary>Campo USUARIO_ORIGEM da tabela BTR_OCORRENCIA.</summary>
        [XmlAttribute("usuario_origem")]
        [CampoTabela("USUARIO_ORIGEM", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> UsuarioOrigem
        {
            get { return this.usuarioOrigem; }
            set { this.usuarioOrigem = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "DATA_HORA_OCOR":
                        this.dataHoraOcor = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "PRODUTO":
                        this.produto = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "SIGLA_SISTEMA":
                        this.siglaSistema = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CHAVE_GRUPO":
                        this.chaveGrupo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_GRUPO":
                        this.codGrupo = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "COD_OCORRENCIA":
                        this.codOcorrencia = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "ID_BASE_DADOS":
                        this.idBaseDados = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "MAQUINA_CLIENTE":
                        this.maquinaCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "MAQUINA_ORIGEM":
                        this.maquinaOrigem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "PARTICAO_MES":
                        this.particaoMes = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "PERFIL_ACESSO_USU":
                        this.perfilAcessoUsu = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "PROGRAMA":
                        this.programa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "SEQ":
                        this.seq = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "TIPO_EQUIPAMENTO":
                        this.tipoEquipamento = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_OPERACAO":
                        this.tipoOperacao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PROCESSO":
                        this.tipoProcesso = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "USUARIO_BD":
                        this.usuarioBd = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "COD_REFERENCIA":
                        this.codReferencia = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "CONTEUDO_ANTERIOR":
                        this.conteudoAnterior = this.LerCampoOpcional<String>(campo);
                        if(this.conteudoAnterior.TemConteudo)
                        {
                            this.conteudoAnterior = this.conteudoAnterior.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CONTEUDO_ATUAL":
                        this.conteudoAtual = this.LerCampoOpcional<String>(campo);
                        if(this.conteudoAtual.TemConteudo)
                        {
                            this.conteudoAtual = this.conteudoAtual.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ID_ENTRADA_REDE":
                        this.idEntradaRede = this.LerCampoOpcional<String>(campo);
                        if(this.idEntradaRede.TemConteudo)
                        {
                            this.idEntradaRede = this.idEntradaRede.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ID_PROCESSO":
                        this.idProcesso = this.LerCampoOpcional<String>(campo);
                        if(this.idProcesso.TemConteudo)
                        {
                            this.idProcesso = this.idProcesso.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "MNEMONICO":
                        this.mnemonico = this.LerCampoOpcional<String>(campo);
                        if(this.mnemonico.TemConteudo)
                        {
                            this.mnemonico = this.mnemonico.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "NIVEL_ACESSO_USU":
                        this.nivelAcessoUsu = this.LerCampoOpcional<String>(campo);
                        if(this.nivelAcessoUsu.TemConteudo)
                        {
                            this.nivelAcessoUsu = this.nivelAcessoUsu.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PROCESSO":
                        this.processo = this.LerCampoOpcional<String>(campo);
                        if(this.processo.TemConteudo)
                        {
                            this.processo = this.processo.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PROGRAMA_ORIGEM":
                        this.programaOrigem = this.LerCampoOpcional<String>(campo);
                        if(this.programaOrigem.TemConteudo)
                        {
                            this.programaOrigem = this.programaOrigem.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "REFERENCIA":
                        this.referencia = this.LerCampoOpcional<String>(campo);
                        if(this.referencia.TemConteudo)
                        {
                            this.referencia = this.referencia.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "TRANSACAO":
                        this.transacao = this.LerCampoOpcional<String>(campo);
                        if(this.transacao.TemConteudo)
                        {
                            this.transacao = this.transacao.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "USUARIO_ORIGEM":
                        this.usuarioOrigem = this.LerCampoOpcional<String>(campo);
                        if(this.usuarioOrigem.TemConteudo)
                        {
                            this.usuarioOrigem = this.usuarioOrigem.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}