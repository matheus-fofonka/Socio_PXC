﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela AVALISTA_RURAL da base de dados PXC.</summary>
    public class TOAvalistaRural : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codAvalista;
        private CampoObrigatorio<Decimal> codProposta;
        private CampoObrigatorio<String> tipoPessoaAval;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> nomeAvalista;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_AVALISTA da tabela AVALISTA_RURAL.</summary>
        [XmlAttribute("cod_avalista")]
        [CampoTabela("COD_AVALISTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<Decimal> CodAvalista
        {
            get { return this.codAvalista; }
            set { this.codAvalista = value; }
        }

        /// <summary>Campo COD_PROPOSTA da tabela AVALISTA_RURAL.</summary>
        [XmlAttribute("cod_proposta")]
        [CampoTabela("COD_PROPOSTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<Decimal> CodProposta
        {
            get { return this.codProposta; }
            set { this.codProposta = value; }
        }

        /// <summary>Campo TIPO_PESSOA_AVAL da tabela AVALISTA_RURAL.</summary>
        [XmlAttribute("tipo_pessoa_aval")]
        [CampoTabela("TIPO_PESSOA_AVAL", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoaAval
        {
            get { return this.tipoPessoaAval; }
            set { this.tipoPessoaAval = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo NOME_AVALISTA da tabela AVALISTA_RURAL.</summary>
        [XmlAttribute("nome_avalista")]
        [CampoTabela("NOME_AVALISTA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> NomeAvalista
        { 
            get { return this.nomeAvalista; }
            set { this.nomeAvalista = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_AVALISTA":
                        this.codAvalista = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "COD_PROPOSTA":
                        this.codProposta = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "TIPO_PESSOA_AVAL":
                        this.tipoPessoaAval = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "NOME_AVALISTA":
                        this.nomeAvalista = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}