﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela BOLETO_BANRISUL da base de dados PXC.</summary>
    public class TOBoletoBanrisul : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<Int32> codNossoNro;
        private CampoObrigatorio<String> tipoPessoa;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int16> codMoeda;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<String> cpfCnpjSacado;
        private CampoObrigatorio<String> nomeSacado;
        private CampoObrigatorio<String> tipoSacado;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valorDocumento;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<DateTime> dataCancelamento;
        private CampoOpcional<DateTime> dataEmissao;
        private CampoOpcional<DateTime> dataPagamento;
        private CampoOpcional<DateTime> dataVencimento;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_CLIENTE da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        {
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_NOSSO_NRO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("cod_nosso_nro")]
        [CampoTabela("COD_NOSSO_NRO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodNossoNro
        {
            get { return this.codNossoNro; }
            set { this.codNossoNro = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        {
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_MOEDA da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("cod_moeda")]
        [CampoTabela("COD_MOEDA", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> CodMoeda
        { 
            get { return this.codMoeda; }
            set { this.codMoeda = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo CPF_CNPJ_SACADO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("cpf_cnpj_sacado")]
        [CampoTabela("CPF_CNPJ_SACADO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CpfCnpjSacado
        { 
            get { return this.cpfCnpjSacado; }
            set { this.cpfCnpjSacado = value; }
        }

        /// <summary>Campo NOME_SACADO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("nome_sacado")]
        [CampoTabela("NOME_SACADO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> NomeSacado
        { 
            get { return this.nomeSacado; }
            set { this.nomeSacado = value; }
        }

        /// <summary>Campo TIPO_SACADO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("tipo_sacado")]
        [CampoTabela("TIPO_SACADO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoSacado
        { 
            get { return this.tipoSacado; }
            set { this.tipoSacado = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR_DOCUMENTO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("valor_documento")]
        [CampoTabela("VALOR_DOCUMENTO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoObrigatorio<Decimal> ValorDocumento
        { 
            get { return this.valorDocumento; }
            set { this.valorDocumento = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo DATA_CANCELAMENTO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("data_cancelamento")]
        [CampoTabela("DATA_CANCELAMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataCancelamento
        {
            get { return this.dataCancelamento; }
            set { this.dataCancelamento = value; }
        }

        /// <summary>Campo DATA_EMISSAO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("data_emissao")]
        [CampoTabela("DATA_EMISSAO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataEmissao
        {
            get { return this.dataEmissao; }
            set { this.dataEmissao = value; }
        }

        /// <summary>Campo DATA_PAGAMENTO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("data_pagamento")]
        [CampoTabela("DATA_PAGAMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataPagamento
        {
            get { return this.dataPagamento; }
            set { this.dataPagamento = value; }
        }

        /// <summary>Campo DATA_VENCIMENTO da tabela BOLETO_BANRISUL.</summary>
        [XmlAttribute("data_vencimento")]
        [CampoTabela("DATA_VENCIMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataVencimento
        {
            get { return this.dataVencimento; }
            set { this.dataVencimento = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_NOSSO_NRO":
                        this.codNossoNro = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_MOEDA":
                        this.codMoeda = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "CPF_CNPJ_SACADO":
                        this.cpfCnpjSacado = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME_SACADO":
                        this.nomeSacado = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_SACADO":
                        this.tipoSacado = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR_DOCUMENTO":
                        this.valorDocumento = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "DATA_CANCELAMENTO":
                        this.dataCancelamento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DATA_EMISSAO":
                        this.dataEmissao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DATA_PAGAMENTO":
                        this.dataPagamento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DATA_VENCIMENTO":
                        this.dataVencimento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}