﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ORDERDETAILS da base de dados PXC.</summary>
    public class TOOrderdetails : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int32> ordernumber;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Int16> orderlinenumber;
        private CampoOpcional<Decimal> priceeach;
        private CampoOpcional<String> productcode;
        private CampoOpcional<Int32> quantityordered;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo ORDERNUMBER da tabela ORDERDETAILS.</summary>
        [XmlAttribute("ordernumber")]
        [CampoTabela("ORDERNUMBER", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> Ordernumber
        { 
            get { return this.ordernumber; }
            set { this.ordernumber = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo ORDERLINENUMBER da tabela ORDERDETAILS.</summary>
        [XmlAttribute("orderlinenumber")]
        [CampoTabela("ORDERLINENUMBER", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> Orderlinenumber
        {
            get { return this.orderlinenumber; }
            set { this.orderlinenumber = value; }
        }

        /// <summary>Campo PRICEEACH da tabela ORDERDETAILS.</summary>
        [XmlAttribute("priceeach")]
        [CampoTabela("PRICEEACH", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoOpcional<Decimal> Priceeach
        {
            get { return this.priceeach; }
            set { this.priceeach = value; }
        }

        /// <summary>Campo PRODUCTCODE da tabela ORDERDETAILS.</summary>
        [XmlAttribute("productcode")]
        [CampoTabela("PRODUCTCODE", TipoParametro = DbType.String, 
            Tamanho = 15, Precisao = 15)]
        public CampoOpcional<String> Productcode
        {
            get { return this.productcode; }
            set { this.productcode = value; }
        }

        /// <summary>Campo QUANTITYORDERED da tabela ORDERDETAILS.</summary>
        [XmlAttribute("quantityordered")]
        [CampoTabela("QUANTITYORDERED", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> Quantityordered
        {
            get { return this.quantityordered; }
            set { this.quantityordered = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias                        
                    #endregion

                    #region Campos Obrigatórios
                    case "ORDERNUMBER":
                        this.ordernumber = Convert.ToInt32(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "ORDERLINENUMBER":
                        this.orderlinenumber = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "PRICEEACH":
                        this.priceeach = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "PRODUCTCODE":
                        this.productcode = this.LerCampoOpcional<String>(campo);
                        if(this.productcode.TemConteudo)
                        {
                            this.productcode = this.productcode.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "QUANTITYORDERED":
                        this.quantityordered = this.LerCampoOpcional<Int32>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}