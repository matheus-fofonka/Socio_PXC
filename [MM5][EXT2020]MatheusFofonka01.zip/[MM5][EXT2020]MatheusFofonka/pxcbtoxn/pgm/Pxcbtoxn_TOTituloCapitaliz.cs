﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela TITULO_CAPITALIZ da base de dados PXC.</summary>
    public class TOTituloCapitaliz : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codTitulo;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codFormaPagto;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<Int16> codTipoTitulo;
        private CampoObrigatorio<Int16> numMesesPrazo;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valorPagamento;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> cpfCnpjBenefic;
        private CampoOpcional<DateTime> dtContratacao;
        private CampoOpcional<DateTime> dtResgate;
        private CampoOpcional<DateTime> dtVencimento;
        private CampoOpcional<String> tipoBeneficiario;
        private CampoOpcional<Decimal> valorResgate;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_TITULO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("cod_titulo")]
        [CampoTabela("COD_TITULO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodTitulo
        {
            get { return this.codTitulo; }
            set { this.codTitulo = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CLIENTE da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_FORMA_PAGTO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("cod_forma_pagto")]
        [CampoTabela("COD_FORMA_PAGTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> CodFormaPagto
        { 
            get { return this.codFormaPagto; }
            set { this.codFormaPagto = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo COD_TIPO_TITULO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("cod_tipo_titulo")]
        [CampoTabela("COD_TIPO_TITULO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> CodTipoTitulo
        { 
            get { return this.codTipoTitulo; }
            set { this.codTipoTitulo = value; }
        }

        /// <summary>Campo NUM_MESES_PRAZO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("num_meses_prazo")]
        [CampoTabela("NUM_MESES_PRAZO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> NumMesesPrazo
        { 
            get { return this.numMesesPrazo; }
            set { this.numMesesPrazo = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR_PAGAMENTO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("valor_pagamento")]
        [CampoTabela("VALOR_PAGAMENTO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> ValorPagamento
        { 
            get { return this.valorPagamento; }
            set { this.valorPagamento = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo CPF_CNPJ_BENEFIC da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("cpf_cnpj_benefic")]
        [CampoTabela("CPF_CNPJ_BENEFIC", TipoParametro = DbType.Decimal, 
            Tamanho = 14, Precisao = 14)]
        public CampoOpcional<Decimal> CpfCnpjBenefic
        {
            get { return this.cpfCnpjBenefic; }
            set { this.cpfCnpjBenefic = value; }
        }

        /// <summary>Campo DT_CONTRATACAO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("dt_contratacao")]
        [CampoTabela("DT_CONTRATACAO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtContratacao
        {
            get { return this.dtContratacao; }
            set { this.dtContratacao = value; }
        }

        /// <summary>Campo DT_RESGATE da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("dt_resgate")]
        [CampoTabela("DT_RESGATE", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtResgate
        {
            get { return this.dtResgate; }
            set { this.dtResgate = value; }
        }

        /// <summary>Campo DT_VENCIMENTO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("dt_vencimento")]
        [CampoTabela("DT_VENCIMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtVencimento
        {
            get { return this.dtVencimento; }
            set { this.dtVencimento = value; }
        }

        /// <summary>Campo TIPO_BENEFICIARIO da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("tipo_beneficiario")]
        [CampoTabela("TIPO_BENEFICIARIO", TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoOpcional<String> TipoBeneficiario
        {
            get { return this.tipoBeneficiario; }
            set { this.tipoBeneficiario = value; }
        }

        /// <summary>Campo VALOR_RESGATE da tabela TITULO_CAPITALIZ.</summary>
        [XmlAttribute("valor_resgate")]
        [CampoTabela("VALOR_RESGATE", TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> ValorResgate
        {
            get { return this.valorResgate; }
            set { this.valorResgate = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_TITULO":
                        this.codTitulo = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_FORMA_PAGTO":
                        this.codFormaPagto = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_TIPO_TITULO":
                        this.codTipoTitulo = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "NUM_MESES_PRAZO":
                        this.numMesesPrazo = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR_PAGAMENTO":
                        this.valorPagamento = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CPF_CNPJ_BENEFIC":
                        this.cpfCnpjBenefic = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "DT_CONTRATACAO":
                        this.dtContratacao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DT_RESGATE":
                        this.dtResgate = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DT_VENCIMENTO":
                        this.dtVencimento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "TIPO_BENEFICIARIO":
                        this.tipoBeneficiario = this.LerCampoOpcional<String>(campo);
                        if(this.tipoBeneficiario.TemConteudo)
                        {
                            this.tipoBeneficiario = this.tipoBeneficiario.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "VALOR_RESGATE":
                        this.valorResgate = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}