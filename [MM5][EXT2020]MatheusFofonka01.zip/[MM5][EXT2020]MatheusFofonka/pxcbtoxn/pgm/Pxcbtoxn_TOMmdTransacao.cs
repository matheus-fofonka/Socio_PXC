﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_TRANSACAO da base de dados PXC.</summary>
    public class TOMmdTransacao : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codTransacao;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> cpf;
        private CampoObrigatorio<DateTime> dtEntPrev;
        private CampoObrigatorio<DateTime> dtSaida;
        private CampoObrigatorio<Decimal> tipo;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valorTotal;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<DateTime> dtEntReal;
        private CampoOpcional<Decimal> multa;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_TRANSACAO da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("cod_transacao")]
        [CampoTabela("COD_TRANSACAO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodTransacao
        {
            get { return this.codTransacao; }
            set { this.codTransacao = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CPF da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("cpf")]
        [CampoTabela("CPF", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 11, Precisao = 11)]
        public CampoObrigatorio<Decimal> Cpf
        { 
            get { return this.cpf; }
            set { this.cpf = value; }
        }

        /// <summary>Campo DT_ENT_PREV da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("dt_ent_prev")]
        [CampoTabela("DT_ENT_PREV", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtEntPrev
        { 
            get { return this.dtEntPrev; }
            set { this.dtEntPrev = value; }
        }

        /// <summary>Campo DT_SAIDA da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("dt_saida")]
        [CampoTabela("DT_SAIDA", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtSaida
        { 
            get { return this.dtSaida; }
            set { this.dtSaida = value; }
        }

        /// <summary>Campo TIPO da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("tipo")]
        [CampoTabela("TIPO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 3, Precisao = 3)]
        public CampoObrigatorio<Decimal> Tipo
        { 
            get { return this.tipo; }
            set { this.tipo = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR_TOTAL da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("valor_total")]
        [CampoTabela("VALOR_TOTAL", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 7, Precisao = 7, Escala = 2)]
        public CampoObrigatorio<Decimal> ValorTotal
        { 
            get { return this.valorTotal; }
            set { this.valorTotal = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo DT_ENT_REAL da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("dt_ent_real")]
        [CampoTabela("DT_ENT_REAL", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtEntReal
        {
            get { return this.dtEntReal; }
            set { this.dtEntReal = value; }
        }

        /// <summary>Campo MULTA da tabela MMD_TRANSACAO.</summary>
        [XmlAttribute("multa")]
        [CampoTabela("MULTA", TipoParametro = DbType.Decimal, 
            Tamanho = 7, Precisao = 7, Escala = 2)]
        public CampoOpcional<Decimal> Multa
        {
            get { return this.multa; }
            set { this.multa = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_TRANSACAO":
                        this.codTransacao = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CPF":
                        this.cpf = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "DT_ENT_PREV":
                        this.dtEntPrev = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DT_SAIDA":
                        this.dtSaida = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "TIPO":
                        this.tipo = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR_TOTAL":
                        this.valorTotal = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "DT_ENT_REAL":
                        this.dtEntReal = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "MULTA":
                        this.multa = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}