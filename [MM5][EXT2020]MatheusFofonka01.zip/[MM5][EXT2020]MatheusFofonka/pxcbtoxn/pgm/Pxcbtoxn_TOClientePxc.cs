﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Collections.Generic;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CLIENTE_PXC da base de dados PXC.</summary>
    public class TOClientePxc : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codCliente;//
        private CampoObrigatorio<TipoPessoa> tipoPessoa;//
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int16> agencia;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> dtAbeCad;
        private CampoObrigatorio<String> nomeCliente;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<DateTime> dtConstituicao;
        private CampoOpcional<SimNao> indFuncBanrisul;
        private CampoOpcional<String> nomeFantasia;
        private CampoOpcional<String> nomeMae;
        private CampoOpcional<Int32> ultNossoNro;
        private CampoOpcional<Decimal> vlrCapitalSocial;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_CLIENTE da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        {
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<TipoPessoa> TipoPessoa
        {
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo AGENCIA da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("agencia")]
        [CampoTabela("AGENCIA", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> Agencia
        { 
            get { return this.agencia; }
            set { this.agencia = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DT_ABE_CAD da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("dt_abe_cad")]
        [CampoTabela("DT_ABE_CAD", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtAbeCad
        { 
            get { return this.dtAbeCad; }
            set { this.dtAbeCad = value; }
        }

        /// <summary>Campo NOME_CLIENTE da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("nome_cliente")]
        [CampoTabela("NOME_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> NomeCliente
        { 
            get { return this.nomeCliente; }
            set { this.nomeCliente = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo DT_CONSTITUICAO da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("dt_constituicao")]
        [CampoTabela("DT_CONSTITUICAO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtConstituicao
        {
            get { return this.dtConstituicao; }
            set { this.dtConstituicao = value; }
        }

        /// <summary>Campo IND_FUNC_BANRISUL da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("ind_func_banrisul")]
        [CampoTabela("IND_FUNC_BANRISUL", TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoOpcional<SimNao> IndFuncBanrisul
        {
            get { return this.indFuncBanrisul; }
            set { this.indFuncBanrisul = value; }
        }

        /// <summary>Campo NOME_FANTASIA da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("nome_fantasia")]
        [CampoTabela("NOME_FANTASIA", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> NomeFantasia
        {
            get { return this.nomeFantasia; }
            set { this.nomeFantasia = value; }
        }

        /// <summary>Campo NOME_MAE da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("nome_mae")]
        [CampoTabela("NOME_MAE", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> NomeMae
        {
            get { return this.nomeMae; }
            set { this.nomeMae = value; }
        }

        /// <summary>Campo ULT_NOSSO_NRO da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("ult_nosso_nro")]
        [CampoTabela("ULT_NOSSO_NRO", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> UltNossoNro
        {
            get { return this.ultNossoNro; }
            set { this.ultNossoNro = value; }
        }

        /// <summary>Campo VLR_CAPITAL_SOCIAL da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("vlr_capital_social")]
        [CampoTabela("VLR_CAPITAL_SOCIAL", TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> VlrCapitalSocial
        {
            get { return this.vlrCapitalSocial; }
            set { this.vlrCapitalSocial = value; }
        }

        /// <summary>Campo SOCIOS.</summary>
        [XmlAttribute("socios")]
        public CampoOpcional<List<TOSocio>> Socios { get; set; }

        /// <summary>Campo CARTOES.</summary>
        [XmlAttribute("cartoes")]
        public CampoOpcional<List<TOCartao>> Cartoes { get; set; }

        /// <summary>Campo CARTOES.</summary>     
        [XmlAttribute("filiais")]
        public CampoOpcional<List<TOCartao>> Filiais { get; set; }

        /// <summary>Campo CARTOES.</summary>
        [XmlAttribute("extratos")]
        public CampoOpcional<List<TOExtratoCliente>> Extratos { get; set; }

        /// <summary>Campo CARTOES.</summary>
        [XmlAttribute("emprestimos")]
        public CampoOpcional<List<TOEmprestimo>> Emprestimos { get; set; }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = (TipoPessoa)Convert.ToChar(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "AGENCIA":
                        this.agencia = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DT_ABE_CAD":
                        this.dtAbeCad = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "NOME_CLIENTE":
                        this.nomeCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "DT_CONSTITUICAO":
                        this.dtConstituicao = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "IND_FUNC_BANRISUL":
                        this.indFuncBanrisul = this.LerCampoOpcional<SimNao>(campo);
                        if(campo.Conteudo != null)
                        {
                            this.indFuncBanrisul = (SimNao)Convert.ToChar(this.indFuncBanrisul.LerConteudoOuPadrao());
                        }
                        break;
                    case "NOME_FANTASIA":
                        this.nomeFantasia = this.LerCampoOpcional<String>(campo);
                        if(this.nomeFantasia.TemConteudo)
                        {
                            this.nomeFantasia = this.nomeFantasia.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "NOME_MAE":
                        this.nomeMae = this.LerCampoOpcional<String>(campo);
                        if(this.nomeMae.TemConteudo)
                        {
                            this.nomeMae = this.nomeMae.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ULT_NOSSO_NRO":
                        this.ultNossoNro = this.LerCampoOpcional<Int32>(campo);
                        break;
                    case "VLR_CAPITAL_SOCIAL":
                        this.vlrCapitalSocial = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}