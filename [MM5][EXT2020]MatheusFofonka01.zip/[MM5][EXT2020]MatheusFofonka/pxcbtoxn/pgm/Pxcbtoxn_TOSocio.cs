﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{
    /// <summary>Representa um registro da tabela SOCIO da base de dados PXC.</summary>
    public class TOSocio : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> cpfCnpjSocio;        
        private CampoObrigatorio<TipoPessoa> tipoSocio;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> dtIniPart;
        private CampoObrigatorio<String> nomeSocio;
        private CampoObrigatorio<Decimal> percentParticip;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<EstadoCivil> codEstadoCivil;
        private CampoOpcional<RegimeCasamento> codRegimeCasam;
        private CampoOpcional<DateTime> dtFimPart;
        private CampoOpcional<DateTime> dtFundacao;
        #endregion
        #endregion

        #region Propriedades

        #region MES
        /// <summary>
        /// Salve
        /// </summary>
        [XmlAttribute("tempo_empresa")]
        public CampoOpcional<int> TempoEmpresa
        {
            get
            {
                DateTime date1, date2;
                Int32 meses = 0;
                if(!dtFimPart.TemConteudo) {
                    dtFimPart = DateTime.Now;
                }
                if(dtFimPart.TemConteudo && dtFimPart.LerConteudoOuPadrao() < DateTime.Now)
                {
                    date1 = dtFimPart.LerConteudoOuPadrao();
                }
                else
                {
                    date1 = DateTime.Now;
                }
                date2 = dtIniPart.LerConteudoOuPadrao();

                meses = ((date1.Year - date2.Year) * 12) + date1.Month - date2.Month;
                       
                return meses;
            }
        }
        #endregion

        #region Chaves Primárias
     
        /// <summary>Campo CPF_CNPJ_SOCIO da tabela SOCIO.</summary>
        [XmlAttribute("cpf_cnpj_socio")]
        [CampoTabela("CPF_CNPJ_SOCIO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<Decimal> CpfCnpjSocio
        {
            get { return this.cpfCnpjSocio; }
            set { this.cpfCnpjSocio = value; }
        }

        /// <summary>Campo TIPO_SOCIO da tabela SOCIO.</summary>
        [XmlAttribute("tipo_socio")]
        [CampoTabela("TIPO_SOCIO", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<TipoPessoa> TipoSocio
        {
            get { return this.tipoSocio; }
            set { this.tipoSocio = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela SOCIO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        {
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DT_INI_PART da tabela SOCIO.</summary>
        [XmlAttribute("dt_ini_part")]
        [CampoTabela("DT_INI_PART", Obrigatorio = true, TipoParametro = DbType.Date,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtIniPart
        {
            get { return this.dtIniPart; }
            set { this.dtIniPart = value; }
        }

        /// <summary>Campo NOME_SOCIO da tabela SOCIO.</summary>
        [XmlAttribute("nome_socio")]
        [CampoTabela("NOME_SOCIO", Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> NomeSocio
        {
            get { return this.nomeSocio; }
            set { this.nomeSocio = value; }
        }

        /// <summary>Campo PERCENT_PARTICIP da tabela SOCIO.</summary>
        [XmlAttribute("percent_particip")]
        [CampoTabela("PERCENT_PARTICIP", Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoObrigatorio<Decimal> PercentParticip
        {
            get { return this.percentParticip; }
            set { this.percentParticip = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela SOCIO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime,
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        {
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo COD_ESTADO_CIVIL da tabela SOCIO.</summary>
        [XmlAttribute("cod_estado_civil")]
        [CampoTabela("COD_ESTADO_CIVIL", TipoParametro = DbType.Int16,
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<EstadoCivil> CodEstadoCivil
        {
            get { return this.codEstadoCivil; }
            set { this.codEstadoCivil = value; }
        }

        /// <summary>Campo COD_REGIME_CASAM da tabela SOCIO.</summary>
        [XmlAttribute("cod_regime_casam")]
        [CampoTabela("COD_REGIME_CASAM", TipoParametro = DbType.Int16,
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<RegimeCasamento> CodRegimeCasam
        {
            get { return this.codRegimeCasam; }
            set { this.codRegimeCasam = value; }
        }

        /// <summary>Campo DT_FIM_PART da tabela SOCIO.</summary>
        [XmlAttribute("dt_fim_part")]
        [CampoTabela("DT_FIM_PART", TipoParametro = DbType.Date,
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtFimPart
        {
            get { return this.dtFimPart; }
            set { this.dtFimPart = value; }
        }

        /// <summary>Campo DT_FUNDACAO da tabela SOCIO.</summary>
        [XmlAttribute("dt_fundacao")]
        [CampoTabela("DT_FUNDACAO", TipoParametro = DbType.Date,
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtFundacao
        {
            get { return this.dtFundacao; }
            set { this.dtFundacao = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno( Linha linha )
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach(Campo campo in linha.Campos)
            {
                switch(campo.Nome)
                {
                    #region Chaves Primárias
                    
                    case "CPF_CNPJ_SOCIO":
                    this.cpfCnpjSocio = Convert.ToDecimal(campo.Conteudo);
                    break;                  
                    case "TIPO_SOCIO":
                    this.tipoSocio = (TipoPessoa)Convert.ToChar(campo.Conteudo);
                    break;
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                    this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                    break;
                    case "DT_INI_PART":
                    this.dtIniPart = Convert.ToDateTime(campo.Conteudo);
                    break;
                    case "NOME_SOCIO":
                    this.nomeSocio = Convert.ToString(campo.Conteudo).Trim();
                    break;
                    case "PERCENT_PARTICIP":
                    this.percentParticip = Convert.ToDecimal(campo.Conteudo);
                    break;
                    case "ULT_ATUALIZACAO":
                    this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                    break;
                    #endregion

                    #region Campos Opcionais
                    case "COD_ESTADO_CIVIL":
                    this.codEstadoCivil = (EstadoCivil)Convert.ToChar(campo.Conteudo);
                    break;
                    case "COD_REGIME_CASAM":
                    this.codRegimeCasam = (RegimeCasamento)Convert.ToChar(campo.Conteudo);
                    break;
                    case "DT_FIM_PART":
                    this.dtFimPart = this.LerCampoOpcional<DateTime>(campo);
                    break;
                    case "DT_FUNDACAO":
                    this.dtFundacao = this.LerCampoOpcional<DateTime>(campo);
                    break;
                    #endregion

                    default:
                    //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                    break;
                }
            }
        }
        #endregion
    }
}