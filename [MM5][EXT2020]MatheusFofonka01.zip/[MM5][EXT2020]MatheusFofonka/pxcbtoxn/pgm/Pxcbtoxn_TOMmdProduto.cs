﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_PRODUTO da base de dados PXC.</summary>
    public class TOMmdProduto : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codProduto;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> ano;
        private CampoObrigatorio<String> ativo;
        private CampoObrigatorio<String> nome;
        private CampoObrigatorio<Decimal> quantidade;
        private CampoObrigatorio<Decimal> tipo;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valor;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> artista;
        private CampoOpcional<String> autor;
        private CampoOpcional<Decimal> duracao;
        private CampoOpcional<Decimal> edicao;
        private CampoOpcional<String> editora;
        private CampoOpcional<String> gravadora;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_PRODUTO da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("cod_produto")]
        [CampoTabela("COD_PRODUTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodProduto
        {
            get { return this.codProduto; }
            set { this.codProduto = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo ANO da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("ano")]
        [CampoTabela("ANO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Decimal> Ano
        { 
            get { return this.ano; }
            set { this.ano = value; }
        }

        /// <summary>Campo ATIVO da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("ativo")]
        [CampoTabela("ATIVO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> Ativo
        { 
            get { return this.ativo; }
            set { this.ativo = value; }
        }

        /// <summary>Campo NOME da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("nome")]
        [CampoTabela("NOME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Nome
        { 
            get { return this.nome; }
            set { this.nome = value; }
        }

        /// <summary>Campo QUANTIDADE da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("quantidade")]
        [CampoTabela("QUANTIDADE", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Decimal> Quantidade
        { 
            get { return this.quantidade; }
            set { this.quantidade = value; }
        }

        /// <summary>Campo TIPO da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("tipo")]
        [CampoTabela("TIPO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<Decimal> Tipo
        { 
            get { return this.tipo; }
            set { this.tipo = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("valor")]
        [CampoTabela("VALOR", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 7, Precisao = 7, Escala = 2)]
        public CampoObrigatorio<Decimal> Valor
        { 
            get { return this.valor; }
            set { this.valor = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo ARTISTA da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("artista")]
        [CampoTabela("ARTISTA", TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoOpcional<String> Artista
        {
            get { return this.artista; }
            set { this.artista = value; }
        }

        /// <summary>Campo AUTOR da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("autor")]
        [CampoTabela("AUTOR", TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoOpcional<String> Autor
        {
            get { return this.autor; }
            set { this.autor = value; }
        }

        /// <summary>Campo DURACAO da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("duracao")]
        [CampoTabela("DURACAO", TipoParametro = DbType.Decimal, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Decimal> Duracao
        {
            get { return this.duracao; }
            set { this.duracao = value; }
        }

        /// <summary>Campo EDICAO da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("edicao")]
        [CampoTabela("EDICAO", TipoParametro = DbType.Decimal, 
            Tamanho = 3, Precisao = 3)]
        public CampoOpcional<Decimal> Edicao
        {
            get { return this.edicao; }
            set { this.edicao = value; }
        }

        /// <summary>Campo EDITORA da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("editora")]
        [CampoTabela("EDITORA", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Editora
        {
            get { return this.editora; }
            set { this.editora = value; }
        }

        /// <summary>Campo GRAVADORA da tabela MMD_PRODUTO.</summary>
        [XmlAttribute("gravadora")]
        [CampoTabela("GRAVADORA", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Gravadora
        {
            get { return this.gravadora; }
            set { this.gravadora = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_PRODUTO":
                        this.codProduto = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "ANO":
                        this.ano = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "ATIVO":
                        this.ativo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME":
                        this.nome = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "QUANTIDADE":
                        this.quantidade = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "TIPO":
                        this.tipo = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR":
                        this.valor = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "ARTISTA":
                        this.artista = this.LerCampoOpcional<String>(campo);
                        if(this.artista.TemConteudo)
                        {
                            this.artista = this.artista.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "AUTOR":
                        this.autor = this.LerCampoOpcional<String>(campo);
                        if(this.autor.TemConteudo)
                        {
                            this.autor = this.autor.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "DURACAO":
                        this.duracao = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "EDICAO":
                        this.edicao = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "EDITORA":
                        this.editora = this.LerCampoOpcional<String>(campo);
                        if(this.editora.TemConteudo)
                        {
                            this.editora = this.editora.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "GRAVADORA":
                        this.gravadora = this.LerCampoOpcional<String>(campo);
                        if(this.gravadora.TemConteudo)
                        {
                            this.gravadora = this.gravadora.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}