﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela BEM_CLIENTE da base de dados PXC.</summary>
    public class TOBemCliente : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> idBem;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<Decimal> percentual;
        private CampoObrigatorio<String> tipoBem;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> vlrDeclarado;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> endereco;
        private CampoOpcional<String> matriculaImovel;
        private CampoOpcional<String> modelo;
        private CampoOpcional<String> municipio;
        private CampoOpcional<String> placa;
        private CampoOpcional<String> uf;
        private CampoOpcional<Decimal> vlrFinanciado;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo ID_BEM da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("id_bem")]
        [CampoTabela("ID_BEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> IdBem
        {
            get { return this.idBem; }
            set { this.idBem = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CLIENTE da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo PERCENTUAL da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("percentual")]
        [CampoTabela("PERCENTUAL", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoObrigatorio<Decimal> Percentual
        { 
            get { return this.percentual; }
            set { this.percentual = value; }
        }

        /// <summary>Campo TIPO_BEM da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("tipo_bem")]
        [CampoTabela("TIPO_BEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoBem
        { 
            get { return this.tipoBem; }
            set { this.tipoBem = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VLR_DECLARADO da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("vlr_declarado")]
        [CampoTabela("VLR_DECLARADO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> VlrDeclarado
        { 
            get { return this.vlrDeclarado; }
            set { this.vlrDeclarado = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo ENDERECO da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("endereco")]
        [CampoTabela("ENDERECO", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Endereco
        {
            get { return this.endereco; }
            set { this.endereco = value; }
        }

        /// <summary>Campo MATRICULA_IMOVEL da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("matricula_imovel")]
        [CampoTabela("MATRICULA_IMOVEL", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> MatriculaImovel
        {
            get { return this.matriculaImovel; }
            set { this.matriculaImovel = value; }
        }

        /// <summary>Campo MODELO da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("modelo")]
        [CampoTabela("MODELO", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> Modelo
        {
            get { return this.modelo; }
            set { this.modelo = value; }
        }

        /// <summary>Campo MUNICIPIO da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("municipio")]
        [CampoTabela("MUNICIPIO", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Municipio
        {
            get { return this.municipio; }
            set { this.municipio = value; }
        }

        /// <summary>Campo PLACA da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("placa")]
        [CampoTabela("PLACA", TipoParametro = DbType.String, 
            Tamanho = 7, Precisao = 7)]
        public CampoOpcional<String> Placa
        {
            get { return this.placa; }
            set { this.placa = value; }
        }

        /// <summary>Campo UF da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<String> Uf
        {
            get { return this.uf; }
            set { this.uf = value; }
        }

        /// <summary>Campo VLR_FINANCIADO da tabela BEM_CLIENTE.</summary>
        [XmlAttribute("vlr_financiado")]
        [CampoTabela("VLR_FINANCIADO", TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> VlrFinanciado
        {
            get { return this.vlrFinanciado; }
            set { this.vlrFinanciado = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "ID_BEM":
                        this.idBem = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "PERCENTUAL":
                        this.percentual = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "TIPO_BEM":
                        this.tipoBem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VLR_DECLARADO":
                        this.vlrDeclarado = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "ENDERECO":
                        this.endereco = this.LerCampoOpcional<String>(campo);
                        if(this.endereco.TemConteudo)
                        {
                            this.endereco = this.endereco.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "MATRICULA_IMOVEL":
                        this.matriculaImovel = this.LerCampoOpcional<String>(campo);
                        if(this.matriculaImovel.TemConteudo)
                        {
                            this.matriculaImovel = this.matriculaImovel.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "MODELO":
                        this.modelo = this.LerCampoOpcional<String>(campo);
                        if(this.modelo.TemConteudo)
                        {
                            this.modelo = this.modelo.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "MUNICIPIO":
                        this.municipio = this.LerCampoOpcional<String>(campo);
                        if(this.municipio.TemConteudo)
                        {
                            this.municipio = this.municipio.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PLACA":
                        this.placa = this.LerCampoOpcional<String>(campo);
                        if(this.placa.TemConteudo)
                        {
                            this.placa = this.placa.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "UF":
                        this.uf = this.LerCampoOpcional<String>(campo);
                        if(this.uf.TemConteudo)
                        {
                            this.uf = this.uf.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "VLR_FINANCIADO":
                        this.vlrFinanciado = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}