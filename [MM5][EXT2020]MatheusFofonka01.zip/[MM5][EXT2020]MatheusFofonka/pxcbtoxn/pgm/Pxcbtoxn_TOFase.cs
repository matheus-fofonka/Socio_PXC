﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela FASE da base de dados PXC.</summary>
    public class TOFase : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codFase;
        private CampoObrigatorio<Decimal> codProposta;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> descrFase;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_FASE da tabela FASE.</summary>
        [XmlAttribute("cod_fase")]
        [CampoTabela("COD_FASE", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodFase
        {
            get { return this.codFase; }
            set { this.codFase = value; }
        }

        /// <summary>Campo COD_PROPOSTA da tabela FASE.</summary>
        [XmlAttribute("cod_proposta")]
        [CampoTabela("COD_PROPOSTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<Decimal> CodProposta
        {
            get { return this.codProposta; }
            set { this.codProposta = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo DESCR_FASE da tabela FASE.</summary>
        [XmlAttribute("descr_fase")]
        [CampoTabela("DESCR_FASE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> DescrFase
        { 
            get { return this.descrFase; }
            set { this.descrFase = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_FASE":
                        this.codFase = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "COD_PROPOSTA":
                        this.codProposta = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "DESCR_FASE":
                        this.descrFase = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}