﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_CLIENTE da base de dados PXC.</summary>
    public class TOMmdCliente : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> cpf;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> ativo;
        private CampoObrigatorio<Decimal> cep;
        private CampoObrigatorio<String> cidade;
        private CampoObrigatorio<DateTime> dtCadastro;
        private CampoObrigatorio<DateTime> dtNasc;
        private CampoObrigatorio<String> endereco;
        private CampoObrigatorio<String> nome;
        private CampoObrigatorio<Decimal> pontuacao;
        private CampoObrigatorio<String> uf;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CPF da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("cpf")]
        [CampoTabela("CPF", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 11, Precisao = 11)]
        public CampoObrigatorio<Decimal> Cpf
        {
            get { return this.cpf; }
            set { this.cpf = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo ATIVO da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("ativo")]
        [CampoTabela("ATIVO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> Ativo
        { 
            get { return this.ativo; }
            set { this.ativo = value; }
        }

        /// <summary>Campo CEP da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<Decimal> Cep
        { 
            get { return this.cep; }
            set { this.cep = value; }
        }

        /// <summary>Campo CIDADE da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("cidade")]
        [CampoTabela("CIDADE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Cidade
        { 
            get { return this.cidade; }
            set { this.cidade = value; }
        }

        /// <summary>Campo DT_CADASTRO da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("dt_cadastro")]
        [CampoTabela("DT_CADASTRO", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtCadastro
        { 
            get { return this.dtCadastro; }
            set { this.dtCadastro = value; }
        }

        /// <summary>Campo DT_NASC da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("dt_nasc")]
        [CampoTabela("DT_NASC", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtNasc
        { 
            get { return this.dtNasc; }
            set { this.dtNasc = value; }
        }

        /// <summary>Campo ENDERECO da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("endereco")]
        [CampoTabela("ENDERECO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Endereco
        { 
            get { return this.endereco; }
            set { this.endereco = value; }
        }

        /// <summary>Campo NOME da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("nome")]
        [CampoTabela("NOME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Nome
        { 
            get { return this.nome; }
            set { this.nome = value; }
        }

        /// <summary>Campo PONTUACAO da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("pontuacao")]
        [CampoTabela("PONTUACAO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Decimal> Pontuacao
        { 
            get { return this.pontuacao; }
            set { this.pontuacao = value; }
        }

        /// <summary>Campo UF da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> Uf
        { 
            get { return this.uf; }
            set { this.uf = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela MMD_CLIENTE.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CPF":
                        this.cpf = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "ATIVO":
                        this.ativo = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "CEP":
                        this.cep = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "CIDADE":
                        this.cidade = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DT_CADASTRO":
                        this.dtCadastro = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DT_NASC":
                        this.dtNasc = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "ENDERECO":
                        this.endereco = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME":
                        this.nome = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "PONTUACAO":
                        this.pontuacao = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "UF":
                        this.uf = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}