﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela IMOVEL_BEM da base de dados PXC.</summary>
    public class TOImovelBem : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> idBem;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> cartorio;
        private CampoObrigatorio<String> cidade;
        private CampoObrigatorio<String> codMatricula;
        private CampoObrigatorio<String> comarca;
        private CampoObrigatorio<String> endereco;
        private CampoObrigatorio<String> indUrbanoRural;
        private CampoObrigatorio<Int16> numEndereco;
        private CampoObrigatorio<String> uf;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> areaTotal;
        private CampoOpcional<String> cep;
        private CampoOpcional<String> complEndereco;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo ID_BEM da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("id_bem")]
        [CampoTabela("ID_BEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> IdBem
        {
            get { return this.idBem; }
            set { this.idBem = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CARTORIO da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("cartorio")]
        [CampoTabela("CARTORIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Cartorio
        { 
            get { return this.cartorio; }
            set { this.cartorio = value; }
        }

        /// <summary>Campo CIDADE da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("cidade")]
        [CampoTabela("CIDADE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> Cidade
        { 
            get { return this.cidade; }
            set { this.cidade = value; }
        }

        /// <summary>Campo COD_MATRICULA da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("cod_matricula")]
        [CampoTabela("COD_MATRICULA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<String> CodMatricula
        { 
            get { return this.codMatricula; }
            set { this.codMatricula = value; }
        }

        /// <summary>Campo COMARCA da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("comarca")]
        [CampoTabela("COMARCA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Comarca
        { 
            get { return this.comarca; }
            set { this.comarca = value; }
        }

        /// <summary>Campo ENDERECO da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("endereco")]
        [CampoTabela("ENDERECO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Endereco
        { 
            get { return this.endereco; }
            set { this.endereco = value; }
        }

        /// <summary>Campo IND_URBANO_RURAL da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("ind_urbano_rural")]
        [CampoTabela("IND_URBANO_RURAL", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndUrbanoRural
        { 
            get { return this.indUrbanoRural; }
            set { this.indUrbanoRural = value; }
        }

        /// <summary>Campo NUM_ENDERECO da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("num_endereco")]
        [CampoTabela("NUM_ENDERECO", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> NumEndereco
        { 
            get { return this.numEndereco; }
            set { this.numEndereco = value; }
        }

        /// <summary>Campo UF da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> Uf
        { 
            get { return this.uf; }
            set { this.uf = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo AREA_TOTAL da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("area_total")]
        [CampoTabela("AREA_TOTAL", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoOpcional<Decimal> AreaTotal
        {
            get { return this.areaTotal; }
            set { this.areaTotal = value; }
        }

        /// <summary>Campo CEP da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> Cep
        {
            get { return this.cep; }
            set { this.cep = value; }
        }

        /// <summary>Campo COMPL_ENDERECO da tabela IMOVEL_BEM.</summary>
        [XmlAttribute("compl_endereco")]
        [CampoTabela("COMPL_ENDERECO", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> ComplEndereco
        {
            get { return this.complEndereco; }
            set { this.complEndereco = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "ID_BEM":
                        this.idBem = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CARTORIO":
                        this.cartorio = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "CIDADE":
                        this.cidade = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_MATRICULA":
                        this.codMatricula = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COMARCA":
                        this.comarca = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ENDERECO":
                        this.endereco = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_URBANO_RURAL":
                        this.indUrbanoRural = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NUM_ENDERECO":
                        this.numEndereco = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "UF":
                        this.uf = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "AREA_TOTAL":
                        this.areaTotal = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "CEP":
                        this.cep = this.LerCampoOpcional<String>(campo);
                        if(this.cep.TemConteudo)
                        {
                            this.cep = this.cep.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "COMPL_ENDERECO":
                        this.complEndereco = this.LerCampoOpcional<String>(campo);
                        if(this.complEndereco.TemConteudo)
                        {
                            this.complEndereco = this.complEndereco.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}