﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CARTAO da base de dados PXC.</summary>
    public class TOCartao : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> numeroCartao;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> dataValidade;
        private CampoObrigatorio<String> nomeCartao;
        private CampoObrigatorio<String> tipoCartao;
        private CampoObrigatorio<String> tipoPessoa;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> agencia;
        private CampoOpcional<Decimal> conta;
        private CampoOpcional<DateTime> dataCancelamento;
        private CampoOpcional<Decimal> diaVencimento;
        private CampoOpcional<Int16> tipoBandeira;
        private CampoOpcional<Int16> tipoPatrocinio;
        private CampoOpcional<Decimal> valorLimite;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo NUMERO_CARTAO da tabela CARTAO.</summary>
        [XmlAttribute("numero_cartao")]
        [CampoTabela("NUMERO_CARTAO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 16, Precisao = 16)]
        public CampoObrigatorio<Decimal> NumeroCartao
        {
            get { return this.numeroCartao; }
            set { this.numeroCartao = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CLIENTE da tabela CARTAO.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        { 
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela CARTAO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DATA_VALIDADE da tabela CARTAO.</summary>
        [XmlAttribute("data_validade")]
        [CampoTabela("DATA_VALIDADE", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataValidade
        { 
            get { return this.dataValidade; }
            set { this.dataValidade = value; }
        }

        /// <summary>Campo NOME_CARTAO da tabela CARTAO.</summary>
        [XmlAttribute("nome_cartao")]
        [CampoTabela("NOME_CARTAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> NomeCartao
        { 
            get { return this.nomeCartao; }
            set { this.nomeCartao = value; }
        }

        /// <summary>Campo TIPO_CARTAO da tabela CARTAO.</summary>
        [XmlAttribute("tipo_cartao")]
        [CampoTabela("TIPO_CARTAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoCartao
        { 
            get { return this.tipoCartao; }
            set { this.tipoCartao = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela CARTAO.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        { 
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela CARTAO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo AGENCIA da tabela CARTAO.</summary>
        [XmlAttribute("agencia")]
        [CampoTabela("AGENCIA", TipoParametro = DbType.Decimal, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Decimal> Agencia
        {
            get { return this.agencia; }
            set { this.agencia = value; }
        }

        /// <summary>Campo CONTA da tabela CARTAO.</summary>
        [XmlAttribute("conta")]
        [CampoTabela("CONTA", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<Decimal> Conta
        {
            get { return this.conta; }
            set { this.conta = value; }
        }

        /// <summary>Campo DATA_CANCELAMENTO da tabela CARTAO.</summary>
        [XmlAttribute("data_cancelamento")]
        [CampoTabela("DATA_CANCELAMENTO", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataCancelamento
        {
            get { return this.dataCancelamento; }
            set { this.dataCancelamento = value; }
        }

        /// <summary>Campo DIA_VENCIMENTO da tabela CARTAO.</summary>
        [XmlAttribute("dia_vencimento")]
        [CampoTabela("DIA_VENCIMENTO", TipoParametro = DbType.Decimal, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Decimal> DiaVencimento
        {
            get { return this.diaVencimento; }
            set { this.diaVencimento = value; }
        }

        /// <summary>Campo TIPO_BANDEIRA da tabela CARTAO.</summary>
        [XmlAttribute("tipo_bandeira")]
        [CampoTabela("TIPO_BANDEIRA", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> TipoBandeira
        {
            get { return this.tipoBandeira; }
            set { this.tipoBandeira = value; }
        }

        /// <summary>Campo TIPO_PATROCINIO da tabela CARTAO.</summary>
        [XmlAttribute("tipo_patrocinio")]
        [CampoTabela("TIPO_PATROCINIO", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> TipoPatrocinio
        {
            get { return this.tipoPatrocinio; }
            set { this.tipoPatrocinio = value; }
        }

        /// <summary>Campo VALOR_LIMITE da tabela CARTAO.</summary>
        [XmlAttribute("valor_limite")]
        [CampoTabela("VALOR_LIMITE", TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> ValorLimite
        {
            get { return this.valorLimite; }
            set { this.valorLimite = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "NUMERO_CARTAO":
                        this.numeroCartao = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_VALIDADE":
                        this.dataValidade = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "NOME_CARTAO":
                        this.nomeCartao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_CARTAO":
                        this.tipoCartao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "AGENCIA":
                        this.agencia = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "CONTA":
                        this.conta = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "DATA_CANCELAMENTO":
                        this.dataCancelamento = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DIA_VENCIMENTO":
                        this.diaVencimento = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "TIPO_BANDEIRA":
                        this.tipoBandeira = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "TIPO_PATROCINIO":
                        this.tipoPatrocinio = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "VALOR_LIMITE":
                        this.valorLimite = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}