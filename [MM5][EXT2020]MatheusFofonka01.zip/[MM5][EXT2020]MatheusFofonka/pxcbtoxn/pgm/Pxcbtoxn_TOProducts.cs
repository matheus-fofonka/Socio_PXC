﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela PRODUCTS da base de dados PXC.</summary>
    public class TOProducts : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> productcode;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> buyprice;
        private CampoOpcional<Decimal> msrp;
        private CampoOpcional<String> productdescription;
        private CampoOpcional<String> productline;
        private CampoOpcional<String> productname;
        private CampoOpcional<String> productscale;
        private CampoOpcional<String> productvendor;
        private CampoOpcional<Int32> quantityinstock;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo PRODUCTCODE da tabela PRODUCTS.</summary>
        [XmlAttribute("productcode")]
        [CampoTabela("PRODUCTCODE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 15, Precisao = 15)]
        public CampoObrigatorio<String> Productcode
        { 
            get { return this.productcode; }
            set { this.productcode = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo BUYPRICE da tabela PRODUCTS.</summary>
        [XmlAttribute("buyprice")]
        [CampoTabela("BUYPRICE", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoOpcional<Decimal> Buyprice
        {
            get { return this.buyprice; }
            set { this.buyprice = value; }
        }

        /// <summary>Campo MSRP da tabela PRODUCTS.</summary>
        [XmlAttribute("msrp")]
        [CampoTabela("MSRP", TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoOpcional<Decimal> Msrp
        {
            get { return this.msrp; }
            set { this.msrp = value; }
        }

        /// <summary>Campo PRODUCTDESCRIPTION da tabela PRODUCTS.</summary>
        [XmlAttribute("productdescription")]
        [CampoTabela("PRODUCTDESCRIPTION", TipoParametro = DbType.String, 
            Tamanho = 200, Precisao = 200)]
        public CampoOpcional<String> Productdescription
        {
            get { return this.productdescription; }
            set { this.productdescription = value; }
        }

        /// <summary>Campo PRODUCTLINE da tabela PRODUCTS.</summary>
        [XmlAttribute("productline")]
        [CampoTabela("PRODUCTLINE", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Productline
        {
            get { return this.productline; }
            set { this.productline = value; }
        }

        /// <summary>Campo PRODUCTNAME da tabela PRODUCTS.</summary>
        [XmlAttribute("productname")]
        [CampoTabela("PRODUCTNAME", TipoParametro = DbType.String, 
            Tamanho = 70, Precisao = 70)]
        public CampoOpcional<String> Productname
        {
            get { return this.productname; }
            set { this.productname = value; }
        }

        /// <summary>Campo PRODUCTSCALE da tabela PRODUCTS.</summary>
        [XmlAttribute("productscale")]
        [CampoTabela("PRODUCTSCALE", TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<String> Productscale
        {
            get { return this.productscale; }
            set { this.productscale = value; }
        }

        /// <summary>Campo PRODUCTVENDOR da tabela PRODUCTS.</summary>
        [XmlAttribute("productvendor")]
        [CampoTabela("PRODUCTVENDOR", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Productvendor
        {
            get { return this.productvendor; }
            set { this.productvendor = value; }
        }

        /// <summary>Campo QUANTITYINSTOCK da tabela PRODUCTS.</summary>
        [XmlAttribute("quantityinstock")]
        [CampoTabela("QUANTITYINSTOCK", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> Quantityinstock
        {
            get { return this.quantityinstock; }
            set { this.quantityinstock = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias                        
                    #endregion

                    #region Campos Obrigatórios
                    case "PRODUCTCODE":
                        this.productcode = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "BUYPRICE":
                        this.buyprice = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "MSRP":
                        this.msrp = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "PRODUCTDESCRIPTION":
                        this.productdescription = this.LerCampoOpcional<String>(campo);
                        if(this.productdescription.TemConteudo)
                        {
                            this.productdescription = this.productdescription.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PRODUCTLINE":
                        this.productline = this.LerCampoOpcional<String>(campo);
                        if(this.productline.TemConteudo)
                        {
                            this.productline = this.productline.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PRODUCTNAME":
                        this.productname = this.LerCampoOpcional<String>(campo);
                        if(this.productname.TemConteudo)
                        {
                            this.productname = this.productname.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PRODUCTSCALE":
                        this.productscale = this.LerCampoOpcional<String>(campo);
                        if(this.productscale.TemConteudo)
                        {
                            this.productscale = this.productscale.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PRODUCTVENDOR":
                        this.productvendor = this.LerCampoOpcional<String>(campo);
                        if(this.productvendor.TemConteudo)
                        {
                            this.productvendor = this.productvendor.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "QUANTITYINSTOCK":
                        this.quantityinstock = this.LerCampoOpcional<Int32>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}