﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ALUNOS da base de dados PXC.</summary>
    public class TOAlunos : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> matricula;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<String> nome;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> email;
        private CampoOpcional<String> telefone;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo MATRICULA da tabela ALUNOS.</summary>
        [XmlAttribute("matricula")]
        [CampoTabela("MATRICULA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> Matricula
        {
            get { return this.matricula; }
            set { this.matricula = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela ALUNOS.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo NOME da tabela ALUNOS.</summary>
        [XmlAttribute("nome")]
        [CampoTabela("NOME", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 35, Precisao = 35)]
        public CampoObrigatorio<String> Nome
        { 
            get { return this.nome; }
            set { this.nome = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela ALUNOS.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo EMAIL da tabela ALUNOS.</summary>
        [XmlAttribute("email")]
        [CampoTabela("EMAIL", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Email
        {
            get { return this.email; }
            set { this.email = value; }
        }

        /// <summary>Campo TELEFONE da tabela ALUNOS.</summary>
        [XmlAttribute("telefone")]
        [CampoTabela("TELEFONE", TipoParametro = DbType.String, 
            Tamanho = 15, Precisao = 15)]
        public CampoOpcional<String> Telefone
        {
            get { return this.telefone; }
            set { this.telefone = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "MATRICULA":
                        this.matricula = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NOME":
                        this.nome = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "EMAIL":
                        this.email = this.LerCampoOpcional<String>(campo);
                        if(this.email.TemConteudo)
                        {
                            this.email = this.email.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "TELEFONE":
                        this.telefone = this.LerCampoOpcional<String>(campo);
                        if(this.telefone.TemConteudo)
                        {
                            this.telefone = this.telefone.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        break;
                }
            }
        }
        #endregion
    }
}