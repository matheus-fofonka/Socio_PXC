﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela BTR_LOG_EVENTO da base de dados PXC.</summary>
    public class TOBtrLogEvento : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<DateTime> dataHoraMensagem;
        private CampoObrigatorio<String> produto;
        private CampoObrigatorio<String> siglaSistema;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> classeContexto;
        private CampoObrigatorio<String> codMensagem;
        private CampoObrigatorio<String> idBaseDados;
        private CampoObrigatorio<String> indBaixa;
        private CampoObrigatorio<String> maquinaCliente;
        private CampoObrigatorio<String> maquinaOrigem;
        private CampoObrigatorio<String> nivelMensagem;
        private CampoObrigatorio<Int16> particaoMes;
        private CampoObrigatorio<String> programa;
        private CampoObrigatorio<Int32> seq;
        private CampoObrigatorio<String> tipoEquipamento;
        private CampoObrigatorio<String> tipoProcesso;
        private CampoObrigatorio<String> usuarioBd;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> chaveGrupo;
        private CampoOpcional<String> classeSistema;
        private CampoOpcional<String> codErro;
        private CampoOpcional<Int16> codGrupo;
        private CampoOpcional<Int16> codReferencia;
        private CampoOpcional<String> complMensagem;
        private CampoOpcional<String> idEntradaRede;
        private CampoOpcional<String> idProcesso;
        private CampoOpcional<String> mnemonico;
        private CampoOpcional<Int32> ordemServico;
        private CampoOpcional<String> pontoPrograma;
        private CampoOpcional<String> processo;
        private CampoOpcional<String> programaOrigem;
        private CampoOpcional<String> referencia;
        private CampoOpcional<String> sistemaOrigem;
        private CampoOpcional<String> transacao;
        private CampoOpcional<String> usuarioOrigem;
        private CampoOpcional<String> versaoOrigem;
        private CampoOpcional<String> versaoPrograma;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo DATA_HORA_MENSAGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("data_hora_mensagem")]
        [CampoTabela("DATA_HORA_MENSAGEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.DateTime,
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DataHoraMensagem
        {
            get { return this.dataHoraMensagem; }
            set { this.dataHoraMensagem = value; }
        }

        /// <summary>Campo PRODUTO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("produto")]
        [CampoTabela("PRODUTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 16, Precisao = 16)]
        public CampoObrigatorio<String> Produto
        {
            get { return this.produto; }
            set { this.produto = value; }
        }

        /// <summary>Campo SIGLA_SISTEMA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("sigla_sistema")]
        [CampoTabela("SIGLA_SISTEMA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 3, Precisao = 3)]
        public CampoObrigatorio<String> SiglaSistema
        {
            get { return this.siglaSistema; }
            set { this.siglaSistema = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo CLASSE_CONTEXTO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("classe_contexto")]
        [CampoTabela("CLASSE_CONTEXTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> ClasseContexto
        { 
            get { return this.classeContexto; }
            set { this.classeContexto = value; }
        }

        /// <summary>Campo COD_MENSAGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("cod_mensagem")]
        [CampoTabela("COD_MENSAGEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> CodMensagem
        { 
            get { return this.codMensagem; }
            set { this.codMensagem = value; }
        }

        /// <summary>Campo ID_BASE_DADOS da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("id_base_dados")]
        [CampoTabela("ID_BASE_DADOS", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> IdBaseDados
        { 
            get { return this.idBaseDados; }
            set { this.idBaseDados = value; }
        }

        /// <summary>Campo IND_BAIXA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("ind_baixa")]
        [CampoTabela("IND_BAIXA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> IndBaixa
        { 
            get { return this.indBaixa; }
            set { this.indBaixa = value; }
        }

        /// <summary>Campo MAQUINA_CLIENTE da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("maquina_cliente")]
        [CampoTabela("MAQUINA_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 40, Precisao = 40)]
        public CampoObrigatorio<String> MaquinaCliente
        { 
            get { return this.maquinaCliente; }
            set { this.maquinaCliente = value; }
        }

        /// <summary>Campo MAQUINA_ORIGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("maquina_origem")]
        [CampoTabela("MAQUINA_ORIGEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoObrigatorio<String> MaquinaOrigem
        { 
            get { return this.maquinaOrigem; }
            set { this.maquinaOrigem = value; }
        }

        /// <summary>Campo NIVEL_MENSAGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("nivel_mensagem")]
        [CampoTabela("NIVEL_MENSAGEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> NivelMensagem
        { 
            get { return this.nivelMensagem; }
            set { this.nivelMensagem = value; }
        }

        /// <summary>Campo PARTICAO_MES da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("particao_mes")]
        [CampoTabela("PARTICAO_MES", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> ParticaoMes
        { 
            get { return this.particaoMes; }
            set { this.particaoMes = value; }
        }

        /// <summary>Campo PROGRAMA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("programa")]
        [CampoTabela("PROGRAMA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> Programa
        { 
            get { return this.programa; }
            set { this.programa = value; }
        }

        /// <summary>Campo SEQ da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("seq")]
        [CampoTabela("SEQ", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> Seq
        { 
            get { return this.seq; }
            set { this.seq = value; }
        }

        /// <summary>Campo TIPO_EQUIPAMENTO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("tipo_equipamento")]
        [CampoTabela("TIPO_EQUIPAMENTO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoEquipamento
        { 
            get { return this.tipoEquipamento; }
            set { this.tipoEquipamento = value; }
        }

        /// <summary>Campo TIPO_PROCESSO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("tipo_processo")]
        [CampoTabela("TIPO_PROCESSO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoProcesso
        { 
            get { return this.tipoProcesso; }
            set { this.tipoProcesso = value; }
        }

        /// <summary>Campo USUARIO_BD da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("usuario_bd")]
        [CampoTabela("USUARIO_BD", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoObrigatorio<String> UsuarioBd
        { 
            get { return this.usuarioBd; }
            set { this.usuarioBd = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo CHAVE_GRUPO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("chave_grupo")]
        [CampoTabela("CHAVE_GRUPO", TipoParametro = DbType.String, 
            Tamanho = 254, Precisao = 254)]
        public CampoOpcional<String> ChaveGrupo
        {
            get { return this.chaveGrupo; }
            set { this.chaveGrupo = value; }
        }

        /// <summary>Campo CLASSE_SISTEMA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("classe_sistema")]
        [CampoTabela("CLASSE_SISTEMA", TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<String> ClasseSistema
        {
            get { return this.classeSistema; }
            set { this.classeSistema = value; }
        }

        /// <summary>Campo COD_ERRO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("cod_erro")]
        [CampoTabela("COD_ERRO", TipoParametro = DbType.String, 
            Tamanho = 5, Precisao = 5)]
        public CampoOpcional<String> CodErro
        {
            get { return this.codErro; }
            set { this.codErro = value; }
        }

        /// <summary>Campo COD_GRUPO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("cod_grupo")]
        [CampoTabela("COD_GRUPO", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> CodGrupo
        {
            get { return this.codGrupo; }
            set { this.codGrupo = value; }
        }

        /// <summary>Campo COD_REFERENCIA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("cod_referencia")]
        [CampoTabela("COD_REFERENCIA", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> CodReferencia
        {
            get { return this.codReferencia; }
            set { this.codReferencia = value; }
        }

        /// <summary>Campo COMPL_MENSAGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("compl_mensagem")]
        [CampoTabela("COMPL_MENSAGEM", TipoParametro = DbType.String, 
            Tamanho = 254, Precisao = 254)]
        public CampoOpcional<String> ComplMensagem
        {
            get { return this.complMensagem; }
            set { this.complMensagem = value; }
        }

        /// <summary>Campo ID_ENTRADA_REDE da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("id_entrada_rede")]
        [CampoTabela("ID_ENTRADA_REDE", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> IdEntradaRede
        {
            get { return this.idEntradaRede; }
            set { this.idEntradaRede = value; }
        }

        /// <summary>Campo ID_PROCESSO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("id_processo")]
        [CampoTabela("ID_PROCESSO", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> IdProcesso
        {
            get { return this.idProcesso; }
            set { this.idProcesso = value; }
        }

        /// <summary>Campo MNEMONICO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("mnemonico")]
        [CampoTabela("MNEMONICO", TipoParametro = DbType.String, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<String> Mnemonico
        {
            get { return this.mnemonico; }
            set { this.mnemonico = value; }
        }

        /// <summary>Campo ORDEM_SERVICO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("ordem_servico")]
        [CampoTabela("ORDEM_SERVICO", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> OrdemServico
        {
            get { return this.ordemServico; }
            set { this.ordemServico = value; }
        }

        /// <summary>Campo PONTO_PROGRAMA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("ponto_programa")]
        [CampoTabela("PONTO_PROGRAMA", TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<String> PontoPrograma
        {
            get { return this.pontoPrograma; }
            set { this.pontoPrograma = value; }
        }

        /// <summary>Campo PROCESSO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("processo")]
        [CampoTabela("PROCESSO", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> Processo
        {
            get { return this.processo; }
            set { this.processo = value; }
        }

        /// <summary>Campo PROGRAMA_ORIGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("programa_origem")]
        [CampoTabela("PROGRAMA_ORIGEM", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> ProgramaOrigem
        {
            get { return this.programaOrigem; }
            set { this.programaOrigem = value; }
        }

        /// <summary>Campo REFERENCIA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("referencia")]
        [CampoTabela("REFERENCIA", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> Referencia
        {
            get { return this.referencia; }
            set { this.referencia = value; }
        }

        /// <summary>Campo SISTEMA_ORIGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("sistema_origem")]
        [CampoTabela("SISTEMA_ORIGEM", TipoParametro = DbType.String, 
            Tamanho = 3, Precisao = 3)]
        public CampoOpcional<String> SistemaOrigem
        {
            get { return this.sistemaOrigem; }
            set { this.sistemaOrigem = value; }
        }

        /// <summary>Campo TRANSACAO da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("transacao")]
        [CampoTabela("TRANSACAO", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> Transacao
        {
            get { return this.transacao; }
            set { this.transacao = value; }
        }

        /// <summary>Campo USUARIO_ORIGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("usuario_origem")]
        [CampoTabela("USUARIO_ORIGEM", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> UsuarioOrigem
        {
            get { return this.usuarioOrigem; }
            set { this.usuarioOrigem = value; }
        }

        /// <summary>Campo VERSAO_ORIGEM da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("versao_origem")]
        [CampoTabela("VERSAO_ORIGEM", TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoOpcional<String> VersaoOrigem
        {
            get { return this.versaoOrigem; }
            set { this.versaoOrigem = value; }
        }

        /// <summary>Campo VERSAO_PROGRAMA da tabela BTR_LOG_EVENTO.</summary>
        [XmlAttribute("versao_programa")]
        [CampoTabela("VERSAO_PROGRAMA", TipoParametro = DbType.String, 
            Tamanho = 14, Precisao = 14)]
        public CampoOpcional<String> VersaoPrograma
        {
            get { return this.versaoPrograma; }
            set { this.versaoPrograma = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "DATA_HORA_MENSAGEM":
                        this.dataHoraMensagem = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "PRODUTO":
                        this.produto = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "SIGLA_SISTEMA":
                        this.siglaSistema = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "CLASSE_CONTEXTO":
                        this.classeContexto = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_MENSAGEM":
                        this.codMensagem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ID_BASE_DADOS":
                        this.idBaseDados = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_BAIXA":
                        this.indBaixa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "MAQUINA_CLIENTE":
                        this.maquinaCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "MAQUINA_ORIGEM":
                        this.maquinaOrigem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NIVEL_MENSAGEM":
                        this.nivelMensagem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "PARTICAO_MES":
                        this.particaoMes = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "PROGRAMA":
                        this.programa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "SEQ":
                        this.seq = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "TIPO_EQUIPAMENTO":
                        this.tipoEquipamento = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PROCESSO":
                        this.tipoProcesso = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "USUARIO_BD":
                        this.usuarioBd = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CHAVE_GRUPO":
                        this.chaveGrupo = this.LerCampoOpcional<String>(campo);
                        if(this.chaveGrupo.TemConteudo)
                        {
                            this.chaveGrupo = this.chaveGrupo.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CLASSE_SISTEMA":
                        this.classeSistema = this.LerCampoOpcional<String>(campo);
                        if(this.classeSistema.TemConteudo)
                        {
                            this.classeSistema = this.classeSistema.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "COD_ERRO":
                        this.codErro = this.LerCampoOpcional<String>(campo);
                        if(this.codErro.TemConteudo)
                        {
                            this.codErro = this.codErro.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "COD_GRUPO":
                        this.codGrupo = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "COD_REFERENCIA":
                        this.codReferencia = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "COMPL_MENSAGEM":
                        this.complMensagem = this.LerCampoOpcional<String>(campo);
                        if(this.complMensagem.TemConteudo)
                        {
                            this.complMensagem = this.complMensagem.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ID_ENTRADA_REDE":
                        this.idEntradaRede = this.LerCampoOpcional<String>(campo);
                        if(this.idEntradaRede.TemConteudo)
                        {
                            this.idEntradaRede = this.idEntradaRede.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ID_PROCESSO":
                        this.idProcesso = this.LerCampoOpcional<String>(campo);
                        if(this.idProcesso.TemConteudo)
                        {
                            this.idProcesso = this.idProcesso.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "MNEMONICO":
                        this.mnemonico = this.LerCampoOpcional<String>(campo);
                        if(this.mnemonico.TemConteudo)
                        {
                            this.mnemonico = this.mnemonico.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ORDEM_SERVICO":
                        this.ordemServico = this.LerCampoOpcional<Int32>(campo);
                        break;
                    case "PONTO_PROGRAMA":
                        this.pontoPrograma = this.LerCampoOpcional<String>(campo);
                        if(this.pontoPrograma.TemConteudo)
                        {
                            this.pontoPrograma = this.pontoPrograma.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PROCESSO":
                        this.processo = this.LerCampoOpcional<String>(campo);
                        if(this.processo.TemConteudo)
                        {
                            this.processo = this.processo.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PROGRAMA_ORIGEM":
                        this.programaOrigem = this.LerCampoOpcional<String>(campo);
                        if(this.programaOrigem.TemConteudo)
                        {
                            this.programaOrigem = this.programaOrigem.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "REFERENCIA":
                        this.referencia = this.LerCampoOpcional<String>(campo);
                        if(this.referencia.TemConteudo)
                        {
                            this.referencia = this.referencia.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "SISTEMA_ORIGEM":
                        this.sistemaOrigem = this.LerCampoOpcional<String>(campo);
                        if(this.sistemaOrigem.TemConteudo)
                        {
                            this.sistemaOrigem = this.sistemaOrigem.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "TRANSACAO":
                        this.transacao = this.LerCampoOpcional<String>(campo);
                        if(this.transacao.TemConteudo)
                        {
                            this.transacao = this.transacao.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "USUARIO_ORIGEM":
                        this.usuarioOrigem = this.LerCampoOpcional<String>(campo);
                        if(this.usuarioOrigem.TemConteudo)
                        {
                            this.usuarioOrigem = this.usuarioOrigem.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "VERSAO_ORIGEM":
                        this.versaoOrigem = this.LerCampoOpcional<String>(campo);
                        if(this.versaoOrigem.TemConteudo)
                        {
                            this.versaoOrigem = this.versaoOrigem.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "VERSAO_PROGRAMA":
                        this.versaoPrograma = this.LerCampoOpcional<String>(campo);
                        if(this.versaoPrograma.TemConteudo)
                        {
                            this.versaoPrograma = this.versaoPrograma.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}