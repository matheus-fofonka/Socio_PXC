﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela TECNICO_RURAL da base de dados PXC.</summary>
    public class TOTecnicoRural : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> cpfTecnico;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codUsuario;
        private CampoObrigatorio<DateTime> dthrUltAtu;
        private CampoObrigatorio<String> nomeTecnico;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CPF_TECNICO da tabela TECNICO_RURAL.</summary>
        [XmlAttribute("cpf_tecnico")]
        [CampoTabela("CPF_TECNICO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 11, Precisao = 11)]
        public CampoObrigatorio<Decimal> CpfTecnico
        {
            get { return this.cpfTecnico; }
            set { this.cpfTecnico = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_USUARIO da tabela TECNICO_RURAL.</summary>
        [XmlAttribute("cod_usuario")]
        [CampoTabela("COD_USUARIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodUsuario
        { 
            get { return this.codUsuario; }
            set { this.codUsuario = value; }
        }

        /// <summary>Campo DTHR_ULT_ATU da tabela TECNICO_RURAL.</summary>
        [XmlAttribute("dthr_ult_atu")]
        [CampoTabela("DTHR_ULT_ATU", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DthrUltAtu
        { 
            get { return this.dthrUltAtu; }
            set { this.dthrUltAtu = value; }
        }

        /// <summary>Campo NOME_TECNICO da tabela TECNICO_RURAL.</summary>
        [XmlAttribute("nome_tecnico")]
        [CampoTabela("NOME_TECNICO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> NomeTecnico
        { 
            get { return this.nomeTecnico; }
            set { this.nomeTecnico = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CPF_TECNICO":
                        this.cpfTecnico = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_USUARIO":
                        this.codUsuario = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DTHR_ULT_ATU":
                        this.dthrUltAtu = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "NOME_TECNICO":
                        this.nomeTecnico = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}