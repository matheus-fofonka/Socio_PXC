﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_NACIONALIDADE da base de dados PXC.</summary>
    public class TOMmdNacionalidade : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codNacionalidade;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> descricao;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_NACIONALIDADE da tabela MMD_NACIONALIDADE.</summary>
        [XmlAttribute("cod_nacionalidade")]
        [CampoTabela("COD_NACIONALIDADE", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 3, Precisao = 3)]
        public CampoObrigatorio<Decimal> CodNacionalidade
        {
            get { return this.codNacionalidade; }
            set { this.codNacionalidade = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo DESCRICAO da tabela MMD_NACIONALIDADE.</summary>
        [XmlAttribute("descricao")]
        [CampoTabela("DESCRICAO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 60, Precisao = 60)]
        public CampoObrigatorio<String> Descricao
        { 
            get { return this.descricao; }
            set { this.descricao = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_NACIONALIDADE":
                        this.codNacionalidade = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "DESCRICAO":
                        this.descricao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}