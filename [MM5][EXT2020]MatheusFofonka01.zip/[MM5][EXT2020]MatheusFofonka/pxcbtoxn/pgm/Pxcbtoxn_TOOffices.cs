﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela OFFICES da base de dados PXC.</summary>
    public class TOOffices : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> officecode;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> addressline1;
        private CampoOpcional<String> addressline2;
        private CampoOpcional<String> city;
        private CampoOpcional<String> country;
        private CampoOpcional<String> phone;
        private CampoOpcional<String> postalcode;
        private CampoOpcional<String> state;
        private CampoOpcional<String> territory;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo OFFICECODE da tabela OFFICES.</summary>
        [XmlAttribute("officecode")]
        [CampoTabela("OFFICECODE", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<String> Officecode
        { 
            get { return this.officecode; }
            set { this.officecode = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo ADDRESSLINE1 da tabela OFFICES.</summary>
        [XmlAttribute("addressline1")]
        [CampoTabela("ADDRESSLINE1", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Addressline1
        {
            get { return this.addressline1; }
            set { this.addressline1 = value; }
        }

        /// <summary>Campo ADDRESSLINE2 da tabela OFFICES.</summary>
        [XmlAttribute("addressline2")]
        [CampoTabela("ADDRESSLINE2", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Addressline2
        {
            get { return this.addressline2; }
            set { this.addressline2 = value; }
        }

        /// <summary>Campo CITY da tabela OFFICES.</summary>
        [XmlAttribute("city")]
        [CampoTabela("CITY", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> City
        {
            get { return this.city; }
            set { this.city = value; }
        }

        /// <summary>Campo COUNTRY da tabela OFFICES.</summary>
        [XmlAttribute("country")]
        [CampoTabela("COUNTRY", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Country
        {
            get { return this.country; }
            set { this.country = value; }
        }

        /// <summary>Campo PHONE da tabela OFFICES.</summary>
        [XmlAttribute("phone")]
        [CampoTabela("PHONE", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Phone
        {
            get { return this.phone; }
            set { this.phone = value; }
        }

        /// <summary>Campo POSTALCODE da tabela OFFICES.</summary>
        [XmlAttribute("postalcode")]
        [CampoTabela("POSTALCODE", TipoParametro = DbType.String, 
            Tamanho = 15, Precisao = 15)]
        public CampoOpcional<String> Postalcode
        {
            get { return this.postalcode; }
            set { this.postalcode = value; }
        }

        /// <summary>Campo STATE da tabela OFFICES.</summary>
        [XmlAttribute("state")]
        [CampoTabela("STATE", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> State
        {
            get { return this.state; }
            set { this.state = value; }
        }

        /// <summary>Campo TERRITORY da tabela OFFICES.</summary>
        [XmlAttribute("territory")]
        [CampoTabela("TERRITORY", TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<String> Territory
        {
            get { return this.territory; }
            set { this.territory = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias                        
                    #endregion

                    #region Campos Obrigatórios
                    case "OFFICECODE":
                        this.officecode = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "ADDRESSLINE1":
                        this.addressline1 = this.LerCampoOpcional<String>(campo);
                        if(this.addressline1.TemConteudo)
                        {
                            this.addressline1 = this.addressline1.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "ADDRESSLINE2":
                        this.addressline2 = this.LerCampoOpcional<String>(campo);
                        if(this.addressline2.TemConteudo)
                        {
                            this.addressline2 = this.addressline2.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CITY":
                        this.city = this.LerCampoOpcional<String>(campo);
                        if(this.city.TemConteudo)
                        {
                            this.city = this.city.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "COUNTRY":
                        this.country = this.LerCampoOpcional<String>(campo);
                        if(this.country.TemConteudo)
                        {
                            this.country = this.country.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PHONE":
                        this.phone = this.LerCampoOpcional<String>(campo);
                        if(this.phone.TemConteudo)
                        {
                            this.phone = this.phone.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "POSTALCODE":
                        this.postalcode = this.LerCampoOpcional<String>(campo);
                        if(this.postalcode.TemConteudo)
                        {
                            this.postalcode = this.postalcode.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "STATE":
                        this.state = this.LerCampoOpcional<String>(campo);
                        if(this.state.TemConteudo)
                        {
                            this.state = this.state.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "TERRITORY":
                        this.territory = this.LerCampoOpcional<String>(campo);
                        if(this.territory.TemConteudo)
                        {
                            this.territory = this.territory.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}