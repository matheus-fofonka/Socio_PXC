﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;
using System.ComponentModel;

namespace Bergs.Pxc.Pxcbtoxn
{
    #region :: Exercício 6 - Criar enum ::
    /// <summary>Enumaração TipoImovel</summary>
    [CharEnum]
    public enum TipoImovel
    {
        /// <summary>Apartamento</summary>
        [Description("Apartamento")]
        Apartamento = 'A',
        /// <summary>Sala Comercial</summary>
        [Description("Sala Comercial")]
        SalaComercial = 'S',
        /// <summary>Prédio</summary>
        [Description("Prédio")]
        Predio = 'P',
        /// <summary>Casa</summary>
        [Description("Casa")]
        Casa = 'C',
        /// <summary>Terreno</summary>
        [Description("Terreno")]
        Terreno = 'T'
    }
    #endregion

    #region Exercício Cliente
    /// <summary>Enumaração TipoPessoa</summary>
    [CharEnum]
    public enum TipoPessoa
    {
        /// <summary>Física</summary>
        [Description("Física")]
        Fisica = 'F',
        /// <summary>Jurídica</summary>
        [Description("Jurídica")]
        Juridica = 'J',
    }

    /// <summary>Enumaração SimNao</summary>
    [CharEnum]
    public enum SimNao
    {
        /// <summary>Sim</summary>
        [Description("Sim")]
        Sim = 'S',
        /// <summary>Nao</summary>
        [Description("Nao")]
        Nao = 'N',
    }
    #endregion
    #region SocioEXT
    /// <summary>Enumaração EstadoCivil </summary>
    
    public enum EstadoCivil
    {
        /// <summary>Casado</summary>
        [Description("Casado")]
        Casado = 2,
        /// <summary>Desquitado</summary>
        [Description("Desquitado")]
        Desquitado = 6,
        /// <summary>Divorciado</summary>
        [Description("Divorciado")]
        Divorciado = 5,
        /// <summary>Separado</summary>
        [Description("Separado")]
        Separado = 4,
        /// <summary>Solteiro</summary>
        [Description("Solteiro")]
        Solteiro = 1,
        /// <summary>UniaoEstavel</summary>
        [Description("UniaoEstavel")]
        UniaoEstavel = 3,
        /// <summary>Viuvo</summary>
        [Description("Viuvo")]
        Viuvo = 7,

    }
    /// <summary>Regime Casamento</summary>
    public enum RegimeCasamento
    {
        /// <summary>ComunhaoParcial</summary>
        [Description("ComunhaoParcial")]
        ComunhaoParcial = 2,
        /// <summary>ComunhaoTotal</summary>
        [Description("ComunhaoTotal")]
        ComunhaoTotal = 3,
        /// <summary>Divorciado</summary>
        [Description("SeparacaoTotal")]
        Divorciado = 1,
        
    }
    #endregion

    #region 
    /// <summary> </summary>
    [CharEnum]
    public enum SituacaoEmprestimo
    {
        /// <summary>Ativo</summary>
        [Description("Ativo")]
        Ativo = 'A',
        /// <summary>Cancelado</summary>
        [Description("Cancelado")]
        Cancelado = 'C',
        /// <summary>Física</summary>
        [Description("Invalido")]
        Invalido = 'I',
        /// <summary>Física</summary>
        [Description("Pago")]
        Pago = 'P',
    }
    #endregion
}