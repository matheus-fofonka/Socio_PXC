﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela TURMA_TREINAMENTO da base de dados PXC.</summary>
    public class TOTurmaTreinamento : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codTurma;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Decimal> codCurso;
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<DateTime> dataFim;
        private CampoObrigatorio<DateTime> dataIni;
        private CampoObrigatorio<String> descLocal;
        private CampoObrigatorio<String> horaEntrada;
        private CampoObrigatorio<String> horaSaida;
        private CampoObrigatorio<String> instrutor;
        private CampoObrigatorio<Decimal> numAlunos;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_TURMA da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("cod_turma")]
        [CampoTabela("COD_TURMA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<String> CodTurma
        {
            get { return this.codTurma; }
            set { this.codTurma = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_CURSO da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("cod_curso")]
        [CampoTabela("COD_CURSO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodCurso
        { 
            get { return this.codCurso; }
            set { this.codCurso = value; }
        }

        /// <summary>Campo COD_OPERADOR da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo DATA_FIM da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("data_fim")]
        [CampoTabela("DATA_FIM", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataFim
        { 
            get { return this.dataFim; }
            set { this.dataFim = value; }
        }

        /// <summary>Campo DATA_INI da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("data_ini")]
        [CampoTabela("DATA_INI", Obrigatorio = true, TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataIni
        { 
            get { return this.dataIni; }
            set { this.dataIni = value; }
        }

        /// <summary>Campo DESC_LOCAL da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("desc_local")]
        [CampoTabela("DESC_LOCAL", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 100, Precisao = 100)]
        public CampoObrigatorio<String> DescLocal
        { 
            get { return this.descLocal; }
            set { this.descLocal = value; }
        }

        /// <summary>Campo HORA_ENTRADA da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("hora_entrada")]
        [CampoTabela("HORA_ENTRADA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<String> HoraEntrada
        { 
            get { return this.horaEntrada; }
            set { this.horaEntrada = value; }
        }

        /// <summary>Campo HORA_SAIDA da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("hora_saida")]
        [CampoTabela("HORA_SAIDA", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<String> HoraSaida
        { 
            get { return this.horaSaida; }
            set { this.horaSaida = value; }
        }

        /// <summary>Campo INSTRUTOR da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("instrutor")]
        [CampoTabela("INSTRUTOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 100, Precisao = 100)]
        public CampoObrigatorio<String> Instrutor
        { 
            get { return this.instrutor; }
            set { this.instrutor = value; }
        }

        /// <summary>Campo NUM_ALUNOS da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("num_alunos")]
        [CampoTabela("NUM_ALUNOS", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 3, Precisao = 3)]
        public CampoObrigatorio<Decimal> NumAlunos
        { 
            get { return this.numAlunos; }
            set { this.numAlunos = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela TURMA_TREINAMENTO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_TURMA":
                        this.codTurma = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_CURSO":
                        this.codCurso = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DATA_FIM":
                        this.dataFim = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DATA_INI":
                        this.dataIni = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DESC_LOCAL":
                        this.descLocal = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "HORA_ENTRADA":
                        this.horaEntrada = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "HORA_SAIDA":
                        this.horaSaida = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "INSTRUTOR":
                        this.instrutor = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NUM_ALUNOS":
                        this.numAlunos = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}