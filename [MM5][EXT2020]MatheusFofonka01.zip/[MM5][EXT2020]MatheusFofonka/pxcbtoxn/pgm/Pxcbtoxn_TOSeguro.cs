﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela SEGURO da base de dados PXC.</summary>
    public class TOSeguro : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codCliente;
        private CampoObrigatorio<Int32> numeroApolice;
        private CampoObrigatorio<String> tipoPessoa;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codOperador;
        private CampoObrigatorio<Int16> tipoApolice;
        private CampoObrigatorio<DateTime> ultAtualizacao;
        private CampoObrigatorio<Decimal> valorSegurado;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Int16> anoFabricacao;
        private CampoOpcional<String> bairro;
        private CampoOpcional<String> cep;
        private CampoOpcional<String> cidade;
        private CampoOpcional<Decimal> cpfBeneficiario;
        private CampoOpcional<DateTime> dataFimVigencia;
        private CampoOpcional<DateTime> dataIniVigencia;
        private CampoOpcional<String> endereco;
        private CampoOpcional<String> marca;
        private CampoOpcional<String> modelo;
        private CampoOpcional<String> placa;
        private CampoOpcional<String> uf;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_CLIENTE da tabela SEGURO.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente
        {
            get { return this.codCliente; }
            set { this.codCliente = value; }
        }

        /// <summary>Campo NUMERO_APOLICE da tabela SEGURO.</summary>
        [XmlAttribute("numero_apolice")]
        [CampoTabela("NUMERO_APOLICE", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> NumeroApolice
        {
            get { return this.numeroApolice; }
            set { this.numeroApolice = value; }
        }

        /// <summary>Campo TIPO_PESSOA da tabela SEGURO.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa
        {
            get { return this.tipoPessoa; }
            set { this.tipoPessoa = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_OPERADOR da tabela SEGURO.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador
        { 
            get { return this.codOperador; }
            set { this.codOperador = value; }
        }

        /// <summary>Campo TIPO_APOLICE da tabela SEGURO.</summary>
        [XmlAttribute("tipo_apolice")]
        [CampoTabela("TIPO_APOLICE", Obrigatorio = true, TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> TipoApolice
        { 
            get { return this.tipoApolice; }
            set { this.tipoApolice = value; }
        }

        /// <summary>Campo ULT_ATUALIZACAO da tabela SEGURO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao
        { 
            get { return this.ultAtualizacao; }
            set { this.ultAtualizacao = value; }
        }

        /// <summary>Campo VALOR_SEGURADO da tabela SEGURO.</summary>
        [XmlAttribute("valor_segurado")]
        [CampoTabela("VALOR_SEGURADO", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> ValorSegurado
        { 
            get { return this.valorSegurado; }
            set { this.valorSegurado = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo ANO_FABRICACAO da tabela SEGURO.</summary>
        [XmlAttribute("ano_fabricacao")]
        [CampoTabela("ANO_FABRICACAO", TipoParametro = DbType.Int16, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<Int16> AnoFabricacao
        {
            get { return this.anoFabricacao; }
            set { this.anoFabricacao = value; }
        }

        /// <summary>Campo BAIRRO da tabela SEGURO.</summary>
        [XmlAttribute("bairro")]
        [CampoTabela("BAIRRO", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> Bairro
        {
            get { return this.bairro; }
            set { this.bairro = value; }
        }

        /// <summary>Campo CEP da tabela SEGURO.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", TipoParametro = DbType.String, 
            Tamanho = 8, Precisao = 8)]
        public CampoOpcional<String> Cep
        {
            get { return this.cep; }
            set { this.cep = value; }
        }

        /// <summary>Campo CIDADE da tabela SEGURO.</summary>
        [XmlAttribute("cidade")]
        [CampoTabela("CIDADE", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> Cidade
        {
            get { return this.cidade; }
            set { this.cidade = value; }
        }

        /// <summary>Campo CPF_BENEFICIARIO da tabela SEGURO.</summary>
        [XmlAttribute("cpf_beneficiario")]
        [CampoTabela("CPF_BENEFICIARIO", TipoParametro = DbType.Decimal, 
            Tamanho = 11, Precisao = 11)]
        public CampoOpcional<Decimal> CpfBeneficiario
        {
            get { return this.cpfBeneficiario; }
            set { this.cpfBeneficiario = value; }
        }

        /// <summary>Campo DATA_FIM_VIGENCIA da tabela SEGURO.</summary>
        [XmlAttribute("data_fim_vigencia")]
        [CampoTabela("DATA_FIM_VIGENCIA", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataFimVigencia
        {
            get { return this.dataFimVigencia; }
            set { this.dataFimVigencia = value; }
        }

        /// <summary>Campo DATA_INI_VIGENCIA da tabela SEGURO.</summary>
        [XmlAttribute("data_ini_vigencia")]
        [CampoTabela("DATA_INI_VIGENCIA", TipoParametro = DbType.Date, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DataIniVigencia
        {
            get { return this.dataIniVigencia; }
            set { this.dataIniVigencia = value; }
        }

        /// <summary>Campo ENDERECO da tabela SEGURO.</summary>
        [XmlAttribute("endereco")]
        [CampoTabela("ENDERECO", TipoParametro = DbType.String, 
            Tamanho = 40, Precisao = 40)]
        public CampoOpcional<String> Endereco
        {
            get { return this.endereco; }
            set { this.endereco = value; }
        }

        /// <summary>Campo MARCA da tabela SEGURO.</summary>
        [XmlAttribute("marca")]
        [CampoTabela("MARCA", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> Marca
        {
            get { return this.marca; }
            set { this.marca = value; }
        }

        /// <summary>Campo MODELO da tabela SEGURO.</summary>
        [XmlAttribute("modelo")]
        [CampoTabela("MODELO", TipoParametro = DbType.String, 
            Tamanho = 20, Precisao = 20)]
        public CampoOpcional<String> Modelo
        {
            get { return this.modelo; }
            set { this.modelo = value; }
        }

        /// <summary>Campo PLACA da tabela SEGURO.</summary>
        [XmlAttribute("placa")]
        [CampoTabela("PLACA", TipoParametro = DbType.String, 
            Tamanho = 7, Precisao = 7)]
        public CampoOpcional<String> Placa
        {
            get { return this.placa; }
            set { this.placa = value; }
        }

        /// <summary>Campo UF da tabela SEGURO.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", TipoParametro = DbType.String, 
            Tamanho = 2, Precisao = 2)]
        public CampoOpcional<String> Uf
        {
            get { return this.uf; }
            set { this.uf = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CLIENTE":
                        this.codCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "NUMERO_APOLICE":
                        this.numeroApolice = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "TIPO_PESSOA":
                        this.tipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_OPERADOR":
                        this.codOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_APOLICE":
                        this.tipoApolice = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "ULT_ATUALIZACAO":
                        this.ultAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "VALOR_SEGURADO":
                        this.valorSegurado = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "ANO_FABRICACAO":
                        this.anoFabricacao = this.LerCampoOpcional<Int16>(campo);
                        break;
                    case "BAIRRO":
                        this.bairro = this.LerCampoOpcional<String>(campo);
                        if(this.bairro.TemConteudo)
                        {
                            this.bairro = this.bairro.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CEP":
                        this.cep = this.LerCampoOpcional<String>(campo);
                        if(this.cep.TemConteudo)
                        {
                            this.cep = this.cep.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CIDADE":
                        this.cidade = this.LerCampoOpcional<String>(campo);
                        if(this.cidade.TemConteudo)
                        {
                            this.cidade = this.cidade.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "CPF_BENEFICIARIO":
                        this.cpfBeneficiario = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "DATA_FIM_VIGENCIA":
                        this.dataFimVigencia = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "DATA_INI_VIGENCIA":
                        this.dataIniVigencia = this.LerCampoOpcional<DateTime>(campo);
                        break;
                    case "ENDERECO":
                        this.endereco = this.LerCampoOpcional<String>(campo);
                        if(this.endereco.TemConteudo)
                        {
                            this.endereco = this.endereco.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "MARCA":
                        this.marca = this.LerCampoOpcional<String>(campo);
                        if(this.marca.TemConteudo)
                        {
                            this.marca = this.marca.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "MODELO":
                        this.modelo = this.LerCampoOpcional<String>(campo);
                        if(this.modelo.TemConteudo)
                        {
                            this.modelo = this.modelo.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "PLACA":
                        this.placa = this.LerCampoOpcional<String>(campo);
                        if(this.placa.TemConteudo)
                        {
                            this.placa = this.placa.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "UF":
                        this.uf = this.LerCampoOpcional<String>(campo);
                        if(this.uf.TemConteudo)
                        {
                            this.uf = this.uf.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}