﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela EMPLOYEES da base de dados PXC.</summary>
    public class TOEmployees : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<Int32> employeenumber;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> email;
        private CampoOpcional<String> extension;
        private CampoOpcional<String> firstname;
        private CampoOpcional<String> jobtitle;
        private CampoOpcional<String> lastname;
        private CampoOpcional<String> officecode;
        private CampoOpcional<Int32> reportsto;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo EMPLOYEENUMBER da tabela EMPLOYEES.</summary>
        [XmlAttribute("employeenumber")]
        [CampoTabela("EMPLOYEENUMBER", Obrigatorio = true, TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> Employeenumber
        { 
            get { return this.employeenumber; }
            set { this.employeenumber = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo EMAIL da tabela EMPLOYEES.</summary>
        [XmlAttribute("email")]
        [CampoTabela("EMAIL", TipoParametro = DbType.String, 
            Tamanho = 100, Precisao = 100)]
        public CampoOpcional<String> Email
        {
            get { return this.email; }
            set { this.email = value; }
        }

        /// <summary>Campo EXTENSION da tabela EMPLOYEES.</summary>
        [XmlAttribute("extension")]
        [CampoTabela("EXTENSION", TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<String> Extension
        {
            get { return this.extension; }
            set { this.extension = value; }
        }

        /// <summary>Campo FIRSTNAME da tabela EMPLOYEES.</summary>
        [XmlAttribute("firstname")]
        [CampoTabela("FIRSTNAME", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Firstname
        {
            get { return this.firstname; }
            set { this.firstname = value; }
        }

        /// <summary>Campo JOBTITLE da tabela EMPLOYEES.</summary>
        [XmlAttribute("jobtitle")]
        [CampoTabela("JOBTITLE", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Jobtitle
        {
            get { return this.jobtitle; }
            set { this.jobtitle = value; }
        }

        /// <summary>Campo LASTNAME da tabela EMPLOYEES.</summary>
        [XmlAttribute("lastname")]
        [CampoTabela("LASTNAME", TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoOpcional<String> Lastname
        {
            get { return this.lastname; }
            set { this.lastname = value; }
        }

        /// <summary>Campo OFFICECODE da tabela EMPLOYEES.</summary>
        [XmlAttribute("officecode")]
        [CampoTabela("OFFICECODE", TipoParametro = DbType.String, 
            Tamanho = 10, Precisao = 10)]
        public CampoOpcional<String> Officecode
        {
            get { return this.officecode; }
            set { this.officecode = value; }
        }

        /// <summary>Campo REPORTSTO da tabela EMPLOYEES.</summary>
        [XmlAttribute("reportsto")]
        [CampoTabela("REPORTSTO", TipoParametro = DbType.Int32, 
            Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> Reportsto
        {
            get { return this.reportsto; }
            set { this.reportsto = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias                        
                    #endregion

                    #region Campos Obrigatórios
                    case "EMPLOYEENUMBER":
                        this.employeenumber = Convert.ToInt32(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "EMAIL":
                        this.email = this.LerCampoOpcional<String>(campo);
                        if(this.email.TemConteudo)
                        {
                            this.email = this.email.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "EXTENSION":
                        this.extension = this.LerCampoOpcional<String>(campo);
                        if(this.extension.TemConteudo)
                        {
                            this.extension = this.extension.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "FIRSTNAME":
                        this.firstname = this.LerCampoOpcional<String>(campo);
                        if(this.firstname.TemConteudo)
                        {
                            this.firstname = this.firstname.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "JOBTITLE":
                        this.jobtitle = this.LerCampoOpcional<String>(campo);
                        if(this.jobtitle.TemConteudo)
                        {
                            this.jobtitle = this.jobtitle.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "LASTNAME":
                        this.lastname = this.LerCampoOpcional<String>(campo);
                        if(this.lastname.TemConteudo)
                        {
                            this.lastname = this.lastname.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "OFFICECODE":
                        this.officecode = this.LerCampoOpcional<String>(campo);
                        if(this.officecode.TemConteudo)
                        {
                            this.officecode = this.officecode.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "REPORTSTO":
                        this.reportsto = this.LerCampoOpcional<Int32>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}