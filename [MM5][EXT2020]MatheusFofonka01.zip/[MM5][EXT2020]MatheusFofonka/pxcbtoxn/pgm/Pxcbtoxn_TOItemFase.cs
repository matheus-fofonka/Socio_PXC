﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ITEM_FASE da base de dados PXC.</summary>
    public class TOItemFase : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codFase;
        private CampoObrigatorio<Int32> codItem;
        private CampoObrigatorio<Decimal> codProposta;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> descrItem;
        private CampoObrigatorio<Decimal> qtdItem;
        private CampoObrigatorio<Decimal> vlrItem;
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_FASE da tabela ITEM_FASE.</summary>
        [XmlAttribute("cod_fase")]
        [CampoTabela("COD_FASE", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodFase
        {
            get { return this.codFase; }
            set { this.codFase = value; }
        }

        /// <summary>Campo COD_ITEM da tabela ITEM_FASE.</summary>
        [XmlAttribute("cod_item")]
        [CampoTabela("COD_ITEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodItem
        {
            get { return this.codItem; }
            set { this.codItem = value; }
        }

        /// <summary>Campo COD_PROPOSTA da tabela ITEM_FASE.</summary>
        [XmlAttribute("cod_proposta")]
        [CampoTabela("COD_PROPOSTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 10, Precisao = 10)]
        public CampoObrigatorio<Decimal> CodProposta
        {
            get { return this.codProposta; }
            set { this.codProposta = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo DESCR_ITEM da tabela ITEM_FASE.</summary>
        [XmlAttribute("descr_item")]
        [CampoTabela("DESCR_ITEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> DescrItem
        { 
            get { return this.descrItem; }
            set { this.descrItem = value; }
        }

        /// <summary>Campo QTD_ITEM da tabela ITEM_FASE.</summary>
        [XmlAttribute("qtd_item")]
        [CampoTabela("QTD_ITEM", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 10, Precisao = 10, Escala = 2)]
        public CampoObrigatorio<Decimal> QtdItem
        { 
            get { return this.qtdItem; }
            set { this.qtdItem = value; }
        }

        /// <summary>Campo VLR_ITEM da tabela ITEM_FASE.</summary>
        [XmlAttribute("vlr_item")]
        [CampoTabela("VLR_ITEM", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<Decimal> VlrItem
        { 
            get { return this.vlrItem; }
            set { this.vlrItem = value; }
        }

        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_FASE":
                        this.codFase = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "COD_ITEM":
                        this.codItem = Convert.ToInt32(campo.Conteudo);
                        break;
                    case "COD_PROPOSTA":
                        this.codProposta = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "DESCR_ITEM":
                        this.descrItem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "QTD_ITEM":
                        this.qtdItem = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "VLR_ITEM":
                        this.vlrItem = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}