﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CADALUNO da base de dados PXC.</summary>
    public class TOCadaluno : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<String> codaluno;
        #endregion

        #region Campos Obrigatórios
        #endregion

        #region Campos Opcionais
        private CampoOpcional<String> cpfaluno;
        private CampoOpcional<String> letaluno;
        private CampoOpcional<String> nomaluno;
        private CampoOpcional<String> turno;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo CODALUNO da tabela CADALUNO.</summary>
        [XmlAttribute("codaluno")]
        [CampoTabela("CODALUNO", Chave = true, Obrigatorio = true, TipoParametro = DbType.String,
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> Codaluno
        {
            get { return this.codaluno; }
            set { this.codaluno = value; }
        }

        #endregion

        #region Campos Obrigatórios
        #endregion

        #region Campos Opcionais
        /// <summary>Campo CPFALUNO da tabela CADALUNO.</summary>
        [XmlAttribute("cpfaluno")]
        [CampoTabela("CPFALUNO", TipoParametro = DbType.String, 
            Tamanho = 11, Precisao = 11)]
        public CampoOpcional<String> Cpfaluno
        {
            get { return this.cpfaluno; }
            set { this.cpfaluno = value; }
        }

        /// <summary>Campo LETALUNO da tabela CADALUNO.</summary>
        [XmlAttribute("letaluno")]
        [CampoTabela("LETALUNO", TipoParametro = DbType.String, 
            Tamanho = 1, Precisao = 1)]
        public CampoOpcional<String> Letaluno
        {
            get { return this.letaluno; }
            set { this.letaluno = value; }
        }

        /// <summary>Campo NOMALUNO da tabela CADALUNO.</summary>
        [XmlAttribute("nomaluno")]
        [CampoTabela("NOMALUNO", TipoParametro = DbType.String, 
            Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> Nomaluno
        {
            get { return this.nomaluno; }
            set { this.nomaluno = value; }
        }

        /// <summary>Campo TURNO da tabela CADALUNO.</summary>
        [XmlAttribute("turno")]
        [CampoTabela("TURNO", TipoParametro = DbType.String, 
            Tamanho = 5, Precisao = 5)]
        public CampoOpcional<String> Turno
        {
            get { return this.turno; }
            set { this.turno = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "CODALUNO":
                        this.codaluno = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    #endregion

                    #region Campos Opcionais
                    case "CPFALUNO":
                        this.cpfaluno = this.LerCampoOpcional<String>(campo);
                        if(this.cpfaluno.TemConteudo)
                        {
                            this.cpfaluno = this.cpfaluno.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "LETALUNO":
                        this.letaluno = this.LerCampoOpcional<String>(campo);
                        if(this.letaluno.TemConteudo)
                        {
                            this.letaluno = this.letaluno.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "NOMALUNO":
                        this.nomaluno = this.LerCampoOpcional<String>(campo);
                        if(this.nomaluno.TemConteudo)
                        {
                            this.nomaluno = this.nomaluno.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    case "TURNO":
                        this.turno = this.LerCampoOpcional<String>(campo);
                        if(this.turno.TemConteudo)
                        {
                            this.turno = this.turno.LerConteudoOuPadrao().Trim();
                        }
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}