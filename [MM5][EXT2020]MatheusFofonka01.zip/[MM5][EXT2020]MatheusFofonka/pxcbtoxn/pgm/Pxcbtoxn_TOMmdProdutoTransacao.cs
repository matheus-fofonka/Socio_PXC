﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela MMD_PRODUTO_TRANSACAO da base de dados PXC.</summary>
    public class TOMmdProdutoTransacao : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Decimal> codProduto;
        private CampoObrigatorio<Decimal> codTransacao;
        #endregion

        #region Campos Obrigatórios
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_PRODUTO da tabela MMD_PRODUTO_TRANSACAO.</summary>
        [XmlAttribute("cod_produto")]
        [CampoTabela("COD_PRODUTO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodProduto
        {
            get { return this.codProduto; }
            set { this.codProduto = value; }
        }

        /// <summary>Campo COD_TRANSACAO da tabela MMD_PRODUTO_TRANSACAO.</summary>
        [XmlAttribute("cod_transacao")]
        [CampoTabela("COD_TRANSACAO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal,
            Tamanho = 5, Precisao = 5)]
        public CampoObrigatorio<Decimal> CodTransacao
        {
            get { return this.codTransacao; }
            set { this.codTransacao = value; }
        }

        #endregion

        #region Campos Obrigatórios
        #endregion

        #region Campos Opcionais
        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_PRODUTO":
                        this.codProduto = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "COD_TRANSACAO":
                        this.codTransacao = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}