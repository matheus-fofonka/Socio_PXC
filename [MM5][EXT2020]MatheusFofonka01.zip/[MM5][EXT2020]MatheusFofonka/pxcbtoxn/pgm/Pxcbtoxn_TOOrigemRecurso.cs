﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela ORIGEM_RECURSO da base de dados PXC.</summary>
    public class TOOrigemRecurso : TOTabela
    {
        #region Atributos
        #region Chaves Primárias
        private CampoObrigatorio<Int32> codOrigem;
        #endregion

        #region Campos Obrigatórios
        private CampoObrigatorio<String> codUsuario;
        private CampoObrigatorio<String> descrOrigem;
        private CampoObrigatorio<DateTime> dthrUltAtu;
        private CampoObrigatorio<Decimal> percRenda;
        private CampoObrigatorio<Decimal> txJuros;
        #endregion

        #region Campos Opcionais
        private CampoOpcional<Decimal> percRendaFunc;
        private CampoOpcional<Decimal> txJurosFunc;
        #endregion
        #endregion

        #region Propriedades
        #region Chaves Primárias
        /// <summary>Campo COD_ORIGEM da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("cod_origem")]
        [CampoTabela("COD_ORIGEM", Chave = true, Obrigatorio = true, TipoParametro = DbType.Int32,
            Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<Int32> CodOrigem
        {
            get { return this.codOrigem; }
            set { this.codOrigem = value; }
        }

        #endregion

        #region Campos Obrigatórios
        /// <summary>Campo COD_USUARIO da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("cod_usuario")]
        [CampoTabela("COD_USUARIO", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodUsuario
        { 
            get { return this.codUsuario; }
            set { this.codUsuario = value; }
        }

        /// <summary>Campo DESCR_ORIGEM da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("descr_origem")]
        [CampoTabela("DESCR_ORIGEM", Obrigatorio = true, TipoParametro = DbType.String, 
            Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> DescrOrigem
        { 
            get { return this.descrOrigem; }
            set { this.descrOrigem = value; }
        }

        /// <summary>Campo DTHR_ULT_ATU da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("dthr_ult_atu")]
        [CampoTabela("DTHR_ULT_ATU", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, 
            Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> DthrUltAtu
        { 
            get { return this.dthrUltAtu; }
            set { this.dthrUltAtu = value; }
        }

        /// <summary>Campo PERC_RENDA da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("perc_renda")]
        [CampoTabela("PERC_RENDA", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoObrigatorio<Decimal> PercRenda
        { 
            get { return this.percRenda; }
            set { this.percRenda = value; }
        }

        /// <summary>Campo TX_JUROS da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("tx_juros")]
        [CampoTabela("TX_JUROS", Obrigatorio = true, TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoObrigatorio<Decimal> TxJuros
        { 
            get { return this.txJuros; }
            set { this.txJuros = value; }
        }

        #endregion

        #region Campos Opcionais
        /// <summary>Campo PERC_RENDA_FUNC da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("perc_renda_func")]
        [CampoTabela("PERC_RENDA_FUNC", TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoOpcional<Decimal> PercRendaFunc
        {
            get { return this.percRendaFunc; }
            set { this.percRendaFunc = value; }
        }

        /// <summary>Campo TX_JUROS_FUNC da tabela ORIGEM_RECURSO.</summary>
        [XmlAttribute("tx_juros_func")]
        [CampoTabela("TX_JUROS_FUNC", TipoParametro = DbType.Decimal, 
            Tamanho = 5, Precisao = 5, Escala = 2)]
        public CampoOpcional<Decimal> TxJurosFunc
        {
            get { return this.txJurosFunc; }
            set { this.txJurosFunc = value; }
        }

        #endregion
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_ORIGEM":
                        this.codOrigem = Convert.ToInt32(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "COD_USUARIO":
                        this.codUsuario = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DESCR_ORIGEM":
                        this.descrOrigem = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DTHR_ULT_ATU":
                        this.dthrUltAtu = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "PERC_RENDA":
                        this.percRenda = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "TX_JUROS":
                        this.txJuros = Convert.ToDecimal(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "PERC_RENDA_FUNC":
                        this.percRendaFunc = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    case "TX_JUROS_FUNC":
                        this.txJurosFunc = this.LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}